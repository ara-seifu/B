﻿#define M_PI 3.141592653589793238f 

#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <limits>
#include <iostream>

struct Vec2 {
    double x, y;
    Vec2(double x = 0, double y = 0) : x(x), y(y) {}
    Vec2 operator+(const Vec2& o) const { return Vec2(x + o.x, y + o.y); }
    Vec2 operator-(const Vec2& o) const { return Vec2(x - o.x, y - o.y); }
    Vec2 operator*(double s) const { return Vec2(x * s, y * s); }
};

struct Segment {
    Vec2 a, b;
    Segment(Vec2 a = Vec2(), Vec2 b = Vec2()) : a(a), b(b) {}
};

int WIN_W = 900, WIN_H = 700;
std::vector<Segment> walls;

Vec2 playerPos(200, 200);
double playerAngle = 0.0;
double moveSpeed = 200.0;

int NUM_RAYS = 300;
double FOV = M_PI / 3.0;
double MAX_DIST = 2000.0;

bool keyState[256] = {0};
bool specialKeyState[256] = {0};
bool mouseDown = false;
int lastMouseX = 0;
int lastTime = 0;

bool raySegmentIntersect(const Vec2& origin, const Vec2& dir, const Segment& seg, double& outDist, Vec2& outPoint) {
    double r_x = seg.b.x - seg.a.x;
    double r_y = seg.b.y - seg.a.y;
    double s_x = dir.x;
    double s_y = dir.y;
    double denom = (s_x * (-r_y) - s_y * (-r_x));
    if (fabs(denom) < 1e-9) return false;
    double dx = seg.a.x - origin.x;
    double dy = seg.a.y - origin.y;
    double t = (dx * (-r_y) - dy * (-r_x)) / denom;
    double u = (s_x * dy - s_y * dx) / denom;
    if (t >= 0.0 && u >= 0.0 && u <= 1.0) {
        outDist = t;
        outPoint = Vec2(origin.x + t * s_x, origin.y + t * s_y);
        return true;
    }
    return false;
}

Vec2 angleToDir(double ang) {
    return Vec2(cos(ang), sin(ang));
}

void initScene() {
    walls.clear();
    walls.emplace_back(Vec2(50, 50), Vec2(WIN_W - 50, 50));
    walls.emplace_back(Vec2(WIN_W - 50, 50), Vec2(WIN_W - 50, WIN_H - 50));
    walls.emplace_back(Vec2(WIN_W - 50, WIN_H - 50), Vec2(50, WIN_H - 50));
    walls.emplace_back(Vec2(50, WIN_H - 50), Vec2(50, 50));
    walls.emplace_back(Vec2(150, 100), Vec2(300, 180));
    walls.emplace_back(Vec2(350, 250), Vec2(650, 220));
    walls.emplace_back(Vec2(400, 120), Vec2(420, 380));
    walls.emplace_back(Vec2(600, 400), Vec2(720, 550));
    walls.emplace_back(Vec2(200, 500), Vec2(320, 420));
    walls.emplace_back(Vec2(480, 320), Vec2(560, 260));
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    for (int i = 0; i < NUM_RAYS; ++i) {
        double rayAngle = playerAngle - FOV / 2 + i * FOV / NUM_RAYS;
        Vec2 dir = angleToDir(rayAngle);

        double closestDist = MAX_DIST;
        int wallIndex = -1;
        for (size_t w = 0; w < walls.size(); ++w) {
            double d;
            Vec2 p;
            if (raySegmentIntersect(playerPos, dir, walls[w], d, p)) {
                if (d < closestDist) { closestDist = d; wallIndex = (int)w; }
            }
        }

        double correctedDist = closestDist * cos(rayAngle - playerAngle);
        double wallHeight = (WIN_H * 100) / (correctedDist + 0.0001);

        // 壁の明暗
        double brightness = std::min(1.0, 400 / (correctedDist + 1));

        // 壁色（壁ごとに色を変える）
        double baseR = 0.5 + 0.5 * ((wallIndex % 3) == 0);
        double baseG = 0.5 + 0.5 * ((wallIndex % 3) == 1);
        double baseB = 0.5 + 0.5 * ((wallIndex % 3) == 2);
        glColor3f(baseR * brightness, baseG * brightness, baseB * brightness);

        double x = i * (double)WIN_W / NUM_RAYS;
        glBegin(GL_LINES);
        glVertex2d(x, WIN_H / 2 - wallHeight / 2);
        glVertex2d(x, WIN_H / 2 + wallHeight / 2);
        glEnd();

        // 床の描画
        for (int y = (int)(WIN_H / 2 + wallHeight / 2); y < WIN_H; ++y) {
            double dist = (WIN_H * 0.5) / (y - WIN_H / 2);
            double shade = std::min(1.0, 0.6 / (dist + 0.01));
            glColor3f(0.2 * shade, 0.2 * shade, 0.2 * shade);
            glBegin(GL_POINTS);
            glVertex2d(x, y);
            glEnd();
        }
        // 天井
        for (int y = 0; y < (int)(WIN_H / 2 - wallHeight / 2); ++y) {
            double dist = (WIN_H * 0.5) / (WIN_H / 2 - y);
            double shade = std::min(1.0, 0.6 / (dist + 0.01));
            glColor3f(0.1 * shade, 0.1 * shade, 0.1 * shade);
            glBegin(GL_POINTS);
            glVertex2d(x, y);
            glEnd();
        }
    }

    glutSwapBuffers();
}

void reshape(int w, int h) {
    WIN_W = w; WIN_H = h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, w, h, 0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void keyboardDown(unsigned char k, int x, int y) { keyState[k] = true; if (k == 27) exit(0); }
void keyboardUp(unsigned char k, int x, int y) { keyState[k] = false; }
void specialDown(int key, int x, int y) { specialKeyState[key] = true; }
void specialUp(int key, int x, int y) { specialKeyState[key] = false; }

void passiveMotion(int x, int y) {
    if (mouseDown) {
        int dx = x - lastMouseX;
        playerAngle -= dx * 0.01;
        lastMouseX = x;
    }
}

void mouseButton(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) { mouseDown = true; lastMouseX = x; }
        else mouseDown = false;
    }
}

void idleFunc() {
    int t = glutGet(GLUT_ELAPSED_TIME);
    double dt = (lastTime == 0) ? 0 : (t - lastTime) / 1000.0;
    lastTime = t;

    Vec2 forward = angleToDir(playerAngle);
    Vec2 rightVec(-forward.y, forward.x);

    Vec2 delta(0, 0);
    if (keyState['w'] || keyState['W'] || specialKeyState[GLUT_KEY_UP])    delta = delta + forward * moveSpeed * dt;
    if (keyState['s'] || keyState['S'] || specialKeyState[GLUT_KEY_DOWN])  delta = delta - forward * moveSpeed * dt;
    if (keyState['a'] || keyState['A'] || specialKeyState[GLUT_KEY_LEFT])  delta = delta - rightVec * moveSpeed * dt;
    if (keyState['d'] || keyState['D'] || specialKeyState[GLUT_KEY_RIGHT]) delta = delta + rightVec * moveSpeed * dt;

    playerPos = playerPos + delta;

    if (playerPos.x < 50) playerPos.x = 50;
    if (playerPos.x > WIN_W - 50) playerPos.x = WIN_W - 50;
    if (playerPos.y < 50) playerPos.y = 50;
    if (playerPos.y > WIN_H - 50) playerPos.y = WIN_H - 50;

    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("疑似3Dレイキャスト（矢印キーで移動／マウスドラッグで回転）");

    glClearColor(0.08f, 0.08f, 0.08f, 1.0f);

    initScene();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboardDown);
    glutKeyboardUpFunc(keyboardUp);
    glutSpecialFunc(specialDown);
    glutSpecialUpFunc(specialUp);
    glutMouseFunc(mouseButton);
    glutMotionFunc(passiveMotion);
    glutIdleFunc(idleFunc);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutMainLoop();
    return 0;
}
