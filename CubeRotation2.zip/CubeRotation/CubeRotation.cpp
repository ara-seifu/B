﻿#include <GL/glut.h>  
#include <cmath>

// 四元数
struct Quaternion {
    double 
        w, x, y, z; // x,y,x は虚数、wは実数

    Quaternion(double w_ = 1, double x_ = 0, double y_ = 0, double z_ = 0) // コンストラクタ
        : w(w_), x(x_), y(y_), z(z_) {  // デフォルト値 w=1, x=y=z=0 は 単位四元数（回転なし）
    }

    static Quaternion fromAxisAngle(double ax, double ay, double az, double angle) { // 回転軸(ax,ay,az)と回転角(angle)からクォータニオンを作成
        double half = angle / 2.0 ;  // 四元数の公式では角度を半分にして計算する
        double s    = sin(half)   ;  // 軸成分に掛ける正弦値
        return Quaternion(cos(half), ax * s, ay * s, az * s); // ただし、回転軸は正規化（長さが１）されていることが条件
    }

    Quaternion operator*(const Quaternion& q) const {   // 掛け算（回転の合成）をオーバーロード
        return Quaternion(
            w * q.w - x * q.x - y * q.y - z * q.z, // 実数部       w = w1​w2 ​− x1​x2​ − y1​y2​ − z1​z2​
            w * q.x + x * q.w + y * q.z - z * q.y, // 虚数部（ｘ） x = w1​x2​ + x1​w2​ + y1​z2​ − z1​y2​
            w * q.y - x * q.z + y * q.w + z * q.x, // 虚数部（ｙ） y = w1​y2​ − x1​z2​ + y1​w2​ + z1​x2​
            w * q.z + x * q.y - y * q.x + z * q.w  // 虚数部（ｚ） z = w1​z2​ + x1​y2​ − y1​x2​ + z1​w2
        );
    }

    void normalize() {  // 正規化
        double len = sqrt(w * w + x * x + y * y + z * z);
        if (len <= 1e-12) return; // 安全策
        w /= len; x /= len; y /= len; z /= len;
    }

    void toMatrix(float m[16]) const { // glMultMatrixf() に渡すために 4×4 行列 に変換
        m[0] = 1 - 2 * y * y - 2 * z * z;
        m[1] = 2 * x * y + 2 * w * z;
        m[2] = 2 * x * z - 2 * w * y;
        m[3] = 0;

        m[4] = 2 * x * y - 2 * w * z;
        m[5] = 1 - 2 * x * x - 2 * z * z;
        m[6] = 2 * y * z + 2 * w * x;
        m[7] = 0;

        m[8] = 2 * x * z + 2 * w * y;
        m[9] = 2 * y * z - 2 * w * x;
        m[10] = 1 - 2 * x * x - 2 * y * y;
        m[11] = 0;

        m[12] = m[13] = m[14] = 0;
        m[15] = 1;
    }
};

Quaternion currentRotation;

void drawCube() {
    glBegin(GL_QUADS);
    glColor3f(1, 0, 0); glVertex3f(-1, -1,  1); glVertex3f( 1, -1,  1); glVertex3f( 1, 1,  1); glVertex3f(-1,  1,  1);
    glColor3f(0, 1, 0); glVertex3f(-1, -1, -1); glVertex3f(-1,  1, -1); glVertex3f( 1, 1, -1); glVertex3f( 1, -1, -1);
    glColor3f(0, 0, 1); glVertex3f(-1, -1, -1); glVertex3f(-1, -1,  1); glVertex3f(-1, 1,  1); glVertex3f(-1,  1, -1);
    glColor3f(1, 1, 0); glVertex3f( 1, -1, -1); glVertex3f( 1,  1, -1); glVertex3f( 1, 1,  1); glVertex3f( 1, -1,  1);
    glColor3f(1, 0, 1); glVertex3f(-1,  1, -1); glVertex3f(-1,  1,  1); glVertex3f( 1, 1,  1); glVertex3f( 1,  1, -1);
    glColor3f(0, 1, 1); glVertex3f(-1, -1, -1); glVertex3f( 1, -1, -1); glVertex3f( 1, -1, 1); glVertex3f(-1, -1,  1);
    glEnd();
}

// XYZ軸を描画（赤:X, 緑:Y, 青:Z）
void drawAxes() {
    glBegin(GL_LINES);
    // X軸
    glColor3f(1.0, 0.0, 0.0);
    glVertex3f(0, 0, 0); glVertex3f(5, 0, 0);
    // Y軸
    glColor3f(0.0, 1.0, 0.0);
    glVertex3f(0, 0, 0); glVertex3f(0, 5, 0);
    // Z軸
    glColor3f(0.0, 0.0, 1.0);
    glVertex3f(0, 0, 0); glVertex3f(0, 0, 5);
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();
    gluLookAt(3, 3, 5, 0, 0, 0, 0, 1, 0);

    // 軸を描画
    drawAxes();

    // 四元数回転を適用
    float m[16];
    currentRotation.toMatrix(m);
    glMultMatrixf(m);      // クォータニオンで回転

    drawCube();

    glutSwapBuffers();
}

void keyboard(unsigned char key, int, int) {
    Quaternion q;
    if (key == 'a') q = Quaternion::fromAxisAngle(0, 1, 0, 0.1);
    if (key == 'd') q = Quaternion::fromAxisAngle(0, 1, 0, -0.1);

    if (key == 'w') q = Quaternion::fromAxisAngle(1, 0, 0, 0.1);
    if (key == 's') q = Quaternion::fromAxisAngle(1, 0, 0, -0.1);

    if (key == 'q') q = Quaternion::fromAxisAngle(0, 0, 1, 0.1);
    if (key == 'e') q = Quaternion::fromAxisAngle(0, 0, 1, -0.1);

    if (key == 'a' || key == 'd' || key == 'w' || key == 's' || key == 'q' || key == 'e') {
        currentRotation = q * currentRotation;
        currentRotation.normalize();
        glutPostRedisplay();
    }
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (double)w / h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(1, 1, 1, 1);
    currentRotation = Quaternion();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(600, 600);
    glutCreateWindow("クォータニオンで立方体回転 (a/d:Y, w/s:X, q/e:Z)");
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}
