﻿#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <set>
#include <iomanip>
#include <cmath>
#include <conio.h>
using namespace std;

struct Point { int y, x; };
const int dy[4] = { -1,1,0,0 }, dx[4] = { 0,0,-1,1 };

// ANSIカラー
const string RED = "\033[31m";
const string RESET = "\033[0m";

// ---------------- BFS ----------------
int bfs_show_path(const vector<string>& maze, Point start, Point goal) {
    int H = maze.size(), W = maze[0].size();
    vector<vector<int>> visited(H, vector<int>(W, 0));
    vector<vector<Point>> prev(H, vector<Point>(W, { -1,-1 }));
    queue<Point> q;
    q.push(start);
    visited[start.y][start.x] = 1;
    int nodes_expanded = 0;

    vector<vector<int>> order(H, vector<int>(W, 0));
    int cnt = 1;

    while (!q.empty()) {
        Point cur = q.front(); q.pop();
        order[cur.y][cur.x] = cnt++;
        nodes_expanded++;
        if (cur.y == goal.y && cur.x == goal.x) break;

        for (int i = 0; i < 4; i++) {
            int ny = cur.y + dy[i], nx = cur.x + dx[i];
            if (ny < 0 || ny >= H || nx < 0 || nx >= W) continue;
            if (maze[ny][nx] == '#') continue;
            if (visited[ny][nx]) continue;
            visited[ny][nx] = 1;
            prev[ny][nx] = cur;
            q.push({ ny,nx });
        }
    }

    // BFS 展開順表示
    cout << "BFS 展開順:\n";
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            if (maze[y][x] == '#' || maze[y][x] == 'S' || maze[y][x] == 'G')
                cout << setw(3) << maze[y][x];
            else if (order[y][x] > 0)
                cout << setw(3) << order[y][x];
            else
                cout << setw(3) << ".";
        }
        cout << endl;
    }

    // 経路復元
    vector<Point> path;
    if (visited[goal.y][goal.x]) {
        Point cur = goal;
        while (!(cur.y == start.y && cur.x == start.x)) {
            path.push_back(cur);
            cur = prev[cur.y][cur.x];
        }
        path.push_back(start);
    }

    // BFS 最短経路表示（*を赤色）
    cout << "\nBFS 最短経路:\n";
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            bool on_path = false;
            for (auto& p : path) if (p.y == y && p.x == x) on_path = true;
            if (on_path && maze[y][x] == '.')
                cout << RED << "*" << RESET << "  ";
            else
                cout << maze[y][x] << "  ";
        }
        cout << endl;
    }

    return nodes_expanded;
}

// ---------------- A* ----------------
struct Node { Point p; int g, f; bool operator<(const Node& other) const { return f > other.f; } };
int manhattan(Point a, Point b) { return abs(a.y - b.y) + abs(a.x - b.x); }

int astar_show_path(const vector<string>& maze, Point start, Point goal) {
    int H = maze.size(), W = maze[0].size();
    vector<vector<int>> g_score(H, vector<int>(W, 1e9));
    vector<vector<Point>> prev(H, vector<Point>(W, { -1,-1 }));
    priority_queue<Node> open;
    set<pair<int, int>> closed;

    g_score[start.y][start.x] = 0;
    open.push({ start,0,manhattan(start,goal) });
    int nodes_expanded = 0;

    vector<vector<int>> order(H, vector<int>(W, 0));
    int cnt = 1;

    while (!open.empty()) {
        Node cur = open.top(); open.pop();
        if (closed.count({ cur.p.y, cur.p.x })) continue;
        closed.insert({ cur.p.y, cur.p.x });
        order[cur.p.y][cur.p.x] = cnt++;
        nodes_expanded++;
        if (cur.p.y == goal.y && cur.p.x == goal.x) break;

        for (int i = 0; i < 4; i++) {
            int ny = cur.p.y + dy[i], nx = cur.p.x + dx[i];
            if (ny < 0 || ny >= H || nx < 0 || nx >= W) continue;
            if (maze[ny][nx] == '#') continue;
            int tentative_g = g_score[cur.p.y][cur.p.x] + 1;
            if (tentative_g < g_score[ny][nx]) {
                g_score[ny][nx] = tentative_g;
                prev[ny][nx] = cur.p;
                open.push({ {ny,nx},tentative_g,tentative_g + manhattan({ny,nx},goal) });
            }
        }
    }

    // A* 展開順表示
    cout << "A* 展開順:\n";
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            if (maze[y][x] == '#' || maze[y][x] == 'S' || maze[y][x] == 'G')
                cout << setw(3) << maze[y][x];
            else if (order[y][x] > 0)
                cout << setw(3) << order[y][x];
            else
                cout << setw(3) << ".";
        }
        cout << endl;
    }

    // 経路復元
    vector<Point> path;
    if (g_score[goal.y][goal.x] != 1e9) {
        Point cur = goal;
        while (!(cur.y == start.y && cur.x == start.x)) {
            path.push_back(cur);
            cur = prev[cur.y][cur.x];
        }
        path.push_back(start);
    }

    // A* 最短経路表示（*を赤色）
    cout << "\nA* 最短経路:\n";
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            bool on_path = false;
            for (auto& p : path) if (p.y == y && p.x == x) on_path = true;
            if (on_path && maze[y][x] == '.')
                cout << RED << "*" << RESET << "  ";
            else
                cout << maze[y][x] << "  ";
        }
        cout << endl;
    }

    return nodes_expanded;
}

int main() {
    vector<string> maze = {
        "###############",
        "#S..#.....#...#",
        "#.#.#.##.#.##.#",
        "#...#..#..#...#",
        "###.#.##.##.#.#",
        "#.....#.......#",
        "#.#######.###.#",
        "#...........#G#",
        "###############"
    };

    Point start, goal;
    for (int y = 0; y < maze.size(); y++)
        for (int x = 0; x < maze[0].size(); x++) {
            if (maze[y][x] == 'S') start = { y,x };
            if (maze[y][x] == 'G') goal = { y,x };
        }

    int bfs_nodes = bfs_show_path(maze, start, goal);
    cout << "\nBFS 展開ノード数: " << bfs_nodes << "\n\n";

    int astar_nodes = astar_show_path(maze, start, goal);
    cout << "\nA* 展開ノード数: " << astar_nodes << endl;

    _getch();
    return 0;
}
