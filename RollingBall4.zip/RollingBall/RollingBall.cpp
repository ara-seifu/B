﻿#include <GL/glut.h>
#include <cmath>
#include <cstdio>

//-----------------------------------------------------
//   グローバル変数・定数
//-----------------------------------------------------

// ウィンドウサイズ
const int WIN_W = 800;
const int WIN_H = 600;

// 物理パラメータ
const float BALL_RADIUS = 0.5f;    // 球の半径
const float BALL_MASS = 1.0f;      // 球の質量
const float LINEAR_DAMP = 0.04f;   // 並進減衰（空気抵抗など）
const float ANGULAR_DAMP = 0.02f;  // 回転減衰
const float GRAVITY = 9.8f;        // 重力加速度
const float FRICTION = 0.25f;      // 動摩擦係数（床との摩擦）

// タイムステップ（1/60秒ごとに更新）
const float DT = 1.0f / 60.0f;

// 床のサイズ（見た目用）
const float FLOOR_SIZE = 10.0f;

//-----------------------------------------------------
//   ベクトル・クォータニオン構造体
//-----------------------------------------------------
struct Vec3 {
    float x, y, z;
};

struct Quaternion {
    float w, x, y, z;
    Quaternion(float ww = 1, float xx = 0, float yy = 0, float zz = 0)
        : w(ww), x(xx), y(yy), z(zz) {
    }
};

//-----------------------------------------------------
//   グローバル状態（ボールの位置・速度・姿勢）
//-----------------------------------------------------
Vec3 ballPos = { 0.0f, BALL_RADIUS, 0.0f }; // 位置
Vec3 ballVel = { 0.0f, 0.0f, 0.0f };        // 速度
Vec3 ballAngVel = { 0.0f, 0.0f, 0.0f };     // 角速度
Quaternion ballOrient;                       // 姿勢（回転）

//-----------------------------------------------------
//   ユーティリティ関数群
//-----------------------------------------------------

// ベクトルの長さ
float vecLen(float x, float z) { return std::sqrt(x * x + z * z); }

// クォータニオンの掛け算
Quaternion quatMultiply(const Quaternion& a, const Quaternion& b) {
    return Quaternion(
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w
    );
}

// 軸と角度からクォータニオンを生成
Quaternion quatFromAxisAngle(float ax, float ay, float az, float angle) {
    float half = angle * 0.5f;
    float s = std::sin(half);
    return Quaternion(std::cos(half), ax * s, ay * s, az * s);
}

// クォータニオンの正規化
void normalizeQuat(Quaternion& q) {
    float n = std::sqrt(q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z);
    if (n > 0.0f) {
        q.w /= n; q.x /= n; q.y /= n; q.z /= n;
    }
}

// OpenGL 用の回転行列に変換して適用
void applyQuatGL(const Quaternion& q) {
    float w = q.w, x = q.x, y = q.y, z = q.z;
    float m[16];

    m[0] = 1 - 2 * y * y - 2 * z * z; m[4] = 2 * x * y - 2 * z * w;     m[8] = 2 * x * z + 2 * y * w;     m[12] = 0;
    m[1] = 2 * x * y + 2 * z * w;     m[5] = 1 - 2 * x * x - 2 * z * z; m[9] = 2 * y * z - 2 * x * w;     m[13] = 0;
    m[2] = 2 * x * z - 2 * y * w;     m[6] = 2 * y * z + 2 * x * w;     m[10] = 1 - 2 * x * x - 2 * y * y; m[14] = 0;
    m[3] = 0;                         m[7] = 0;                         m[11] = 0;                        m[15] = 1;
    glMultMatrixf(m);
}

//-----------------------------------------------------
//   物理更新（摩擦付き転がりモデル）
//-----------------------------------------------------
void stepPhysics(float dt) {
    // --- 位置更新 ---
    ballPos.x += ballVel.x * dt;
    ballPos.z += ballVel.z * dt;

    // --- 接地点の速度（滑りの度合い）を計算 ---
    Vec3 contactVel = {
        ballVel.x + ballAngVel.z * BALL_RADIUS,
        0.0f,
        ballVel.z - ballAngVel.x * BALL_RADIUS
    };

    float slipSpeed = vecLen(contactVel.x, contactVel.z);

    // --- 摩擦力が働く ---
    if (slipSpeed > 1e-6f) {
        // 接地点の速度方向（逆向きが摩擦方向）
        float fx = -contactVel.x / slipSpeed;
        float fz = -contactVel.z / slipSpeed;

        // 摩擦力の大きさ（μmg）
        float fMag = FRICTION * BALL_MASS * GRAVITY;

        // 並進速度の更新
        ballVel.x += (fMag * fx / BALL_MASS) * dt;
        ballVel.z += (fMag * fz / BALL_MASS) * dt;

        // 回転トルクの更新
        // 球の慣性モーメント I = (2/5)mR²
        float I = 0.4f * BALL_MASS * BALL_RADIUS * BALL_RADIUS;
        float torqueX = fz * BALL_RADIUS;
        float torqueZ = -fx * BALL_RADIUS;
        ballAngVel.x += (torqueX / I) * dt;
        ballAngVel.z += (torqueZ / I) * dt;
    }

    // --- 減衰処理（空気抵抗など）---
    ballVel.x *= (1.0f - LINEAR_DAMP * dt);
    ballVel.z *= (1.0f - LINEAR_DAMP * dt);
    ballAngVel.x *= (1.0f - ANGULAR_DAMP * dt);
    ballAngVel.z *= (1.0f - ANGULAR_DAMP * dt);

    // --- 回転をクォータニオンに反映 ---
    float angSpeed = std::sqrt(ballAngVel.x * ballAngVel.x + ballAngVel.y * ballAngVel.y + ballAngVel.z * ballAngVel.z);
    if (angSpeed > 1e-6f) {
        float angle = angSpeed * dt;
        float ax = ballAngVel.x / angSpeed;
        float ay = ballAngVel.y / angSpeed;
        float az = ballAngVel.z / angSpeed;
        Quaternion dq = quatFromAxisAngle(ax, ay, az, angle);
        ballOrient = quatMultiply(dq, ballOrient);
        normalizeQuat(ballOrient);
    }

    // --- 床での反射処理 ---
    float limit = FLOOR_SIZE * 0.5f - BALL_RADIUS - 0.01f;
    if (ballPos.x > limit) { ballPos.x = limit; ballVel.x *= -0.4f; }
    if (ballPos.x < -limit) { ballPos.x = -limit; ballVel.x *= -0.4f; }
    if (ballPos.z > limit) { ballPos.z = limit; ballVel.z *= -0.4f; }
    if (ballPos.z < -limit) { ballPos.z = -limit; ballVel.z *= -0.4f; }

    // --- 停止判定 ---
    if (vecLen(ballVel.x, ballVel.z) < 0.001f) {
        ballVel.x = ballVel.z = 0.0f;
        ballAngVel.x = ballAngVel.z = 0.0f;
    }
}

//-----------------------------------------------------
//   床の描画
//-----------------------------------------------------
void drawFloor() {
    const float half = FLOOR_SIZE * 0.5f;
    const int GRID = 20;

    // 床面
    glBegin(GL_QUADS);
    glColor3f(0.6f, 0.6f, 0.6f);
    glNormal3f(0, 1, 0);
    glVertex3f(-half, 0.0f, -half);
    glVertex3f(half, 0.0f, -half);
    glVertex3f(half, 0.0f, half);
    glVertex3f(-half, 0.0f, half);
    glEnd();

    // グリッド線
    glColor3f(0.3f, 0.3f, 0.3f);
    glBegin(GL_LINES);
    for (int i = 0; i <= GRID; i++) {
        float t = -half + (FLOOR_SIZE / GRID) * i;
        glVertex3f(t, 0.001f, -half);
        glVertex3f(t, 0.001f, half);
        glVertex3f(-half, 0.001f, t);
        glVertex3f(half, 0.001f, t);
    }
    glEnd();
}

//-----------------------------------------------------
//   ボールの描画
//-----------------------------------------------------
void drawBall() {
    glPushMatrix();
    glTranslatef(ballPos.x, ballPos.y, ballPos.z);
    applyQuatGL(ballOrient);
    glColor3f(0.8f, 0.2f, 0.2f);
    glutSolidSphere(BALL_RADIUS, 48, 48);
    glColor3f(0.2f, 0.2f, 0.2f);
    glutWireSphere(BALL_RADIUS * 1.001f, 12, 12);
    glPopMatrix();
}

//-----------------------------------------------------
//   描画ループ
//-----------------------------------------------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // カメラの位置（やや斜め上から）
    gluLookAt(6.0f, 6.0f, 8.0f,
        0.0f, 0.0f, 0.0f,
        0.0f, 1.0f, 0.0f);

    // ライティング設定
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    GLfloat pos[] = { 5.0f, 8.0f, 5.0f, 1.0f };
    GLfloat diff[] = { 0.9f,0.9f,0.9f,1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, pos);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diff);

    drawFloor();
    drawBall();

    glutSwapBuffers();
}

//-----------------------------------------------------
//   ウィンドウサイズ変更時
//-----------------------------------------------------
void resize(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)w / h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

//-----------------------------------------------------
//   外力（インパルス）を与える
//-----------------------------------------------------
void applyImpulse(float fx, float fz) {
    ballVel.x += fx / BALL_MASS;
    ballVel.z += fz / BALL_MASS;
}

//-----------------------------------------------------
//   キー入力
//-----------------------------------------------------
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case 0x1b: exit(0); break; // ESCキーで終了
    case ' ': applyImpulse(3.0f, 0.0f); break; // スペースで右方向に加速
    case 'r': case 'R': // リセット
        ballPos = { 0.0f, BALL_RADIUS, 0.0f };
        ballVel = { 0.0f,0.0f,0.0f };
        ballAngVel = { 0.0f,0.0f,0.0f };
        ballOrient = Quaternion();
        break;
    }
}

//-----------------------------------------------------
//   特殊キー（矢印キー）
 //-----------------------------------------------------
void special(int key, int x, int y) {
    const float I = 1.5f;
    switch (key) {
    case GLUT_KEY_LEFT: applyImpulse(-I, 0.0f); break;
    case GLUT_KEY_RIGHT: applyImpulse(I, 0.0f); break;
    case GLUT_KEY_UP: applyImpulse(0.0f, -I); break;
    case GLUT_KEY_DOWN: applyImpulse(0.0f, I); break;
    }
}

//-----------------------------------------------------
//   タイマー更新（60FPS）
//-----------------------------------------------------
void timer(int v) {
    stepPhysics(DT);
    glutPostRedisplay();
    glutTimerFunc((int)(DT * 1000.0f), timer, 0);
}

//-----------------------------------------------------
//   メイン関数
//-----------------------------------------------------
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("摩擦付きボール転がし");

    glClearColor(0.1f, 0.1f, 0.12f, 1.0f);

    glutDisplayFunc(display);
    glutReshapeFunc(resize);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);
    glutTimerFunc((int)(DT * 1000.0f), timer, 0);

    // 材質設定（照明に対する反射特性）
    GLfloat mat_ambient[] = { 0.2f,0.2f,0.2f,1.0f };
    GLfloat mat_diffuse[] = { 0.8f,0.8f,0.8f,1.0f };
    GLfloat mat_specular[] = { 0.9f,0.9f,0.9f,1.0f };
    GLfloat mat_shininess[] = { 50.0f };
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

    glutMainLoop();
    return 0;
}
