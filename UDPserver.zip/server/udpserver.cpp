﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <iostream>
#include <winsock2.h>

#pragma comment(lib,"ws2_32.lib")
#define CHAT_PORT	1024
#define BUFSIZE     512

WSADATA	g_wsadata   ;			// winsock dll

int main(void) {
    SOCKET serverSock ;

    unsigned short port = CHAT_PORT ;
    char msg[] = "I'm fine, thank you"     ;
    char buf[BUFSIZE];
    int  receivedSize   ;
    int  sendSize       ;

    struct sockaddr_in client_addr          ;
    struct sockaddr_in server_addr  = { 0 } ;
 
    server_addr.sin_family          = AF_INET           ;
    server_addr.sin_addr.s_addr     = htonl(INADDR_ANY) ;   // 複数のNICへのアクセスを認める
    server_addr.sin_port            = htons(port)       ;  

    int len = sizeof(struct sockaddr_in)    ;

    // 1. Winsockを開始(WSAStartup())
    if (WSAStartup(MAKEWORD(2, 2), &g_wsadata) == SOCKET_ERROR) {	
        WSACleanup()    ;
        return -1       ;
    }
    printf("startup.\n")    ;

    // 2.ソケット生成(socket())
    serverSock = socket(AF_INET, SOCK_DGRAM, 0)    ;
    if (serverSock == INVALID_SOCKET) {
        WSACleanup();
        return -2   ;
    }
    printf("socket created.\n") ;

    // 3. ソケット登録(bind())
    if (bind(serverSock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        closesocket(serverSock) ;
        WSACleanup()    ;
        return -3   ;

    }

    printf("bind completed.\n") ;

   
    printf("\nlocalhost address = %s\n", "127.0.0.1") ;
    printf("localhost port    = %d\n", ntohs(server_addr.sin_port))       ;

    // 4.受信（recvfrom())
    receivedSize = recvfrom(serverSock, buf, sizeof(buf), 0,(sockaddr*)&client_addr,&len);
    if (receivedSize < 0) {
        printf("recvfrom() failed\n");
        WSACleanup();
        return -5;
    }
    printf("\nreceived: %s\n", buf);
    printf("remote host address = %s\n", inet_ntoa(client_addr.sin_addr))    ;
    printf("remote port    = %d\n", ntohs(client_addr.sin_port))        ;

    // 5.送信（sendto())
    sendSize=sendto(serverSock, msg, sizeof(msg),0,(sockaddr*)&client_addr, sizeof(sockaddr))    ;
    if (sendSize != sizeof(msg)) {
        printf("sendto() failed\n");
        WSACleanup();
        return -5;
    }
    printf("\nsended: %s\n", msg);
    printf("remote host address = %s\n", inet_ntoa(client_addr.sin_addr));
    printf("remote port    = %d\n", ntohs(client_addr.sin_port));

    // 6.ソケットクローズ(closesocket())
    closesocket(serverSock)                 ; 

    // 7.Winsockを終了
    WSACleanup()                            ;

    return 0    ;
}
