﻿#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <iostream>

#define M_PI 3.14159265358979323846f

// -------------------- ベクトルユーティリティ --------------------
struct Vec3 {
    float x, y, z;
    Vec3(float x_ = 0, float y_ = 0, float z_ = 0) :x(x_), y(y_), z(z_) {}
    Vec3 operator+(const Vec3& v) const { return Vec3(x + v.x, y + v.y, z + v.z); }
    Vec3 operator-(const Vec3& v) const { return Vec3(x - v.x, y - v.y, z - v.z); }
    Vec3 operator*(float s) const { return Vec3(x * s, y * s, z * s); }
    Vec3 operator/(float s) const { return Vec3(x / s, y / s, z / s); }
    Vec3& operator+=(const Vec3& v) { x += v.x; y += v.y; z += v.z; return *this; }
    Vec3& operator-=(const Vec3& v) { x -= v.x; y -= v.y; z -= v.z; return *this; }
    Vec3& operator*=(float s) { x *= s; y *= s; z *= s; return *this; }
};

static inline Vec3 cross(const Vec3& a, const Vec3& b) {
    return Vec3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}
static inline float dot(const Vec3& a, const Vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static inline float length(const Vec3& a) { return std::sqrt(dot(a, a)); }
static inline Vec3 normalize(const Vec3& a) { float l = length(a); return (l > 1e-8f) ? a * (1.0f / l) : Vec3(0, 0, 0); }

// -------------------- Ball 構造体 --------------------
struct Ball {
    Vec3 pos;
    Vec3 vel;
    Vec3 angVel;    // 角速度ベクトル（rad/s）
    float r;        // 半径
    float mass;
    float restitution; // 反発係数
    float color[3];
};

// -------------------- 定数 --------------------
const int WIN_W = 800, WIN_H = 600;
const float TABLE_W = 8.0f, TABLE_H = 4.0f;
const float TABLE_THICK = 0.2f;

const float DEFAULT_RESTITUTION = 0.99f;
const float SURFACE_FRICTION = 0.995f;   // 速度減衰（テーブル上の転がり抵抗簡易モデル）
const float ANGULAR_DAMP = 0.99f;

// 接触摩擦係数（衝突時の接線摩擦）
const float CONTACT_FRICTION_COEF = 0.2f; // 調整可能

// 物理タイムステップ（固定ステップでサブステップ実行）
const float PHYS_FIXED_DT = 1.0f / 120.0f; // 120 Hz
const float MAX_ACCUMULATED_DT = 0.1f;     // 100 ms（極端な遅延を切る）

// 全停止判定閾値
const float STOP_VELOCITY_THRESH = 0.02f; // m/s
const float STOP_ANGVEL_THRESH = 0.02f;   // rad/s

// -------------------- グローバル --------------------
std::vector<Ball> balls;
std::vector<Ball> initialBalls;
int prevTimeMs = 0;
float accumulator = 0.0f;

// -------------------- 色設定 --------------------
void setBallColor(int id, float col[3]) {
    static float colors[16][3] = {
        {1,1,1}, {1,1,0}, {0,0,1}, {1,0,0}, {0.5f,0,0.5f},
        {1,0.5f,0}, {0,1,0}, {0.6f,0.2f,0}, {0,0,0},
        {1,1,0}, {0,0,1}, {1,0,0}, {0.5f,0,0.5f}, {1,0.5f,0},
        {0,1,0}, {0.6f,0.2f,0}
    };
    int idx = id % 16;
    col[0] = colors[idx][0];
    col[1] = colors[idx][1];
    col[2] = colors[idx][2];
}

// -------------------- 初期化（ボール配置） --------------------
void initBalls() {
    balls.clear();

    // 白球（キュー）
    Ball cue;
    cue.r = 0.15f;
    cue.mass = 1.0f;
    cue.restitution = DEFAULT_RESTITUTION;
    cue.pos = Vec3(-3.0f, cue.r, 0.0f);
    cue.angVel = Vec3(0, 0, 0);
    setBallColor(0, cue.color);

    // ランダム角のバグ修正：-5..+5 deg
    float deg = ((float)rand() / RAND_MAX - 0.5f) * 10.0f; // -5..+5
    float angle = deg * (M_PI / 180.0f);
    float speed = 8.0f;
    cue.vel = Vec3(speed * std::cos(angle), 0.0f, speed * std::sin(angle));
    balls.push_back(cue);

    // 三角配置（15球）を正確な球径に合わせて配置（密充填三角格子）
    int n = 5; // rows
    int colorID = 1;
    float r = 0.15f;
    float diameter = 2.0f * r;
    float rowDx = std::sqrt(3.0f) * r; // row間のx差（正確な三角格子）
    float startX = 2.0f; // 三角の先端の x 座標

    for (int row = 0; row < n; ++row) {
        for (int col = 0; col <= row; ++col) {
            Ball b;
            b.r = r;
            b.mass = 1.0f;
            b.restitution = DEFAULT_RESTITUTION;
            // row に沿って x を進め、列で z を左右に並べる
            float bx = startX + row * rowDx;
            float bz = ((float)col - (float)row * 0.5f) * diameter;
            b.pos = Vec3(bx, b.r, bz);
            b.vel = Vec3(0, 0, 0);
            b.angVel = Vec3(0, 0, 0);
            setBallColor(colorID, b.color);
            balls.push_back(b);
            colorID++;
        }
    }

    initialBalls = balls;
}

// -------------------- 停止判定 --------------------
bool allStopped() {
    for (auto& b : balls) {
        if (length(b.vel) > STOP_VELOCITY_THRESH) return false;
        if (length(b.angVel) > STOP_ANGVEL_THRESH) return false;
    }
    return true;
}

// -------------------- リセット＆再発射 --------------------
void resetAndShoot() {
    balls = initialBalls;
    // 正しいランダム角 -5..+5
    float deg = ((float)rand() / RAND_MAX - 0.5f) * 10.0f;
    float angle = deg * (M_PI / 180.0f);
    float speed = 8.0f;
    balls[0].vel = Vec3(speed * std::cos(angle), 0, speed * std::sin(angle));
    // 速度・角速度を確実にリセット
    for (auto& b : balls) { b.angVel = Vec3(0, 0, 0); }
}

// -------------------- 物理ユーティリティ --------------------
// 球の慣性モーメント（均質な球） I = 2/5 m r^2
static inline float momentOfInertiaSphere(float m, float r) {
    return 0.4f * m * r * r;
}

// 位置補正：重なりを逆質量に比例して分離（最大補正量を設ける）
void positionalCorrection(Ball& A, Ball& B, const Vec3& n, float penetration) {
    // パラメータ（調整可能）
    const float percent = 0.8f; // 修正量の割合（Baumgarteスタイル）
    const float slop = 0.01f;   // 小さな侵入は無視
    if (penetration <= slop) return;

    float invMassA = 1.0f / A.mass;
    float invMassB = 1.0f / B.mass;
    float invMassSum = invMassA + invMassB;
    if (invMassSum <= 1e-9f) return;

    Vec3 correction = n * (percent * (penetration - slop) / invMassSum);
    // A を逆質量に比例して後退、B を前進
    A.pos -= correction * invMassA;
    B.pos += correction * invMassB;
}

// -------------------- 衝突処理（法線＋接線摩擦＋回転の更新） --------------------
void resolveCollision(Ball& A, Ball& B) {
    Vec3 d = B.pos - A.pos;
    float dist = length(d);
    float minDist = A.r + B.r;
    if (dist >= minDist || dist < 1e-6f) return; // 衝突なしまたは数値不安定

    Vec3 n = normalize(d); // A -> B の単位法線
    float penetration = minDist - dist;

    // 相対速度（線形）
    Vec3 relVel = B.vel - A.vel;
    float vn = dot(relVel, n);

    // 質量逆数
    float invMassA = 1.0f / A.mass;
    float invMassB = 1.0f / B.mass;

    // 反発インパルス（法線方向）
    if (vn < 0.0f) {
        float e = 0.5f * (A.restitution + B.restitution); // 平均反発係数
        float j = -(1.0f + e) * vn;
        j /= (invMassA + invMassB);

        Vec3 impulse = n * j;
        A.vel -= impulse * invMassA;
        B.vel += impulse * invMassB;

        // 接触点での相対接線速度（角速度を含める）
        // 接触点の位置ベクトル（中心から接触点）： rA = n * A.r, rB = -n * B.r (それぞれ接触点方向)
        Vec3 rA = n * A.r;
        Vec3 rB = n * (-B.r);

        // 接触点の線速度（v + omega x r）
        Vec3 vA_contact = A.vel + cross(A.angVel, rA);
        Vec3 vB_contact = B.vel + cross(B.angVel, rB);
        Vec3 relContactVel = vB_contact - vA_contact;

        // 接線方向速度（法線方向成分を除く）
        Vec3 tangent = relContactVel - n * dot(relContactVel, n);
        float vt = length(tangent);

        if (vt > 1e-6f) {
            Vec3 t = tangent * (1.0f / vt); // 正規化接線

            // 球の慣性
            float IA = momentOfInertiaSphere(A.mass, A.r);
            float IB = momentOfInertiaSphere(B.mass, B.r);

            // 接線方向の有効質量（近似）
            // denominator = 1/mA + 1/mB + ( (rA×t)^2 / IA ) + ( (rB×t)^2 / IB )
            Vec3 rAxt = cross(rA, t);
            Vec3 rBxt = cross(rB, t);
            float denom = invMassA + invMassB + (dot(rAxt, rAxt) / IA) + (dot(rBxt, rBxt) / IB);

            float jt = -vt / denom;
            // 静止摩擦に相当する上限（クーロン則の近似）
            float jtMax = CONTACT_FRICTION_COEF * j;
            if (std::fabs(jt) > jtMax) {
                // 動摩擦方向で制限
                jt = (jt > 0) ? jtMax : -jtMax;
            }

            Vec3 tangentialImpulse = t * jt;

            // 線形速度への影響
            A.vel -= tangentialImpulse * invMassA;
            B.vel += tangentialImpulse * invMassB;

            // 角速度への影響（トルク = r × J）
            Vec3 torqueA = cross(rA, tangentialImpulse * -1.0f); // A に対しては反対方向のインパルス
            Vec3 torqueB = cross(rB, tangentialImpulse);

            A.angVel += torqueA / IA;
            B.angVel += torqueB / IB;
        }
    }

    // 位置補正（penetration resolution）を行う（インパルス後）
    positionalCorrection(A, B, n, penetration);
}

// -------------------- updatePhysics: 単一固定ステップ（dt = PHYS_FIXED_DT） --------------------
void integrateStep(float dt) {
    // 基本的な運動（オイラー）
    for (auto& b : balls) {
        b.pos += b.vel * dt;
        // y はテーブル上に固定（高さ = 半径）
        b.pos.y = b.r;
        // 速度減衰（テーブル摩擦の簡易モデル）
        float linearFriction = std::pow(SURFACE_FRICTION, dt * 60.0f);
        b.vel *= linearFriction;
        b.angVel *= std::pow(ANGULAR_DAMP, dt * 60.0f);
    }

    // 壁との反射（単純な位置補正＋速度の法線成分反転）
    for (auto& b : balls) {
        if (b.pos.x - b.r < -TABLE_W / 2.0f) {
            b.pos.x = -TABLE_W / 2.0f + b.r;
            b.vel.x *= -b.restitution;
        }
        if (b.pos.x + b.r > TABLE_W / 2.0f) {
            b.pos.x = TABLE_W / 2.0f - b.r;
            b.vel.x *= -b.restitution;
        }
        if (b.pos.z - b.r < -TABLE_H / 2.0f) {
            b.pos.z = -TABLE_H / 2.0f + b.r;
            b.vel.z *= -b.restitution;
        }
        if (b.pos.z + b.r > TABLE_H / 2.0f) {
            b.pos.z = TABLE_H / 2.0f - b.r;
            b.vel.z *= -b.restitution;
        }
    }

    // 球同士の衝突解決（全対全だが球数が小さいので O(n^2)）
    size_t n = balls.size();
    for (size_t i = 0; i < n; ++i) {
        for (size_t j = i + 1; j < n; ++j) {
            resolveCollision(balls[i], balls[j]);
        }
    }

    // 停止判定：速度が閾値以下ならスナップしてエネルギーを消す
    if (allStopped()) {
        for (auto& b : balls) {
            b.vel = Vec3(0, 0, 0);
            b.angVel = Vec3(0, 0, 0);
        }
        // 自動再発射（オリジナルの挙動を維持）
        resetAndShoot();
    }
}

// -------------------- display / draw --------------------
void drawTable() {
    glPushMatrix();
    glTranslatef(0, -TABLE_THICK / 2.0f, 0);
    glScalef(TABLE_W, TABLE_THICK, TABLE_H);
    glColor3f(0.0f, 0.5f, 0.0f);
    glutSolidCube(1.0f);
    glPopMatrix();
}

void display() {
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    GLfloat lightPos[] = { 0.0f,10.0f,10.0f,1.0f };
    GLfloat lightColor[] = { 1.0f,1.0f,1.0f,1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (float)WIN_W / WIN_H, 0.1, 50.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0, 6, 10, 0, 0, 0, 0, 1, 0);

    drawTable();

    for (auto& b : balls) {
        glPushMatrix();
        glTranslatef(b.pos.x, b.pos.y, b.pos.z);
        glColor3f(b.color[0], b.color[1], b.color[2]);

        // optionally rotate sphere visually according to angVel (simple approx)
        // 回転角 = |angVel| * t (ここでは見た目目的: 単純に angVel の向きに回転する)
        // 実装を簡潔に保つため視覚回転は省略（angVel は物理計算に反映済み）

        glutSolidSphere(b.r, 24, 24);
        glPopMatrix();
    }

    glutSwapBuffers();
}

// -------------------- idle / 時間管理（固定タイムステップ） --------------------
void idle() {
    int timeMs = glutGet(GLUT_ELAPSED_TIME);
    static int lastTime = timeMs;
    int deltaMs = timeMs - lastTime;
    lastTime = timeMs;

    float dt = deltaMs * 0.001f;
    // dt クランプ（極端な遅延を防ぐ）
    if (dt > MAX_ACCUMULATED_DT) dt = MAX_ACCUMULATED_DT;

    accumulator += dt;

    // 上限のサブステップ数を設けて無限ループを防ぐ
    const int MAX_SUBSTEPS = 10;
    int substeps = 0;
    while (accumulator >= PHYS_FIXED_DT && substeps < MAX_SUBSTEPS) {
        integrateStep(PHYS_FIXED_DT);
        accumulator -= PHYS_FIXED_DT;
        ++substeps;
    }

    // 描画
    glutPostRedisplay();
}

// -------------------- OpenGL 初期設定 --------------------
void setupGL() {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glShadeModel(GL_SMOOTH);
}

// -------------------- main --------------------
int main(int argc, char** argv) {
    srand((unsigned)time(NULL));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("ビリヤード（改良版）");

    setupGL();
    initBalls();

    prevTimeMs = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    glutMainLoop();
    return 0;
}
