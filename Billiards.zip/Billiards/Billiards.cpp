#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <iostream>

//--------------------------------------------------------------
// �萔�F�~����
//--------------------------------------------------------------
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

//--------------------------------------------------------------
// 3�����x�N�g���\���́i�Q�[���̕������Z�ł͕K�{�j
//--------------------------------------------------------------
struct Vec3 {
    float x, y, z;

    // �R���X�g���N�^�i�f�t�H���g�l�t���j
    Vec3(float X = 0, float Y = 0, float Z = 0)
        : x(X), y(Y), z(Z) {
    }

    // ���Z�E���Z
    Vec3 operator+(const Vec3& v) const { return Vec3(x + v.x, y + v.y, z + v.z); }
    Vec3 operator-(const Vec3& v) const { return Vec3(x - v.x, y - v.y, z - v.z); }

    // �X�J���[�{�E���Z
    Vec3 operator*(float s) const { return Vec3(x * s, y * s, z * s); }
    Vec3 operator/(float s) const { return Vec3(x / s, y / s, z / s); }

    // �P���}�C�i�X�i-v�j
    Vec3 operator-() const { return Vec3(-x, -y, -z); }

    // �������
    Vec3& operator+=(const Vec3& v) { x += v.x; y += v.y; z += v.z; return *this; }
    Vec3& operator-=(const Vec3& v) { x -= v.x; y -= v.y; z -= v.z; return *this; }
    Vec3& operator*=(float s) { x *= s; y *= s; z *= s; return *this; }
};

//--------------------------------------------------------------
// �x�N�g�����Z�֐�
//--------------------------------------------------------------
inline float dot(const Vec3& a, const Vec3& b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

inline Vec3 cross(const Vec3& a, const Vec3& b) {
    return Vec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    );
}

inline float length(const Vec3& v) {
    return std::sqrt(dot(v, v));
}

inline Vec3 normalize(const Vec3& v) {
    float L = length(v);
    return (L > 1e-8f) ? (v * (1.0f / L)) : Vec3(0, 0, 0);
}

//--------------------------------------------------------------
// ���i�{�[���j
//--------------------------------------------------------------
struct Ball {
    Vec3 pos = Vec3(0, 0, 0);
    Vec3 vel = Vec3(0, 0, 0);
    Vec3 angVel = Vec3(0, 0, 0);

    float r = 0.0f;
    float mass = 1.0f;
    float restitution = 1.0f;

    float color[3] = { 1.0f, 1.0f, 1.0f };
};

//==============================================================
// �V�~�����[�V�����萔
//==============================================================
const int WIN_W = 800;
const int WIN_H = 600;

const float TABLE_W = 8.0f;
const float TABLE_H = 4.0f;
const float TABLE_THICK = 0.2f;

const float SURFACE_FRICTION = 0.995f;
const float ANGULAR_DAMP = 0.99f;

const float CONTACT_FRICTION = 0.2f;

const float FIXED_DT = 1.0f / 120.0f;
const float MAX_DT = 0.1f;

const float STOP_VEL = 0.08f;
const float STOP_ANG = 0.08f;

//==============================================================
std::vector<Ball> balls;
std::vector<Ball> initialBalls;
float accumulator = 0.0f;

//--------------------------------------------------------------
// �F�ݒ�
//--------------------------------------------------------------
void setBallColor(int id, float c[3]) {
    static float tbl[16][3] = {
        {1,1,1},{1,1,0},{0,0,1},{1,0,0},
        {1,0,1},{1,0.5f,0},{0,1,0},{0,0,0},
        {1,1,0},{0,0,1},{1,0,0},{1,0,1},
        {1,0.5f,0},{0,1,0},{0.5f,0.3f,0},{1,1,1}
    };
    int idx = id % 16;
    c[0] = tbl[idx][0];
    c[1] = tbl[idx][1];
    c[2] = tbl[idx][2];
}

//==============================================================
// �����z�u
//==============================================================
void initBalls() {
    balls.clear();

    // ����
    Ball cue;
    cue.r = 0.15f;
    cue.restitution = 0.99f;
    cue.pos = Vec3(-3.0f, cue.r, 0.0f);
    setBallColor(0, cue.color);

    float deg = ((float)rand() / RAND_MAX - 0.5f) * 10.0f;
    float rad = deg * (float)(M_PI / 180.0f);
    float speed = 8.0f;
    cue.vel = Vec3(speed * std::cos(rad), 0, speed * std::sin(rad));

    balls.push_back(cue);

    // �c���15�����O�p�`�z�u
    float r = 0.15f;
    float dia = 2 * r;
    float dx = std::sqrt(3.0f) * r;
    float startX = 2.0f;

    int colorID = 1;

    for (int row = 0; row < 5; row++) {
        for (int col = 0; col <= row; col++) {
            Ball b;
            b.r = r;
            b.restitution = 0.99f;

            float bx = startX + row * dx;
            float bz = (col - row * 0.5f) * dia;
            b.pos = Vec3(bx, b.r, bz);

            setBallColor(colorID, b.color);
            balls.push_back(b);
            colorID++;
        }
    }

    initialBalls = balls;
}

//==============================================================
bool allStopped() {
    for (const auto& b : balls) {
        if (length(b.vel) > STOP_VEL) return false;
        if (length(b.angVel) > STOP_ANG) return false;
    }
    return true;
}

//==============================================================
void resetAndShoot() {
    balls = initialBalls;

    float deg = ((float)rand() / RAND_MAX - 0.5f) * 10.0f;
    float rad = deg * (float)(M_PI / 180.0f);
    float speed = 8.0f;

    balls[0].vel = Vec3(speed * std::cos(rad), 0, speed * std::sin(rad));

    for (auto& b : balls) b.angVel = Vec3();
}

//==============================================================
float inertiaSphere(float m, float r) {
    return 0.4f * m * r * r;
}

//==============================================================
// �Փˉ����i���� + ���C + ��]�j
//==============================================================
void resolveCollision(Ball& A, Ball& B) {
    Vec3 d = B.pos - A.pos;
    float dist = length(d);
    float minDist = A.r + B.r;

    if (dist >= minDist || dist < 1e-6f) return;

    Vec3 n = normalize(d);
    float penetration = minDist - dist;

    Vec3 rel = B.vel - A.vel;
    float vn = dot(rel, n);

    float invA = 1.0f / A.mass;
    float invB = 1.0f / B.mass;

    if (vn < 0) {
        float e = 0.5f * (A.restitution + B.restitution);
        float j = -(1 + e) * vn / (invA + invB);
        Vec3 imp = n * j;

        A.vel -= imp * invA;
        B.vel += imp * invB;
    }

    Vec3 rA = n * A.r;
    Vec3 rB = -n * B.r;

    Vec3 vA_c = A.vel + cross(A.angVel, rA);
    Vec3 vB_c = B.vel + cross(B.angVel, rB);
    Vec3 relC = vB_c - vA_c;

    Vec3 tangent = relC - n * dot(relC, n);
    float tlen = length(tangent);

    if (tlen > 1e-6f) {
        Vec3 t = tangent * (1.0f / tlen);

        float IA = inertiaSphere(A.mass, A.r);
        float IB = inertiaSphere(B.mass, B.r);

        Vec3 rAxt = cross(rA, t);
        Vec3 rBxt = cross(rB, t);

        float denom = invA + invB + (dot(rAxt, rAxt) / IA) + (dot(rBxt, rBxt) / IB);

        float jt = -tlen / denom;
        float jtMax = CONTACT_FRICTION;

        if (std::fabs(jt) > jtMax)
            jt = (jt > 0 ? jtMax : -jtMax);

        Vec3 Jt = t * jt;

        A.vel -= Jt * invA;
        B.vel += Jt * invB;

        A.angVel += cross(rA, -Jt) / IA;
        B.angVel += cross(rB, Jt) / IB;
    }

    {
        const float percent = 0.8f;
        const float slop = 0.01f;

        if (penetration > slop) {
            float cm = percent * (penetration - slop) / (invA + invB);
            Vec3 corr = n * cm;

            A.pos -= corr * invA;
            B.pos += corr * invB;
        }
    }
}

//==============================================================
void integrateStep(float dt) {
    for (auto& b : balls) {
        b.pos += b.vel * dt;
        b.pos.y = b.r;

        float f = std::pow(SURFACE_FRICTION, dt * 60);
        b.vel *= f;
        b.angVel *= std::pow(ANGULAR_DAMP, dt * 60);
    }

    for (auto& b : balls) {
        if (b.pos.x - b.r < -TABLE_W / 2) {
            b.pos.x = -TABLE_W / 2 + b.r;
            b.vel.x = -b.vel.x * b.restitution;
        }
        if (b.pos.x + b.r > TABLE_W / 2) {
            b.pos.x = TABLE_W / 2 - b.r;
            b.vel.x = -b.vel.x * b.restitution;
        }
        if (b.pos.z - b.r < -TABLE_H / 2) {
            b.pos.z = -TABLE_H / 2 + b.r;
            b.vel.z = -b.vel.z * b.restitution;
        }
        if (b.pos.z + b.r > TABLE_H / 2) {
            b.pos.z = TABLE_H / 2 - b.r;
            b.vel.z = -b.vel.z * b.restitution;
        }
    }

    for (int i = 0; i < (int)balls.size(); i++)
        for (int j = i + 1; j < (int)balls.size(); j++)
            resolveCollision(balls[i], balls[j]);

    if (allStopped()) {
        for (auto& b : balls) {
            b.vel = Vec3();
            b.angVel = Vec3();
        }
        resetAndShoot();
    }
}

//==============================================================
void drawTable() {
    glPushMatrix();
    glTranslatef(0, -TABLE_THICK / 2, 0);
    glScalef(TABLE_W, TABLE_THICK, TABLE_H);
    glColor3f(0, 0.5f, 0);
    glutSolidCube(1.0f);
    glPopMatrix();
}

//==============================================================
void display() {
    glClearColor(0.2f, 0.2f, 0.2f, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    GLfloat lightPos[] = { 0,10,10,1 };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45, (float)WIN_W / WIN_H, 0.1, 50);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0, 6, 10, 0, 0, 0, 0, 1, 0);

    drawTable();

    for (auto& b : balls) {
        glPushMatrix();
        glTranslatef(b.pos.x, b.pos.y, b.pos.z);
        glColor3f(b.color[0], b.color[1], b.color[2]);
        glutSolidSphere(b.r, 24, 24);
        glPopMatrix();
    }

    glutSwapBuffers();
}

//==============================================================
void idle() {
    static int last = glutGet(GLUT_ELAPSED_TIME);
    int now = glutGet(GLUT_ELAPSED_TIME);

    float dt = (now - last) * 0.001f;
    last = now;

    if (dt > MAX_DT) dt = MAX_DT;

    accumulator += dt;

    const int MAX_STEPS = 10;
    int steps = 0;

    while (accumulator >= FIXED_DT && steps < MAX_STEPS) {
        integrateStep(FIXED_DT);
        accumulator -= FIXED_DT;
        steps++;
    }

    glutPostRedisplay();
}


//==============================================================
int main(int argc, char** argv) {
    srand((unsigned)time(NULL));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("�r�����[�h");

    glEnable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);

    initBalls();

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    glutMainLoop();
    return 0;
}
