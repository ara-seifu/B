﻿//==============================================================
// 2つのキャラクターを常に画面内に収める回転カメラ
//
// Visual Studio + freeglut
//
// キャラクターはXZ平面上を移動する
//
// 青い球：WASD
// 赤い球：カーソルキー
// ESC    ：終了
//==============================================================
#define NOMINMAX
#include <windows.h>
#include <GL/freeglut.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <algorithm>

//==============================================================
// 定数
//==============================================================

const int WINDOW_WIDTH = 1280;
const int WINDOW_HEIGHT = 720;

const float PI = 3.14159265358979323846f;

// アスペクト比
float aspectRatio =
    static_cast<float>(WINDOW_WIDTH) /
    static_cast<float>(WINDOW_HEIGHT);

// カメラの縦方向の画角
const float VERTICAL_FOV_DEG = 60.0f;

// キャラクターの半径
const float CHARACTER_RADIUS = 1.0f;

// キャラクターが画面端に近づきすぎないための余白
const float CAMERA_MARGIN = 1.5f;

// カメラが近づきすぎないための最低距離
const float MIN_CAMERA_DISTANCE = 6.0f;

// カメラの補間速度
const float CAMERA_SMOOTH_SPEED = 5.0f;

// キャラクターの移動速度
const float CHARACTER_MOVE_SPEED = 5.0f;

// カメラが1秒間に回転する角度
const float CAMERA_ROTATION_SPEED = 20.0f;

// カメラを水平面から何度上に配置するか
const float CAMERA_ELEVATION_DEG = 30.0f;

// 固定フレームレート
const int FPS = 60;

//==============================================================
// 3次元ベクトル
//==============================================================

struct Vector3
{
    float x;
    float y;
    float z;
};

//==============================================================
// キャラクター
//==============================================================

struct Character
{
    Vector3 position;

    float red;
    float green;
    float blue;
};

//==============================================================
// グローバル変数
//==============================================================

// 青いキャラクター
Character playerA =
{
    { -3.0f, 0.0f, 0.0f },
    0.2f, 0.5f, 1.0f
};

// 赤いキャラクター
Character playerB =
{
    { 3.0f, 0.0f, 0.0f },
    1.0f, 0.3f, 0.2f
};

// 現在のカメラ注視点
Vector3 cameraTarget =
{
    0.0f,
    0.0f,
    0.0f
};

// 現在のカメラ距離
float cameraDistance = 10.0f;

// カメラのY軸回転角度
float cameraRotationAngle = 0.0f;

//==============================================================
// キー入力
//==============================================================

bool keyW = false;
bool keyA = false;
bool keyS = false;
bool keyD = false;

bool keyLeft = false;
bool keyRight = false;
bool keyUp = false;
bool keyDown = false;

//==============================================================
// 角度をラジアンに変換
//==============================================================

float DegreeToRadian(float degree)
{
    return degree * PI / 180.0f;
}

//==============================================================
// 線形補間
//==============================================================

float Lerp(float start, float end, float t)
{
    return start + (end - start) * t;
}


//==============================================================
// カメラに必要な距離を求める
//
// 2体を包む大きな球を考え、
// カメラがどの方向に回転しても画面内に収まりやすくする
//==============================================================

float CalculateRequiredCameraDistance()
{
    //----------------------------------------------------------
    // 1. 垂直方向の半画角を求める
    //----------------------------------------------------------

    float verticalHalfFov =
        DegreeToRadian(
            VERTICAL_FOV_DEG * 0.5f
        );

    //----------------------------------------------------------
    // 2. 水平方向の半画角を求める
    //----------------------------------------------------------

    float horizontalHalfFov =
        std::atan(
            std::tan(verticalHalfFov) *
            aspectRatio
        );

    //----------------------------------------------------------
    // 3. 水平半画角と垂直半画角のうち、
    //    狭い方を使用する
    //----------------------------------------------------------

    float limitingHalfFov =
        std::min(
            horizontalHalfFov,
            verticalHalfFov
        );

    //----------------------------------------------------------
    // 4. 2体の中心間距離を求める
    //----------------------------------------------------------

    // float differenceX =

    // float differenceZ =

    // float distanceBetweenCharacters 

    //----------------------------------------------------------
    // 5. 2体を包む球の半径を求める
    //----------------------------------------------------------

    // float requiredRadius =
       

    //----------------------------------------------------------
    // 6. 包含球が画面内に収まる距離を求める
    //----------------------------------------------------------

    // float requiredDistance =

    //----------------------------------------------------------
    // 7. カメラが近づきすぎないようにする
    //----------------------------------------------------------

    // requiredDistance =

    // return requiredDistance;

     return 10 ;

}

//==============================================================
// キャラクターを移動させる
//==============================================================

void UpdateCharacters(float deltaTime)
{
    //----------------------------------------------------------
    // 青いキャラクター
    //----------------------------------------------------------

    Vector3 directionA =
    {
        0.0f,
        0.0f,
        0.0f
    };

    if (keyA)
    {
        directionA.x -= 1.0f;
    }

    if (keyD)
    {
        directionA.x += 1.0f;
    }

    if (keyW)
    {
        directionA.z -= 1.0f;
    }

    if (keyS)
    {
        directionA.z += 1.0f;
    }

    //----------------------------------------------------------
    // 斜め移動が速くならないように正規化
    //----------------------------------------------------------

    float lengthA =
        std::sqrt(
            directionA.x * directionA.x +
            directionA.z * directionA.z
        );

    if (lengthA > 0.0001f)
    {
        directionA.x /= lengthA;
        directionA.z /= lengthA;
    }

    playerA.position.x +=
        directionA.x *
        CHARACTER_MOVE_SPEED *
        deltaTime;

    playerA.position.z +=
        directionA.z *
        CHARACTER_MOVE_SPEED *
        deltaTime;

    //----------------------------------------------------------
    // 赤いキャラクター
    //----------------------------------------------------------

    Vector3 directionB =
    {
        0.0f,
        0.0f,
        0.0f
    };

    if (keyLeft)
    {
        directionB.x -= 1.0f;
    }

    if (keyRight)
    {
        directionB.x += 1.0f;
    }

    if (keyUp)
    {
        directionB.z -= 1.0f;
    }

    if (keyDown)
    {
        directionB.z += 1.0f;
    }

    //----------------------------------------------------------
    // 斜め移動が速くならないように正規化
    //----------------------------------------------------------

    float lengthB =
        std::sqrt(
            directionB.x * directionB.x +
            directionB.z * directionB.z
        );

    if (lengthB > 0.0001f)
    {
        directionB.x /= lengthB;
        directionB.z /= lengthB;
    }

    playerB.position.x +=
        directionB.x *
        CHARACTER_MOVE_SPEED *
        deltaTime;

    playerB.position.z +=
        directionB.z *
        CHARACTER_MOVE_SPEED *
        deltaTime;
}

//==============================================================
// カメラを更新する
//==============================================================

void UpdateCamera(float deltaTime)
{
    //----------------------------------------------------------
    // 2体の中間地点を求める
    //----------------------------------------------------------

    Vector3 desiredTarget =
    {
        (playerA.position.x + playerB.position.x) * 0.5f,

        0.0f,

        (playerA.position.z + playerB.position.z) * 0.5f
    };

    //----------------------------------------------------------
    // 2体を画面内に収めるための距離を求める
    //----------------------------------------------------------

    float desiredDistance =
        CalculateRequiredCameraDistance();

    //----------------------------------------------------------
    // フレームレートに依存しにくい補間係数
    //----------------------------------------------------------

    float interpolation =
        1.0f -
        std::exp(
            -CAMERA_SMOOTH_SPEED *
            deltaTime
        );

    //----------------------------------------------------------
    // 注視点を滑らかに移動
    //----------------------------------------------------------

    cameraTarget.x =
        Lerp(
            cameraTarget.x,
            desiredTarget.x,
            interpolation
        );

    cameraTarget.y =
        Lerp(
            cameraTarget.y,
            desiredTarget.y,
            interpolation
        );

    cameraTarget.z =
        Lerp(
            cameraTarget.z,
            desiredTarget.z,
            interpolation
        );

    //----------------------------------------------------------
    // カメラ距離を滑らかに変更
    //----------------------------------------------------------

    cameraDistance =
        Lerp(
            cameraDistance,
            desiredDistance,
            interpolation
        );

    //----------------------------------------------------------
    // カメラのY軸回転角度を更新
    //----------------------------------------------------------

    cameraRotationAngle +=
        CAMERA_ROTATION_SPEED *
        deltaTime;

    if (cameraRotationAngle >= 360.0f)
    {
        cameraRotationAngle -= 360.0f;
    }
}

//==============================================================
// キャラクターを描画する
//==============================================================

void DrawCharacter(const Character& character)
{
    glPushMatrix();

    glTranslatef(
        character.position.x,
        character.position.y,
        character.position.z
    );

    glColor3f(
        character.red,
        character.green,
        character.blue
    );

    glutSolidSphere(
        CHARACTER_RADIUS,
        32,
        32
    );

    glPopMatrix();
}

//==============================================================
// XZ平面上に背景グリッドを描画する
//==============================================================

void DrawGrid()
{
    glDisable(GL_LIGHTING);

    glColor3f(
        0.85f,
        0.85f,
        0.85f
    );

    glBegin(GL_LINES);

    const int GRID_SIZE = 30;

    for (int i = -GRID_SIZE; i <= GRID_SIZE; i++)
    {
        //------------------------------------------------------
        // X方向に伸びる線
        //------------------------------------------------------

        glVertex3f(
            static_cast<float>(-GRID_SIZE),
            -1.1f,
            static_cast<float>(i)
        );

        glVertex3f(
            static_cast<float>(GRID_SIZE),
            -1.1f,
            static_cast<float>(i)
        );

        //------------------------------------------------------
        // Z方向に伸びる線
        //------------------------------------------------------

        glVertex3f(
            static_cast<float>(i),
            -1.1f,
            static_cast<float>(-GRID_SIZE)
        );

        glVertex3f(
            static_cast<float>(i),
            -1.1f,
            static_cast<float>(GRID_SIZE)
        );
    }

    glEnd();

    glEnable(GL_LIGHTING);
}

//==============================================================
// 文字列を描画する
//==============================================================

void DrawString(float x, float y, const char* text)
{
    glRasterPos2f(x, y);

    while (*text != '\0')
    {
        glutBitmapCharacter(
            GLUT_BITMAP_9_BY_15,
            *text
        );

        text++;
    }
}

//==============================================================
// 画面上に情報を表示する
//==============================================================

void DrawInformation()
{
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();

    glLoadIdentity();

    gluOrtho2D(
        0.0,
        static_cast<double>(WINDOW_WIDTH),
        0.0,
        static_cast<double>(WINDOW_HEIGHT)
    );

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glLoadIdentity();

    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);

    glColor3f(
        0.1f,
        0.1f,
        0.1f
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 30.0f,
        "Blue : W A S D"
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 50.0f,
        "Red  : Arrow Keys"
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 70.0f,
        "ESC  : Exit"
    );

    char buffer[128];

    std::snprintf(
        buffer,
        sizeof(buffer),
        "Camera Distance : %.2f",
        cameraDistance
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 100.0f,
        buffer
    );

    std::snprintf(
        buffer,
        sizeof(buffer),
        "Camera Angle : %.2f",
        cameraRotationAngle
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 120.0f,
        buffer
    );

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);

    glPopMatrix();

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    glMatrixMode(GL_MODELVIEW);
}

//==============================================================
// 描画
//==============================================================

void Display()
{
    glClear(
        GL_COLOR_BUFFER_BIT |
        GL_DEPTH_BUFFER_BIT
    );

    //----------------------------------------------------------
    // 透視投影
    //----------------------------------------------------------

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(
        VERTICAL_FOV_DEG,
        aspectRatio,
        0.1,
        500.0
    );

    //----------------------------------------------------------
    // モデルビュー行列
    //----------------------------------------------------------

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    //----------------------------------------------------------
    // カメラの回転角度をラジアンに変換
    //----------------------------------------------------------

    float rotationRadian =
        DegreeToRadian(
            cameraRotationAngle
        );

    //----------------------------------------------------------
    // カメラの仰角をラジアンに変換
    //----------------------------------------------------------

    float elevationRadian =
        DegreeToRadian(
            CAMERA_ELEVATION_DEG
        );

    //----------------------------------------------------------
    // カメラ距離を水平方向と高さに分解する
    //----------------------------------------------------------

    float horizontalCameraDistance =
        cameraDistance *
        std::cos(elevationRadian);

    float cameraHeight =
        cameraDistance *
        std::sin(elevationRadian);

    //----------------------------------------------------------
    // 2人の中間地点を中心として、
    // Y軸の周囲をカメラが回転する
    //----------------------------------------------------------

    float cameraX =
        cameraTarget.x +
        std::sin(rotationRadian) *
        horizontalCameraDistance;

    float cameraY =
        cameraTarget.y +
        cameraHeight;

    float cameraZ =
        cameraTarget.z +
        std::cos(rotationRadian) *
        horizontalCameraDistance;

    //----------------------------------------------------------
    // カメラ
    //----------------------------------------------------------

    gluLookAt(
        cameraX,
        cameraY,
        cameraZ,

        cameraTarget.x,
        cameraTarget.y,
        cameraTarget.z,

        0.0f,
        1.0f,
        0.0f
    );

    //----------------------------------------------------------
    // ライト
    //----------------------------------------------------------

    GLfloat lightPosition[] =
    {
        0.0f,
        20.0f,
        10.0f,
        1.0f
    };

    glLightfv(
        GL_LIGHT0,
        GL_POSITION,
        lightPosition
    );

    //----------------------------------------------------------
    // 描画
    //----------------------------------------------------------

    DrawGrid();

    DrawCharacter(playerA);
    DrawCharacter(playerB);

    DrawInformation();

    glutSwapBuffers();
}

//==============================================================
// ウィンドウサイズ変更
//==============================================================

void Reshape(int width, int height)
{
    if (height <= 0)
    {
        height = 1;
    }

    glViewport(
        0,
        0,
        width,
        height
    );

    aspectRatio =
        static_cast<float>(width) /
        static_cast<float>(height);
}

//==============================================================
// 通常キーを押した
//==============================================================

void KeyboardDown(
    unsigned char key,
    int,
    int
)
{
    switch (key)
    {
    case 'w':
    case 'W':
        keyW = true;
        break;

    case 'a':
    case 'A':
        keyA = true;
        break;

    case 's':
    case 'S':
        keyS = true;
        break;

    case 'd':
    case 'D':
        keyD = true;
        break;

    case 27:
        glutLeaveMainLoop();
        break;
    }
}

//==============================================================
// 通常キーを離した
//==============================================================

void KeyboardUp(
    unsigned char key,
    int,
    int
)
{
    switch (key)
    {
    case 'w':
    case 'W':
        keyW = false;
        break;

    case 'a':
    case 'A':
        keyA = false;
        break;

    case 's':
    case 'S':
        keyS = false;
        break;

    case 'd':
    case 'D':
        keyD = false;
        break;
    }
}

//==============================================================
// 特殊キーを押した
//==============================================================

void SpecialKeyDown(
    int key,
    int,
    int
)
{
    switch (key)
    {
    case GLUT_KEY_LEFT:
        keyLeft = true;
        break;

    case GLUT_KEY_RIGHT:
        keyRight = true;
        break;

    case GLUT_KEY_UP:
        keyUp = true;
        break;

    case GLUT_KEY_DOWN:
        keyDown = true;
        break;
    }
}

//==============================================================
// 特殊キーを離した
//==============================================================

void SpecialKeyUp(
    int key,
    int,
    int
)
{
    switch (key)
    {
    case GLUT_KEY_LEFT:
        keyLeft = false;
        break;

    case GLUT_KEY_RIGHT:
        keyRight = false;
        break;

    case GLUT_KEY_UP:
        keyUp = false;
        break;

    case GLUT_KEY_DOWN:
        keyDown = false;
        break;
    }
}

//==============================================================
// 更新処理
//==============================================================

void Timer(int)
{
    const float deltaTime =
        1.0f /
        static_cast<float>(FPS);

    UpdateCharacters(deltaTime);
    UpdateCamera(deltaTime);

    glutPostRedisplay();

    glutTimerFunc(
        1000 / FPS,
        Timer,
        0
    );
}

//==============================================================
// OpenGL初期化
//==============================================================

void Initialize()
{
    //----------------------------------------------------------
    // 背景色
    //----------------------------------------------------------

    glClearColor(
        1.0f,
        1.0f,
        1.0f,
        1.0f
    );

    //----------------------------------------------------------
    // 深度テスト
    //----------------------------------------------------------

    glEnable(GL_DEPTH_TEST);

    //----------------------------------------------------------
    // ライティング
    //----------------------------------------------------------

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    //----------------------------------------------------------
    // glColor3fの色をマテリアルとして使用する
    //----------------------------------------------------------

    glEnable(GL_COLOR_MATERIAL);

    glColorMaterial(
        GL_FRONT_AND_BACK,
        GL_AMBIENT_AND_DIFFUSE
    );

    //----------------------------------------------------------
    // スムーズシェーディング
    //----------------------------------------------------------

    glShadeModel(GL_SMOOTH);

    //----------------------------------------------------------
    // キーリピートを無効にする
    //----------------------------------------------------------

    glutIgnoreKeyRepeat(GL_TRUE);
}

//==============================================================
// メイン関数
//==============================================================

int main(int argc, char** argv)
{
    glutInit(&argc, argv);

    glutInitDisplayMode(
        GLUT_DOUBLE |
        GLUT_RGBA |
        GLUT_DEPTH
    );

    glutInitWindowSize(
        WINDOW_WIDTH,
        WINDOW_HEIGHT
    );

    glutCreateWindow(
        "２ヶ所のキャラクターを中心にカメラを回転させる"
    );

    Initialize();

    glutDisplayFunc(Display);
    glutReshapeFunc(Reshape);

    glutKeyboardFunc(KeyboardDown);
    glutKeyboardUpFunc(KeyboardUp);

    glutSpecialFunc(SpecialKeyDown);
    glutSpecialUpFunc(SpecialKeyUp);

    glutTimerFunc(
        1000 / FPS,
        Timer,
        0
    );

    glutMainLoop();

    return 0;
}
