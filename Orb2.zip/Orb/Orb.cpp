#define _USE_MATH_DEFINES
#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <string>

// ======================= �\���� =======================
struct Planet {
    std::string name;
    float a;           // �O�������a (AU)
    float ecc;         // �ΐS��
    float inclination; // �O���X�Ίp (�x)
    float period;      // ���]�����i���j
    float radius;      // �`��p���a
    float color[3];    // �F
};

// ======================= �f���f�[�^ =======================
std::vector<Planet> planets = {
    {"Mercury", 0.387f, 0.206f, 7.0f,    88.0f,   0.02f, {0.5f, 0.5f, 0.5f}},
    {"Venus",   0.723f, 0.007f, 3.4f,   225.0f,   0.05f, {1.0f, 0.8f, 0.2f}},
    {"Earth",   1.000f, 0.017f, 0.0f,   365.0f,   0.05f, {0.2f, 0.2f, 1.0f}},
    {"Mars",    1.524f, 0.093f, 1.85f,  687.0f,   0.04f, {1.0f, 0.3f, 0.3f}},
    {"Jupiter", 5.203f, 0.049f, 1.3f,  4331.0f,   0.10f, {1.0f, 0.6f, 0.2f}},
    {"Saturn",  9.537f, 0.056f, 2.5f, 10747.0f,   0.09f, {1.0f, 0.8f, 0.5f}},
    {"Uranus", 19.191f, 0.047f, 0.8f, 30589.0f,   0.07f, {0.5f, 0.8f, 1.0f}},
    {"Neptune",30.068f, 0.009f, 1.8f, 59800.0f,   0.07f, {0.2f, 0.4f, 1.0f}},
};

// ?? ���f�[�^�i�n�����S�E�傫�����邭�\���j
Planet moon = { "Moon", 0.00257f * 1.5f, 0.055f, 5.0f, 27.3f, 0.03f, {0.9f, 0.9f, 0.9f} };

// ======================= �O���[�o���ϐ� =======================
float simDay = 0.0f;
float simSpeed = 5.0f;  // 1�t���[��������̓���
bool paused = false;

// �J��������i�n���\�ʁj
float camAngleY = 0.0f;
float camDist = 0.0f; // �n���\�ʎ��_�Ȃ̂�0

// �}�E�X���x����
bool mouseDown = false;
int lastMouseX = 0;

// ======================= �f���{���̕`�� =======================
void drawPlanets() {
    for (auto& p : planets) {
        if (p.name == "Earth") continue; // �n���͕`���Ȃ��i�n���\�ʎ��_�j

        glPushMatrix();

        // �O���`��
        glColor3f(0.5f, 0.5f, 0.5f);
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < 360; i++) {
            float theta = i * M_PI / 180.0f;
            float r = p.a * (1 - p.ecc * p.ecc) / (1 + p.ecc * cos(theta));
            float x = r * cos(theta);
            float y = r * sin(theta);
            glVertex3f(x, 0, y);
        }
        glEnd();

        // �f���ʒu
        float M = 2 * M_PI * simDay / p.period;
        float E = M + p.ecc * sin(M);
        float x = p.a * (cos(E) - p.ecc);
        float y = p.a * sqrt(1 - p.ecc * p.ecc) * sin(E);

        glRotatef(p.inclination, 1, 0, 0);
        glTranslatef(x, 0, y);

        glColor3fv(p.color);
        glutSolidSphere(p.radius, 20, 20);

        glPopMatrix();
    }

    // ���`��
    glPushMatrix();
    float Mm = 2 * M_PI * simDay / moon.period;
    float Em = Mm + moon.ecc * sin(Mm);
    float xm = moon.a * (cos(Em) - moon.ecc);
    float ym = moon.a * sqrt(1 - moon.ecc * moon.ecc) * sin(Em);

    glRotatef(moon.inclination, 1, 0, 0);
    glTranslatef(xm, 0, ym);

    // ���O�����C���i�I�v�V�����j
    glColor3f(0.7f, 0.7f, 0.7f);
    glLineWidth(2.0f);
    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < 360; i++) {
        float theta = i * M_PI / 180.0f;
        float r = moon.a;
        glVertex3f(r * cos(theta), 0, r * sin(theta));
    }
    glEnd();
    glLineWidth(1.0f);

    // ���{��
    glColor3fv(moon.color);
    glutSolidSphere(moon.radius, 20, 20);
    glPopMatrix();
}

// ======================= �f�B�X�v���C�R�[���o�b�N =======================
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // �n���ʒu
    float M = 2 * M_PI * simDay / planets[2].period;
    float E = M + planets[2].ecc * sin(M);
    float earthX = planets[2].a * (cos(E) - planets[2].ecc);
    float earthY = planets[2].a * sqrt(1 - planets[2].ecc * planets[2].ecc) * sin(E);

    // �n���\�ʎ��_�J����
    float camHeight = planets[2].radius + 0.01f;
    gluLookAt(earthX, camHeight, earthY,
        earthX + sin(camAngleY * M_PI / 180.0), camHeight, earthY + cos(camAngleY * M_PI / 180.0),
        0, 1, 0);

    // ���z
    glPushMatrix();
    glColor3f(1.0f, 1.0f, 0.0f);
    glutSolidSphere(0.2f, 30, 30);
    glPopMatrix();

    drawPlanets();
    glutSwapBuffers();
}

// ======================= �A�j���[�V���� =======================
void idle() {
    if (!paused) simDay += simSpeed;
    glutPostRedisplay();
}

// ======================= ���͏��� =======================
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case 27: exit(0); break;
    case ' ': paused = !paused; break;
    case '/': simSpeed *= 2; break;
    case '-': simSpeed /= 2; if (simSpeed < 0.1f) simSpeed = 0.1f; break;
    }
}

void specialKeys(int key, int x, int y) {
    switch (key) {
    case GLUT_KEY_LEFT:  camAngleY -= 5; break;
    case GLUT_KEY_RIGHT: camAngleY += 5; break;
    }
}

// ======================= �}�E�X���� =======================
void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        mouseDown = (state == GLUT_DOWN);
        lastMouseX = x;
    }
}

void motion(int x, int y) {
    if (mouseDown) {
        int dx = x - lastMouseX;
        simSpeed += dx * 0.1f;
        if (simSpeed < 0.1f) simSpeed = 0.1f;
        lastMouseX = x;
    }
}

// ======================= �E�B���h�E���T�C�Y =======================
void reshape(int w, int h) {
    if (h == 0) h = 1;
    float aspect = (float)w / (float)h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, aspect, 0.001, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

// ======================= OpenGL������ =======================
void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0, 0, 0, 1);
}

// ======================= ���C���֐� =======================
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1200, 800);
    glutCreateWindow("�n�����_�̑��z�n");

    init();

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glutReshapeFunc(reshape);

    glutMouseFunc(mouse);
    glutMotionFunc(motion);

    glutMainLoop();
    return 0;
}
