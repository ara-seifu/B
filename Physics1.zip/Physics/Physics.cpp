// ============================================
// STEP 1 : ��1���������ď��Œ��˂�
// ============================================
#include <GL/freeglut.h>
#include <cmath>

float x = 0, y = 5, z = 0;     // ���̈ʒu
float vx = 0, vy = 0, vz = 0; // ���x
float radius = 1.0f;

float gravity = -9.8f;
float dt = 0.016f;
float restitution = 0.7f;

void update() {
    vy += gravity * dt; // �d��
    y += vy * dt;      // �ʒu�X�V

    // --- ���Ƃ̏Փ� ---
    if (y - radius < 0) {
        y = radius;
        vy = -vy * restitution;
    }
}

void timer(int v) {
    update();
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60, 16.0 / 9.0, 0.1, 1000);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(20, 15, 20, 0, 0, 0, 0, 1, 0);

    // ��
    glDisable(GL_LIGHTING);
    glColor3f(0.4f, 0.4f, 0.4f);
    glBegin(GL_QUADS);
    glVertex3f(-10, 0, -10);
    glVertex3f(10, 0, -10);
    glVertex3f(10, 0, 10);
    glVertex3f(-10, 0, 10);
    glEnd();
    glEnable(GL_LIGHTING);

    // ��
    glColor3f(0.8, 0.2, 0.2);
    glPushMatrix();
    glTranslatef(x, y, z);
    glutSolidSphere(radius, 24, 24);
    glPopMatrix();

    glutSwapBuffers();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1280, 720);
    glutCreateWindow("STEP1: ��1���������ď��Œ��˂�");

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glutDisplayFunc(display);
    glutTimerFunc(16, timer, 0);

    glutMainLoop();
}