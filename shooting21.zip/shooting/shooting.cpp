﻿#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <ctime>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct Bullet {
    float x, y;
    float vx, vy;
};

std::vector<Bullet> bullets;

float playerX = 0.0f;
float playerY = -0.8f;

int lastTime = 0;

// --- Way弾 ---
// baseAngle: 中心方向, n: 弾数, angleStep: 弾間隔角度(rad), speed: 単位/sec
void shootWay(float x, float y, float baseAngle, int n, float angleStep, float speed) {
    for (int i = 0; i < n; i++) {
        float angle = baseAngle + (i - n / 2) * angleStep;
        Bullet b;
        b.x = x;
        b.y = y;
        b.vx = cos(angle) * speed;
        b.vy = sin(angle) * speed;
        bullets.push_back(b);
    }
}

// --- 扇状弾 ---
// baseAngle: 中心角, spread: 扇の広がり, count: 弾数, speed: 単位/sec
void shootFan(float x, float y, float baseAngle, float spread, int count, float speed) {
    for (int i = 0; i < count; i++) {
        float angle = baseAngle - spread * 0.5f + spread * (i / (float)(count - 1));
        Bullet b;
        b.x = x;
        b.y = y;
        b.vx = cos(angle) * speed;
        b.vy = sin(angle) * speed;
        bullets.push_back(b);
    }
}

// --- バラマキ弾 ---
// speed: 弾速, count: 弾数
void shootRandom(float x, float y, int count, float speed) {
    for (int i = 0; i < count; i++) {
        float angle = (rand() % 360) * M_PI / 180.0f;
        Bullet b;
        b.x = x;
        b.y = y;
        b.vx = cos(angle) * speed;
        b.vy = sin(angle) * speed;
        bullets.push_back(b);
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー（青）
    glPointSize(10.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(playerX, playerY);
    glEnd();

    // 弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    // 弾の更新
    for (auto& b : bullets) {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
    }

    glutPostRedisplay();
}

void keyboard(unsigned char key, int, int) {
    if (key == '1') {
        // Way弾
        shootWay(playerX, playerY, M_PI / 2, 5, M_PI / 18, 0.5f); // 上方向、5発、10度間隔
    }
    else if (key == '2') {
        // 扇状弾
        shootFan(playerX, playerY, M_PI / 2, M_PI / 3, 7, 0.5f); // 上方向、60度、7発
    }
    else if (key == '3') {
        // バラマキ弾
        shootRandom(playerX, playerY, 10, 0.5f); // 10発ランダム
    }
}

int main(int argc, char** argv) {
    srand((unsigned)time(NULL));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("弾の種類デモ(1:Way弾/2:扇状弾/3:ランダムバラマキ弾)");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
