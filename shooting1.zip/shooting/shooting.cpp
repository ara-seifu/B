﻿#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <chrono>
#include <algorithm>

constexpr float PI = 3.14159265358979323846f;

// ウィンドウサイズ
const int WIDTH  = 600;
const int HEIGHT = 600;

// 弾の構造体
struct Bullet {
    float  x,  y;   // 位置
    float vx, vy;   // 速度 (単位: 座標/秒)
};

std::vector<Bullet> bullets;

// プレイヤーの位置
float playerX =  0.0f ;
float playerY = -0.8f ;

// 時間計測
std::chrono::high_resolution_clock::time_point prevTime ;

// --- Way弾発射 ---
void shootWay(int way, float angleRangeRad, float speed) {
    float baseAngle = PI / 2.0f; // ９０度（真上）

    for (int i = 0; i < way; i++) {
        float t = (way == 1) ? 0.0f : (float)i / (way - 1); // 0〜1
        float angle = baseAngle - angleRangeRad / 2.0f + angleRangeRad * t;

        Bullet b;
        b.x = playerX;
        b.y = playerY;
        b.vx = cosf(angle) * speed;
        b.vy = sinf(angle) * speed;

        bullets.push_back(b);
    }
}

// --- 描画 ---
void display() {
    // Δt計算
    auto now = std::chrono::high_resolution_clock::now();
    std::chrono::duration<float> elapsed = now - prevTime;
    float dt = elapsed.count(); // 秒
    prevTime = now;

    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー描画
    glColor3f(0.0f, 0.0f, 0.8f);
    glBegin(GL_TRIANGLES);
    glVertex2f(playerX, playerY);
    glVertex2f(playerX - 0.05f, playerY - 0.1f);
    glVertex2f(playerX + 0.05f, playerY - 0.1f);
    glEnd();

    // 弾の更新
    for (auto& b : bullets) {
        b.x += b.vx * dt; // 秒単位の移動
        b.y += b.vy * dt;
    }

    // 画面外の弾を削除（-1.2〜1.2 の範囲外なら削除）
    bullets.erase(std::remove_if(bullets.begin(), bullets.end(),
        [](const Bullet& b) {
            return (b.x < -1.2f || b.x > 1.2f || b.y < -1.2f || b.y > 1.2f);
        }), bullets.end());

    // 弾の描画
    glColor3f(1.0f, 0.0f, 0.0f);
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    for (const auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

// --- 毎フレーム更新 ---
void idle() {
    glutPostRedisplay();
}

// --- キーボード入力 ---
void keyboard(unsigned char key, int x, int y) {
    if (key == ' ') {
        // スペースキーで5-Way弾を発射
        // angleRange = 60度 = PI/3, speed = 0.6 (座標/秒)
        shootWay(5, PI / 3.0f, 0.6f);
    }   
    if (key == 0x1b) {
        exit(0);
    }
}

// --- 初期化 ---
void init() {
    glClearColor(0, 0, 0, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);
}

// --- メイン関数 ---
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WIDTH, HEIGHT);
    glutCreateWindow("Way弾(Spaceで発射）");

    init();

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    prevTime = std::chrono::high_resolution_clock::now();

    glutMainLoop();
    return 0;
}
