//==============================================================
// rubik_current_fixed.cpp
// �E�A�[�N�{�[���S�̉�]
// �E�e�ʉ�]�i�A�j���[�V�����j
//==============================================================

#define _USE_MATH_DEFINES
#include <windows.h>
#include <GL/glut.h>
#include <GL/glu.h>
#include <cmath>
#include <vector>

//==============================================================
// �N�H�[�^�j�I���i�S�̉�]�j
//==============================================================
struct Quat {
    double w, x, y, z;
    Quat(double w_ = 1, double x_ = 0, double y_ = 0, double z_ = 0) :w(w_), x(x_), y(y_), z(z_) {}
};


Quat quatMul(const Quat& a, const Quat& b) {
    return Quat(
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w   
    );
}

Quat quatFromAxisAngle(double ax, double ay, double az, double ang) {
    double len = std::sqrt(ax * ax + ay * ay + az * az);
    if (len < 1e-9) return Quat();
    ax /= len; ay /= len; az /= len;
    double s = std::sin(ang * 0.5);
    return Quat(std::cos(ang * 0.5), ax * s, ay * s, az * s);
}

void quatToMatrix(const Quat& q, float M[16]) {
    double w = q.w, x = q.x, y = q.y, z = q.z;
    M[0] = 1 - 2 * (y * y + z * z); M[1] = 2 * (x * y + z * w);     M[2] = 2 * (x * z - y * w);      M[3] = 0;
    M[4] = 2 * (x * y - z * w);     M[5] = 1 - 2 * (x * x + z * z); M[6] = 2 * (y * z + x * w);      M[7] = 0;
    M[8] = 2 * (x * z + y * w);     M[9] = 2 * (y * z - x * w);     M[10] = 1 - 2 * (x * x + y * y); M[11] = 0;
    M[12] = M[13] = M[14] = 0; M[15] = 1;
}

//==============================================================
// �A�[�N�{�[��
//==============================================================
int WinW = 800, WinH = 600;
bool dragging = false;
int lastX, lastY;
Quat cur_q, drag_q;
float Zoom = -10.0f;

void mapToSphere(int x, int y, double& vx, double& vy, double& vz) {
    double nx = (2.0 * x - WinW) / WinW;
    double ny = (WinH - 2.0 * y) / WinH;
    double len2 = nx * nx + ny * ny;
    if (len2 <= 1) { vx = nx; vy = ny; vz = std::sqrt(1 - len2); }
    else { double n = 1 / std::sqrt(len2); vx = nx * n; vy = ny * n; vz = 0; }
}

void mouseButton(int btn, int state, int x, int y) {
    if (btn == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {
            dragging = true; lastX = x; lastY = y; drag_q = Quat();
        }
        else {
            dragging = false;
            cur_q = quatMul(drag_q, cur_q);
            drag_q = Quat();
        }
    }
}

void mouseMotion(int x, int y) {
    if (!dragging) return;
    double x1, y1, z1, x2, y2, z2;
    mapToSphere(lastX, lastY, x1, y1, z1);
    mapToSphere(x, y, x2, y2, z2);
    double ax = y1 * z2 - z1 * y2;
    double ay = z1 * x2 - x1 * z2;
    double az = x1 * y2 - y1 * x2;
    double dot = x1 * x2 + y1 * y2 + z1 * z2;
    if (ax * ax + ay * ay + az * az > 1e-9) {
        dot = fmax(-1.0, fmin(1.0, dot));
        double ang = acos(dot);
        drag_q = quatMul(quatFromAxisAngle(ax, ay, az, ang * 1.5), drag_q);
    }
    lastX = x; lastY = y;
    glutPostRedisplay();
}

//==============================================================
// Cublet & �X�e�b�J�[
//==============================================================
enum Face  { UP, DOWN, FRONT, BACK, LEFT, RIGHT };
enum Color { NONE = -1, WHITE, YELLOW, RED, ORANGE, GREEN, BLUE };

struct Cublet {
    int x, y, z;
    int face[6];
};

std::vector<Cublet> cublets;

//==============================================================
// ��]���
//==============================================================
int rotAxis    = 0;   // ��]�� 1=X 2=Y 3=Z
int rotLayer   = 0;
int rotDir     = 1;
float rotAngle = 0;

//==============================================================
// ���ԊǗ��p
//==============================================================
int lastTime = 0;   // �O��̎����ims�j

//==============================================================
// �F
//==============================================================
GLfloat col[7][3] = {
    {   0,     0, 1},
    {   1,     1, 1},
    {   1,     1, 0},
    {   1,     0, 0},
    {   1, 0.35f, 0},
    {   0,  0.8f, 0},
    {0.2f,  0.4f, 1}
};

//==============================================================
// ������
//==============================================================
void initCublets() {
    cublets.clear();
    for (int x = -1; x <= 1; x++)
        for (int y = -1; y <= 1; y++)
            for (int z = -1; z <= 1; z++) {
                Cublet c{};
                c.x = x; c.y = y; c.z = z;
                for (int i = 0; i < 6; i++) 
                    c.face[i] = NONE;
                if (y ==  1) c.face[UP]    = WHITE;
                if (y == -1) c.face[DOWN]  = YELLOW;
                if (z ==  1) c.face[FRONT] = RED;
                if (z == -1) c.face[BACK]  = ORANGE;
                if (x == -1) c.face[LEFT]  = GREEN;
                if (x ==  1) c.face[RIGHT] = BLUE;
                cublets.push_back(c);
            }
}

//==============================================================
// �������X�e�b�J�[��]
//==============================================================

void rotateFacesX(Cublet& c, int d) {
    int t;
    if (d > 0) {
        // -90�� ����
        t = c.face[UP];
        c.face[UP]    = c.face[BACK];
        c.face[BACK]  = c.face[DOWN];
        c.face[DOWN]  = c.face[FRONT];
        c.face[FRONT] = t;
    }
    else {
        t = c.face[UP];
        c.face[UP]    = c.face[FRONT];
        c.face[FRONT] = c.face[DOWN];
        c.face[DOWN]  = c.face[BACK];
        c.face[BACK]  = t;
    }
}

void rotateFacesY(Cublet& c, int d) {
    int t;
    if (d > 0) { 
        t = c.face[FRONT]; 
        c.face[FRONT] = c.face[LEFT]; 
        c.face[LEFT]  = c.face[BACK]; 
        c.face[BACK]  = c.face[RIGHT]; 
        c.face[RIGHT] = t; 
    }
    else { 
        t = c.face[FRONT]; 
        c.face[FRONT] = c.face[RIGHT]; 
        c.face[RIGHT] = c.face[BACK]; 
        c.face[BACK]  = c.face[LEFT]; 
        c.face[LEFT]  = t; 
    }
}

void rotateFacesZ(Cublet& c, int d) {
    int t;
    if (d > 0) { 
        t = c.face[UP]; 
        c.face[UP] = c.face[RIGHT]; 
        c.face[RIGHT] = c.face[DOWN]; 
        c.face[DOWN] = c.face[LEFT]; 
        c.face[LEFT] = t; 
    }
    else { 
        t = c.face[UP]; 
        c.face[UP] = c.face[LEFT];  
        c.face[LEFT] = c.face[DOWN]; 
        c.face[DOWN] = c.face[RIGHT]; 
        c.face[RIGHT] = t; 
    }
}

//==============================================================
// ��]�m��
//==============================================================
void applyRotation() {
    for (auto& c : cublets) {
        if ((rotAxis == 1 && c.x == rotLayer) || (rotAxis == 2 && c.y == rotLayer) || (rotAxis == 3 && c.z == rotLayer)) {
            int x = c.x, y = c.y, z = c.z;
            if (rotAxis == 1) { // ����
                c.y = rotDir * z; 
                c.z = -rotDir * y; 
                rotateFacesX(c, -rotDir); 
            }
            if (rotAxis == 2) { // ����
                c.x = -rotDir * z; 
                c.z = rotDir * x; 
                rotateFacesY(c, -rotDir); 
            }
            if (rotAxis == 3) { // ����
                c.x = rotDir * y; 
                c.y = -rotDir * x; 
                rotateFacesZ(c, -rotDir); 
            }
        }
    }
}

//==============================================================
// �`��
//==============================================================
const float CUBE_SIZE = 0.9f, CUBE_GAP = 0.08f, CUBE_SURFACE = 0.002f;

void drawSticker(float h) {
    float in = 0.06f;
    glBegin(GL_QUADS);
    glVertex3f(-h + in, -h + in, 0);
    glVertex3f( h - in, -h + in, 0);
    glVertex3f( h - in,  h - in, 0);
    glVertex3f(-h + in,  h - in, 0);
    glEnd();
}

void drawCublet(const Cublet& c) {
    float x = c.x * (CUBE_SIZE + CUBE_GAP);
    float y = c.y * (CUBE_SIZE + CUBE_GAP);
    float z = c.z * (CUBE_SIZE + CUBE_GAP);
    float h = CUBE_SIZE * 0.5f, off = h + CUBE_SURFACE;

    glPushMatrix();
    glTranslatef(x, y, z);
    glColor3f(0.3f, 0.3f, 0.3f);
    glutSolidCube(CUBE_SIZE);

    glDisable(GL_LIGHTING);  // �ꎞ�I�Ƀ��C�e�B���O�𖳌��Ɂi�@�����Ȃ��̂ŐF�X�e�b�J�[���\������Ȃ��i�@���������|���S�� = ����������Ȃ��j�Ƃ����d�l�̂��߁j
    if (c.face[UP]    != NONE) { glPushMatrix(); glTranslatef(0,  off,    0); glRotatef(-90, 1, 0, 0); glColor3fv(col[c.face[UP]]   ); drawSticker(h); glPopMatrix(); }
    if (c.face[DOWN]  != NONE) { glPushMatrix(); glTranslatef(0, -off,    0); glRotatef( 90, 1, 0, 0); glColor3fv(col[c.face[DOWN]] ); drawSticker(h); glPopMatrix(); }
    if (c.face[FRONT] != NONE) { glPushMatrix(); glTranslatef(0,    0,  off); glColor3fv(col[c.face[FRONT]]); drawSticker(h); glPopMatrix(); }
    if (c.face[BACK]  != NONE) { glPushMatrix(); glTranslatef(0,    0, -off); glRotatef(180, 0, 1, 0); glColor3fv(col[c.face[BACK]] ); drawSticker(h); glPopMatrix(); }
    if (c.face[LEFT]  != NONE) { glPushMatrix(); glTranslatef(-off, 0,    0); glRotatef( 90, 0, 1, 0); glColor3fv(col[c.face[LEFT]] ); drawSticker(h); glPopMatrix(); }
    if (c.face[RIGHT] != NONE) { glPushMatrix(); glTranslatef( off, 0,    0); glRotatef(-90, 0, 1, 0); glColor3fv(col[c.face[RIGHT]]); drawSticker(h); glPopMatrix(); }
    glEnable(GL_LIGHTING);  // ���C�e�B���O��L���ɖ߂�

    glPopMatrix();
}

void drawRubik() {
    for (auto& c : cublets) {
        glPushMatrix();
        if (rotAxis) {
            bool hit = (rotAxis == 1 && c.x == rotLayer) || (rotAxis == 2 && c.y == rotLayer) || (rotAxis == 3 && c.z == rotLayer);
            if (hit) {
                if (rotAxis == 1) // ����
                    glRotatef(-rotAngle * rotDir, 1, 0, 0);
                if (rotAxis == 2) // ����
                    glRotatef(-rotAngle * rotDir, 0, 1, 0);
                if (rotAxis == 3) // ����
                    glRotatef(-rotAngle * rotDir, 0, 0, 1);
            }
        }
        drawCublet(c);
        glPopMatrix();
    }
}

//==============================================================
// GLUT
//==============================================================
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(0, 0, Zoom);

    float M[16];
    quatToMatrix(quatMul(drag_q, cur_q), M);
    glMultMatrixf(M);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    
    GLfloat la[] = { 0.25f,0.25f,0.25f,   1 };
    GLfloat ld[] = {     1,    1,    1,   1 };
    GLfloat lp[] = {     5,    6,   10,   1 };
    glLightfv(GL_LIGHT0, GL_AMBIENT, la);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, ld);
    glLightfv(GL_LIGHT0, GL_POSITION, lp);
    
    drawRubik();
    glDisable(GL_LIGHTING);
    glutSwapBuffers();
}

void reshape(int w, int h) {
    WinW = w > 1 ? w : 1; WinH = h > 1 ? h : 1;
    glViewport(0, 0, WinW, WinH);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)WinW / WinH, 0.1, 100);
    glMatrixMode(GL_MODELVIEW);
}

void idle() {
    int now = glutGet(GLUT_ELAPSED_TIME); // ms
    float dt = (now - lastTime) * 0.001f; // �b
    lastTime = now;

    if (rotAxis) {
        float speed = 180.0f;   // �x / �b�i�� �D���Ȓl�j
        rotAngle += speed * dt;

        if (rotAngle >= 90.0f) {
            rotAngle = 90.0f;
            applyRotation();
            rotAxis = 0;
            rotAngle = 0.0f;
        }
        glutPostRedisplay();
    }
}

void keyboard(unsigned char k, int, int) {
    if (rotAxis != 0)   // ��]����
        return;         // �L�[���󂯕t���Ȃ�

    bool rev = (k >= 'A' && k <= 'Z');
    if (rev) k += 32;
    rotDir = rev ? -1 : 1;

    if      (k == 'u') { rotAxis = 2; rotLayer =  1; }
    else if (k == 'd') { rotAxis = 2; rotLayer = -1; }
    else if (k == 'f') { rotAxis = 3; rotLayer =  1; }
    else if (k == 'b') { rotAxis = 3; rotLayer = -1; }
    else if (k == 'r') { rotAxis = 1; rotLayer =  1; }
    else if (k == 'l') { rotAxis = 1; rotLayer = -1; }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    lastTime = glutGet(GLUT_ELAPSED_TIME);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WinW, WinH);
    glutCreateWindow("���[�r�b�N�L���[�u�i�}�E�X�h���b�O�őS�̂���]�AU/D F/B R/L �ł��ꂼ���]�i�{�V�t�g�L�[�ŋt�]�j��]���͉�]�s�I");

    glEnable(GL_DEPTH_TEST);
    glClearColor(1, 1, 1, 1);

    initCublets();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idle);
    glutMouseFunc(mouseButton);
    glutMotionFunc(mouseMotion);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
}
