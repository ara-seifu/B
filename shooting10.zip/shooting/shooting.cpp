﻿#include <GL/glut.h>
#include <vector>
#include <cstdlib>
#include <ctime>

struct Bullet {
    float x, y;
    float vy; // 下方向の速度
};

std::vector<Bullet> bullets;

int lastTime = 0;

// 弾生成（画面上端のランダムX位置）
void spawnBullet() {
    Bullet b;
    b.x = (float)(rand() % 2000 - 1000) / 1000.0f; // -1.0〜1.0
    b.y = 1.0f; // 上端
    b.vy = -0.3f; // 下方向速度（少し遅く）
    bullets.push_back(b);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 弾（青）
    glPointSize(6.0f); // 見やすく大きめ
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    // 弾更新
    for (auto it = bullets.begin(); it != bullets.end();) {
        it->y += it->vy * dt;

        // 画面下に消えたら削除
        if (it->y < -1.0f) {
            it = bullets.erase(it);
        }
        else {
            ++it;
        }
    }

    // 弾生成（0.1秒ごとに2発）
    static float accumTime = 0.0f;
    accumTime += dt;
    if (accumTime > 0.1f) {
        for (int i = 0; i < 2; i++) spawnBullet();
        accumTime = 0.0f;
    }

    glutPostRedisplay();
}

int main(int argc, char** argv) {
    srand((unsigned int)time(0));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("雨弾");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    glutMainLoop();
    return 0;
}
