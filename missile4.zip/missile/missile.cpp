#define _USE_MATH_DEFINES

#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <ctime>

using std::sin;
using std::cos;
using std::atan2;
using std::sqrt;

// ---------------------------- �萔 ----------------------------
const int WIN_W = 1200;
const int WIN_H = 800;
const float DT = 0.016f;          // 60FPS
const float WORLD_X = 500.0f;
const float WORLD_Y = 350.0f;

const float TARGET_SPEED = 120.0f;
const float TARGET_MAX_TURN_RATE = 1.5f; // rad/s
const float MISSILE_SPEED = 200.0f;
const float MISSILE_TURN_RATE = 2.2f;    // rad/s

const float MISSILE_HIT_DIST = 15.0f;
const float MISSILE_LOST_DIST = 600.0f;
const float MISSILE_LOST_TIME = 2.0f;

// ---------------------------- �\���� ----------------------------
struct Vec2 {
    float x, y;
    Vec2(float X = 0, float Y = 0) :x(X), y(Y) {}
    Vec2 operator+(const Vec2& o)const { return Vec2(x + o.x, y + o.y); }
    Vec2 operator-(const Vec2& o)const { return Vec2(x - o.x, y - o.y); }
    Vec2 operator*(float s)const { return Vec2(x * s, y * s); }
};

struct Trail {
    std::vector<Vec2> pts;
    void add(const Vec2& p) {
        pts.push_back(p);
        if (pts.size() > 500) pts.erase(pts.begin());
    }
    void draw(float r, float g, float b) {
        glColor3f(r, g, b);
        glBegin(GL_LINE_STRIP);
        for (auto& p : pts) glVertex2f(p.x, p.y);
        glEnd();
    }
};

struct Entity {
    Vec2 pos, vel;
    float heading;
    Trail trail;
    void addTrail() { trail.add(pos); }
};

Entity target, missile;

// ---------------------------- �V�~�����[�V������� ----------------------------
enum SimState { RUNNING, HIT, LOST };
SimState simState = RUNNING;
float lostTimer = 0.0f;

// ---------------------------- ���[�e�B���e�B ----------------------------
float frand(float a, float b) { return a + (b - a) * (rand() / (float)RAND_MAX); }
float wrapAngle(float a) { while (a > M_PI) a -= 2 * M_PI; while (a < -M_PI) a += 2 * M_PI; return a; }
float clamp(float v, float mn, float mx) { return (v < mn ? mn : (v > mx ? mx : v)); }


void initSimulation();

// ---------------------------- �^�[�Q�b�g�X�V ----------------------------
void updateTarget(float dt) {
    static float tAccum = 0.0f;
    tAccum += dt;

    float dHeading = 0.6f * sin(0.7f * tAccum) + 0.4f * sin(1.3f * tAccum + 2.0f);

    // �[�ɋ߂Â�����U�^�[��
    float marginX = WORLD_X * 0.85f, marginY = WORLD_Y * 0.85f;
    if (target.pos.x > marginX) dHeading += 1.5f;
    if (target.pos.x < -marginX) dHeading += -1.5f;
    if (target.pos.y > marginY) dHeading += -1.5f;
    if (target.pos.y < -marginY) dHeading += 1.5f;

    dHeading = clamp(dHeading, -TARGET_MAX_TURN_RATE, TARGET_MAX_TURN_RATE);
    target.heading = wrapAngle(target.heading + dHeading * dt);
    target.vel = Vec2(cos(target.heading), sin(target.heading)) * TARGET_SPEED;
    target.pos = target.pos + target.vel * dt;
    target.addTrail();
}

// ---------------------------- �~�T�C���X�V ----------------------------
void updateMissile(float dt) {
    // �� 0.5�b��̃^�[�Q�b�g�\���ʒu���v�Z ��
    // predictTime �b��̃^�[�Q�b�g�ʒu��P���ɒ����^���ŗ\��
    float predictTime = 0.5f;
    Vec2 futurePos = target.pos + target.vel * predictTime;

    // �~�T�C������\���ʒu�ւ̑��΃x�N�g��
    float dx = futurePos.x - missile.pos.x;
    float dy = futurePos.y - missile.pos.y;

    // �ڕW�p�x�i�\���ʒu�������j
    float desired = atan2(dy, dx);

    // ���݂̌����Ƃ̊p���� -��..�� �Ɋۂ߂�
    float diff = wrapAngle(desired - missile.heading);

    // 1�t���[���Ő���ł���ő�p�x�Ő����i���炩�Ȑ���j
    diff = clamp(diff, -MISSILE_TURN_RATE * dt, MISSILE_TURN_RATE * dt);

    // �~�T�C���̌������X�V�i�ēx wrap �ň��艻�j
    missile.heading = wrapAngle(missile.heading + diff);

    // �~�T�C���̑��x�x�N�g�����X�V�i�����ɉ����j
    missile.vel = Vec2(cos(missile.heading), sin(missile.heading)) * MISSILE_SPEED;

    // �ʒu���X�V
    missile.pos = missile.pos + missile.vel * dt;

    // �O�Ղ�p�[�e�B�N���̉��o
    missile.addTrail();
}


// ---------------------------- �V�~�����[�V�����X�V ----------------------------
void updateSimulation(float dt) {
    if (simState != RUNNING) return;

    updateTarget(dt);
    updateMissile(dt);

    float dx = target.pos.x - missile.pos.x;
    float dy = target.pos.y - missile.pos.y;
    float dist = sqrt(dx * dx + dy * dy);

    if (dist < MISSILE_HIT_DIST) {
        simState = HIT;
        std::cout << "����!\n";
        glutTimerFunc(1000, [](int) { initSimulation(); }, 0);
        return;
    }
    if (dist > MISSILE_LOST_DIST) {
        lostTimer += dt;
        if (lostTimer > MISSILE_LOST_TIME) {
            simState = LOST;
            std::cout << "�U��؂萬��!\n";
            glutTimerFunc(1000, [](int) { initSimulation(); }, 0);
            return;
        }
    }
    else {
        lostTimer = 0.0f;
    }
}

// ---------------------------- ������ ----------------------------
void initSimulation() {
    simState = RUNNING;
    lostTimer = 0.0f;

    target.pos = Vec2(frand(-200, 200), frand(-100, 100));
    target.heading = frand(-M_PI, M_PI);
    target.vel = Vec2(cos(target.heading), sin(target.heading)) * TARGET_SPEED;
    target.trail.pts.clear();

    missile.pos = Vec2(0, -200);
    missile.heading = 0.0f;
    missile.vel = Vec2(cos(missile.heading), sin(missile.heading)) * MISSILE_SPEED;
    missile.trail.pts.clear();
}

// ---------------------------- �`�� ----------------------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // �O��
    target.trail.draw(0.0f, 1.0f, 0.0f);
    missile.trail.draw(1.0f, 0.0f, 0.0f);

    // �퓬�@
    glPushMatrix();
    glTranslatef(target.pos.x, target.pos.y, 0);
    glRotatef(target.heading * 180.0 / M_PI, 0, 0, 1);
    glColor3f(0, 1, 0);
    glBegin(GL_TRIANGLES);
    glVertex2f(15, 0); glVertex2f(-10, 7); glVertex2f(-10, -7);
    glEnd();
    glPopMatrix();

    // �~�T�C��
    glPushMatrix();
    glTranslatef(missile.pos.x, missile.pos.y, 0);
    glRotatef(missile.heading * 180.0 / M_PI, 0, 0, 1);
    glColor3f(1, 0, 0);
    glBegin(GL_TRIANGLES);
    glVertex2f(12, 0); glVertex2f(-8, 5); glVertex2f(-8, -5);
    glEnd();
    glPopMatrix();

    glutSwapBuffers();
}

// ---------------------------- �^�C�}�[ ----------------------------
void timer(int) {
    if (simState == RUNNING) updateSimulation(DT);
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

// ---------------------------- ���C�� ----------------------------
int main(int argc, char** argv) {
    srand((unsigned)time(NULL));
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("�M���ǔ��~�T�C���̃V�~�����[�V�����i�O�D�T�b���\�����ē��Ăɂ����j");
    glClearColor(0, 0, 0, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-WORLD_X, WORLD_X, -WORLD_Y, WORLD_Y);

    initSimulation();
    glutDisplayFunc(display);
    glutTimerFunc(16, timer, 0);
    glutMainLoop();
    return 0;
}
