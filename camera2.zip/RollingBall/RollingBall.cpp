﻿//==============================================================
// 2つのキャラクターを常に画面内に収めるカメラ
//
// キャラクターはXZ平面上を移動する
//
// Visual Studio + freeglut
//
// 青い球：WASD
// 赤い球：カーソルキー
// ESC    ：終了
//==============================================================
#define NOMINMAX
#include <windows.h>
#include <GL/freeglut.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <algorithm>

//==============================================================
// 定数
//==============================================================

const int WINDOW_WIDTH = 1280;
const int WINDOW_HEIGHT = 720;

const float PI = 3.14159265358979323846f;

// アスペクト比
float aspectRatio =
static_cast<float>(WINDOW_WIDTH) /
static_cast<float>(WINDOW_HEIGHT);

// カメラの縦方向の画角
const float VERTICAL_FOV_DEG = 60.0f;

// キャラクターの半径
const float CHARACTER_RADIUS = 1.0f;

// キャラクターが画面端に近づきすぎないための余白
const float CAMERA_MARGIN = 1.5f;

// カメラが近づきすぎないための最低距離
const float MIN_CAMERA_DISTANCE = 6.0f;

// カメラの補間速度
const float CAMERA_SMOOTH_SPEED = 5.0f;

// キャラクターの移動速度
const float CHARACTER_MOVE_SPEED = 5.0f;

// 固定フレームレート
const int FPS = 60;

//==============================================================
// 3次元ベクトル
//==============================================================

struct Vector3
{
    float x;
    float y;
    float z;
};

//==============================================================
// キャラクター
//==============================================================

struct Character
{
    Vector3 position;

    float red;
    float green;
    float blue;
};

//==============================================================
// グローバル変数
//==============================================================

// 青いキャラクター
Character playerA =
{
    { -3.0f, 0.0f, 0.0f },
    0.2f, 0.5f, 1.0f
};

// 赤いキャラクター
Character playerB =
{
    { 3.0f, 0.0f, 0.0f },
    1.0f, 0.3f, 0.2f
};

// 現在のカメラ注視点
Vector3 cameraTarget =
{
    0.0f,
    0.0f,
    0.0f
};

// 現在のカメラ距離
float cameraDistance = 10.0f;

//==============================================================
// キー入力
//==============================================================

bool keyW = false;
bool keyA = false;
bool keyS = false;
bool keyD = false;

bool keyLeft = false;
bool keyRight = false;
bool keyUp = false;
bool keyDown = false;

//==============================================================
// 角度をラジアンに変換
//==============================================================

float DegreeToRadian(float degree)
{
    return degree * PI / 180.0f;
}

//==============================================================
// ９．線形補間
//==============================================================

float Lerp(float start, float end, float t)
{
    return start + (end - start) * t;
}

//==============================================================
// カメラに必要な距離を求める
//==============================================================

float CalculateRequiredCameraDistance()
{
    //----------------------------------------------------------
    // 1.  縦方向の半画角(verticalHalfFov)を求める
    //----------------------------------------------------------

    float verticalHalfFov =
        DegreeToRadian(
            VERTICAL_FOV_DEG * 0.5f
        );

    //----------------------------------------------------------
    // 2. 水平方向の半画角(horizontalHalfFov)を求める
    //    アスペクト比は aspectRatioとして定義済
    //
    // 水平半画角
    // ＝ arctan(tan(垂直半画角) × アスペクト比)
    //----------------------------------------------------------

    float horizontalHalfFov =
        std::atan(
            std::tan(verticalHalfFov) *
            aspectRatio
        );

    //----------------------------------------------------------
    // 3. 2体のX方向の距離(differenceX)とZ方向の距離(differenceZ)を求める
    //　それぞれの座標は　playerA.position.x  playerA.position.z
    //                    playerB.position.x  playerB.position.z
    // 
    // X方向：画面の横方向
    // Z方向：画面の縦方向
    //----------------------------------------------------------

    float differenceX =
        std::fabs(
            playerB.position.x -
            playerA.position.x
        );

    float differenceZ =
        std::fabs(
            playerB.position.z -
            playerA.position.z
        );

    //----------------------------------------------------------
    // 4. 
    //    X方向の距離(differenceX)と画面の縦方向(differenceZ)と
    //   キャラクターの半径 (CHARACTER_RADIUS )と 
    // 　キャラクターが画面端に近づきすぎないための余白(CAMERA_MARGIN)
    // 　から画面内に必要な半幅(requiredHalfWidth)と半高さ(requiredHalfHeight)を求める
    //----------------------------------------------------------

    float requiredHalfWidth =
        differenceX * 0.5f +
        CHARACTER_RADIUS +
        CAMERA_MARGIN;

    float requiredHalfHeight =
        differenceZ * 0.5f +
        CHARACTER_RADIUS +
        CAMERA_MARGIN;

    //----------------------------------------------------------
    // 5. 横方向から必要なカメラ距離(distanceFromHorizontal)を求める
    //----------------------------------------------------------

    float distanceFromHorizontal =
        requiredHalfWidth /
        std::tan(horizontalHalfFov);

    //----------------------------------------------------------
    // 6. 縦方向から必要なカメラ距離(distanceFromVertical)を求める
    //----------------------------------------------------------

    float distanceFromVertical =
        requiredHalfHeight /
        std::tan(verticalHalfFov);

    //----------------------------------------------------------
    // 7. 横方向と縦方向のうち、大きい距離を採用する
    //----------------------------------------------------------

    float requiredDistance =
        std::max(
            distanceFromHorizontal,
            distanceFromVertical
        );

    //----------------------------------------------------------
    // 8. 最低距離(MIN_CAMERA_DISTANCE)より近づかないようにする
    //----------------------------------------------------------

    requiredDistance =
        std::max(
            requiredDistance,
            MIN_CAMERA_DISTANCE
        );

    return requiredDistance;
}

//==============================================================
// キャラクターを移動させる
//==============================================================

void UpdateCharacters(float deltaTime)
{
    //----------------------------------------------------------
    // 青いキャラクター
    //----------------------------------------------------------

    Vector3 directionA =
    {
        0.0f,
        0.0f,
        0.0f
    };

    //----------------------------------------------------------
    // A・DキーでX方向に移動
    //----------------------------------------------------------

    if (keyA)
    {
        directionA.x -= 1.0f;
    }

    if (keyD)
    {
        directionA.x += 1.0f;
    }

    //----------------------------------------------------------
    // W・SキーでZ方向に移動
    //
    // 現在のカメラでは、
    // Zのマイナス方向が画面上側になる
    //----------------------------------------------------------

    if (keyW)
    {
        directionA.z -= 1.0f;
    }

    if (keyS)
    {
        directionA.z += 1.0f;
    }

    //----------------------------------------------------------
    // 斜め移動が速くならないように正規化
    //----------------------------------------------------------

    float lengthA =
        std::sqrt(
            directionA.x * directionA.x +
            directionA.z * directionA.z
        );

    if (lengthA > 0.0001f)
    {
        directionA.x /= lengthA;
        directionA.z /= lengthA;
    }

    //----------------------------------------------------------
    // XZ平面上を移動させる
    //----------------------------------------------------------

    playerA.position.x +=
        directionA.x *
        CHARACTER_MOVE_SPEED *
        deltaTime;

    playerA.position.z +=
        directionA.z *
        CHARACTER_MOVE_SPEED *
        deltaTime;

    //----------------------------------------------------------
    // 赤いキャラクター
    //----------------------------------------------------------

    Vector3 directionB =
    {
        0.0f,
        0.0f,
        0.0f
    };

    //----------------------------------------------------------
    // 左右キーでX方向に移動
    //----------------------------------------------------------

    if (keyLeft)
    {
        directionB.x -= 1.0f;
    }

    if (keyRight)
    {
        directionB.x += 1.0f;
    }

    //----------------------------------------------------------
    // 上下キーでZ方向に移動
    //----------------------------------------------------------

    if (keyUp)
    {
        directionB.z -= 1.0f;
    }

    if (keyDown)
    {
        directionB.z += 1.0f;
    }

    //----------------------------------------------------------
    // 斜め移動が速くならないように正規化
    //----------------------------------------------------------

    float lengthB =
        std::sqrt(
            directionB.x * directionB.x +
            directionB.z * directionB.z
        );

    if (lengthB > 0.0001f)
    {
        directionB.x /= lengthB;
        directionB.z /= lengthB;
    }

    //----------------------------------------------------------
    // XZ平面上を移動させる
    //----------------------------------------------------------

    playerB.position.x +=
        directionB.x *
        CHARACTER_MOVE_SPEED *
        deltaTime;

    playerB.position.z +=
        directionB.z *
        CHARACTER_MOVE_SPEED *
        deltaTime;
}

//==============================================================
// カメラを更新する
//==============================================================

void UpdateCamera(float deltaTime)
{
    //----------------------------------------------------------
    // 2体の中間地点を求める
    //----------------------------------------------------------

    Vector3 desiredTarget =
    {
        (playerA.position.x + playerB.position.x) * 0.5f,

        0.0f,

        (playerA.position.z + playerB.position.z) * 0.5f
    };

    //----------------------------------------------------------
    // 2体を画面内に収めるための距離を求める
    //----------------------------------------------------------

    float desiredDistance =
        CalculateRequiredCameraDistance();

    //----------------------------------------------------------
    // フレームレートに依存しにくい補間係数
    //----------------------------------------------------------

    float interpolation =
        1.0f -
        std::exp(
            -CAMERA_SMOOTH_SPEED *
            deltaTime
        );

    //----------------------------------------------------------
    // 注視点を滑らかに移動
    //----------------------------------------------------------

    cameraTarget.x =
        Lerp(
            cameraTarget.x,
            desiredTarget.x,
            interpolation
        );

    cameraTarget.y =
        Lerp(
            cameraTarget.y,
            desiredTarget.y,
            interpolation
        );

    cameraTarget.z =
        Lerp(
            cameraTarget.z,
            desiredTarget.z,
            interpolation
        );

    //----------------------------------------------------------
    // カメラ距離を滑らかに変更
    //----------------------------------------------------------

    cameraDistance =
        Lerp(
            cameraDistance,
            desiredDistance,
            interpolation
        );
}

//==============================================================
// キャラクターを描画する
//==============================================================

void DrawCharacter(const Character& character)
{
    glPushMatrix();

    glTranslatef(
        character.position.x,
        character.position.y,
        character.position.z
    );

    glColor3f(
        character.red,
        character.green,
        character.blue
    );

    glutSolidSphere(
        CHARACTER_RADIUS,
        32,
        32
    );

    glPopMatrix();
}

//==============================================================
// XZ平面上に背景グリッドを描画する
//==============================================================

void DrawGrid()
{
    glDisable(GL_LIGHTING);

    glColor3f(
        0.85f,
        0.85f,
        0.85f
    );

    glBegin(GL_LINES);

    const int GRID_SIZE = 30;

    for (int i = -GRID_SIZE; i <= GRID_SIZE; i++)
    {
        //------------------------------------------------------
        // X方向に伸びる線
        //------------------------------------------------------

        glVertex3f(
            static_cast<float>(-GRID_SIZE),
            -1.1f,
            static_cast<float>(i)
        );

        glVertex3f(
            static_cast<float>(GRID_SIZE),
            -1.1f,
            static_cast<float>(i)
        );

        //------------------------------------------------------
        // Z方向に伸びる線
        //------------------------------------------------------

        glVertex3f(
            static_cast<float>(i),
            -1.1f,
            static_cast<float>(-GRID_SIZE)
        );

        glVertex3f(
            static_cast<float>(i),
            -1.1f,
            static_cast<float>(GRID_SIZE)
        );
    }

    glEnd();

    glEnable(GL_LIGHTING);
}

//==============================================================
// 文字列を描画する
//==============================================================

void DrawString(float x, float y, const char* text)
{
    glRasterPos2f(x, y);

    while (*text != '\0')
    {
        glutBitmapCharacter(
            GLUT_BITMAP_9_BY_15,
            *text
        );

        text++;
    }
}

//==============================================================
// 画面上に情報を表示する
//==============================================================

void DrawInformation()
{
    //----------------------------------------------------------
    // 3D描画用の設定を一時保存
    //----------------------------------------------------------

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();

    glLoadIdentity();

    gluOrtho2D(
        0.0,
        static_cast<double>(WINDOW_WIDTH),
        0.0,
        static_cast<double>(WINDOW_HEIGHT)
    );

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    glLoadIdentity();

    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);

    glColor3f(
        0.1f,
        0.1f,
        0.1f
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 30.0f,
        "Blue : W A S D"
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 50.0f,
        "Red  : Arrow Keys"
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 70.0f,
        "ESC  : Exit"
    );

    char buffer[128];

    std::snprintf(
        buffer,
        sizeof(buffer),
        "Camera Distance : %.2f",
        cameraDistance
    );

    DrawString(
        20.0f,
        WINDOW_HEIGHT - 100.0f,
        buffer
    );

    //----------------------------------------------------------
    // 元の描画設定に戻す
    //----------------------------------------------------------

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);

    glPopMatrix();

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    glMatrixMode(GL_MODELVIEW);
}

//==============================================================
// 描画
//==============================================================

void Display()
{
    glClear(
        GL_COLOR_BUFFER_BIT |
        GL_DEPTH_BUFFER_BIT
    );

    //----------------------------------------------------------
    // 透視投影
    //----------------------------------------------------------

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(
        VERTICAL_FOV_DEG,
        aspectRatio,
        0.1,
        500.0
    );

    //----------------------------------------------------------
    // カメラ
    //----------------------------------------------------------

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    //----------------------------------------------------------
    // XZ平面を真上から見下ろす
    //
    // カメラ位置：
    //     (targetX, cameraDistance, targetZ)
    //
    // 注視点：
    //     (targetX, 0, targetZ)
    //
    // カメラの上方向：
    //     Zのマイナス方向
    //----------------------------------------------------------

    gluLookAt(
        cameraTarget.x,
        cameraDistance,
        cameraTarget.z,

        cameraTarget.x,
        cameraTarget.y,
        cameraTarget.z,

        0.0f,
        0.0f,
        -1.0f
    );

    //----------------------------------------------------------
    // ライト
    //----------------------------------------------------------

    GLfloat lightPosition[] =
    {
        0.0f,
        20.0f,
        10.0f,
        1.0f
    };

    glLightfv(
        GL_LIGHT0,
        GL_POSITION,
        lightPosition
    );

    //----------------------------------------------------------
    // 描画
    //----------------------------------------------------------

    DrawGrid();

    DrawCharacter(playerA);
    DrawCharacter(playerB);

    DrawInformation();

    glutSwapBuffers();
}

//==============================================================
// ウィンドウサイズ変更
//==============================================================

void Reshape(int width, int height)
{
    if (height <= 0)
    {
        height = 1;
    }

    glViewport(
        0,
        0,
        width,
        height
    );

    aspectRatio =
        static_cast<float>(width) /
        static_cast<float>(height);
}

//==============================================================
// 通常キーを押した
//==============================================================

void KeyboardDown(
    unsigned char key,
    int,
    int
)
{
    switch (key)
    {
    case 'w':
    case 'W':
        keyW = true;
        break;

    case 'a':
    case 'A':
        keyA = true;
        break;

    case 's':
    case 'S':
        keyS = true;
        break;

    case 'd':
    case 'D':
        keyD = true;
        break;

    case 27:
        glutLeaveMainLoop();
        break;
    }
}

//==============================================================
// 通常キーを離した
//==============================================================

void KeyboardUp(
    unsigned char key,
    int,
    int
)
{
    switch (key)
    {
    case 'w':
    case 'W':
        keyW = false;
        break;

    case 'a':
    case 'A':
        keyA = false;
        break;

    case 's':
    case 'S':
        keyS = false;
        break;

    case 'd':
    case 'D':
        keyD = false;
        break;
    }
}

//==============================================================
// 特殊キーを押した
//==============================================================

void SpecialKeyDown(
    int key,
    int,
    int
)
{
    switch (key)
    {
    case GLUT_KEY_LEFT:
        keyLeft = true;
        break;

    case GLUT_KEY_RIGHT:
        keyRight = true;
        break;

    case GLUT_KEY_UP:
        keyUp = true;
        break;

    case GLUT_KEY_DOWN:
        keyDown = true;
        break;
    }
}

//==============================================================
// 特殊キーを離した
//==============================================================

void SpecialKeyUp(
    int key,
    int,
    int
)
{
    switch (key)
    {
    case GLUT_KEY_LEFT:
        keyLeft = false;
        break;

    case GLUT_KEY_RIGHT:
        keyRight = false;
        break;

    case GLUT_KEY_UP:
        keyUp = false;
        break;

    case GLUT_KEY_DOWN:
        keyDown = false;
        break;
    }
}

//==============================================================
// 更新処理
//==============================================================

void Timer(int)
{
    const float deltaTime =
        1.0f /
        static_cast<float>(FPS);

    UpdateCharacters(deltaTime);
    UpdateCamera(deltaTime);

    glutPostRedisplay();

    glutTimerFunc(
        1000 / FPS,
        Timer,
        0
    );
}

//==============================================================
// OpenGL初期化
//==============================================================

void Initialize()
{
    //----------------------------------------------------------
    // 背景色
    //----------------------------------------------------------

    glClearColor(
        1.0f,
        1.0f,
        1.0f,
        1.0f
    );

    //----------------------------------------------------------
    // 深度テスト
    //----------------------------------------------------------

    glEnable(GL_DEPTH_TEST);

    //----------------------------------------------------------
    // ライティング
    //----------------------------------------------------------

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    //----------------------------------------------------------
    // glColor3fの色をマテリアルとして使用する
    //----------------------------------------------------------

    glEnable(GL_COLOR_MATERIAL);

    glColorMaterial(
        GL_FRONT_AND_BACK,
        GL_AMBIENT_AND_DIFFUSE
    );

    //----------------------------------------------------------
    // スムーズシェーディング
    //----------------------------------------------------------

    glShadeModel(GL_SMOOTH);

    //----------------------------------------------------------
    // キーリピートを無効にする
    //----------------------------------------------------------

    glutIgnoreKeyRepeat(GL_TRUE);
}

//==============================================================
// メイン関数
//==============================================================

int main(int argc, char** argv)
{
    glutInit(&argc, argv);

    glutInitDisplayMode(
        GLUT_DOUBLE |
        GLUT_RGBA |
        GLUT_DEPTH
    );

    glutInitWindowSize(
        WINDOW_WIDTH,
        WINDOW_HEIGHT
    );

    glutCreateWindow(
        "２つのキャラクターをどちらも画面内に収めるカメラ"
    );

    Initialize();

    glutDisplayFunc(Display);
    glutReshapeFunc(Reshape);

    glutKeyboardFunc(KeyboardDown);
    glutKeyboardUpFunc(KeyboardUp);

    glutSpecialFunc(SpecialKeyDown);
    glutSpecialUpFunc(SpecialKeyUp);

    glutTimerFunc(
        1000 / FPS,
        Timer,
        0
    );

    glutMainLoop();

    return 0;
}