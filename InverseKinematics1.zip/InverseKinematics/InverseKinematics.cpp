﻿#include <GL/glut.h>
#include <cmath>
#include <cstdio>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

const int WIN_W = 800;
const int WIN_H = 600;

const double L1 = 160.0;
const double L2 = 120.0;

double theta1 = 0.3;
double theta2 = 0.3;

double targetX = 200.0;
double targetY = 100.0;

bool targetLocked = false;
bool elbowDown = true;

inline double clamp(double v, double lo, double hi) {
    return (v < lo) ? lo : (v > hi) ? hi : v;
}



void solveIK_analytical(double tx, double ty, bool elbowDownFlag) {

    // --------------------------------------------------
    // STEP 0
    // 目標までのX方向・Y方向の差
    // 今回はアームの根元が(0,0)なので、
    // tx,tyがそのままdx,dyになる
    // --------------------------------------------------

    double dx = tx;
    double dy = ty;


    // --------------------------------------------------
    // STEP 1
    // 根元から目標までの距離 d を求める
    //
    // --------------------------------------------------

    double d = 1.0;       // ← ★ここを書き換える


    // --------------------------------------------------
    // STEP 2
    // とりあえず目標の方向を向かせる
    //
    // atan2(dy,dx) を使うと
    // 原点から目標への角度を求められる
    // --------------------------------------------------

    double ang = std::atan2(dy, dx);

    theta1 = ang;

    // 最初は肘を曲げない
    theta2 = 0.0;


    // --------------------------------------------------
    // STEP 3
    // アームが届く最大距離・最小距離を求める
    //
    // ★穴②
    // L1とL2を使って最大距離を求めてください
    // --------------------------------------------------

    double maxReach = 9999.0;       // ← ★ここを書き換える
    double minReach = 0.0;          // ← ★ここを書き換える


    // --------------------------------------------------
    // STEP 4
    // 目標が遠すぎる場合
    //
    // ★穴③
    // dとmaxReachを比較してください
    // --------------------------------------------------

    if (false) {                    // ← ★ここを書き換える

        // 届かないので目標方向へまっすぐ伸ばす
        theta1 = ang;
        theta2 = 0.0;

        return;
    }

    // --------------------------------------------------
    // STEP 5
    // 目標が遠すぎる場合
    //
    // ★穴③
    // dとmaxReachを比較してください
    // --------------------------------------------------

    if (false) {                   // ★ここを書き換える

        theta1 = ang;

        // 肘を完全に折りたたむ
        theta2 = M_PI;

        return;
    }

    // --------------------------------------------------
    // STEP 6
    // ここから本格的なIK
    //
    // 余弦定理から
    //
    // cos(theta2)
    //
    // を求める
    //
    // ★穴④
    // 下の0.0を余弦定理の式に置き換えてください
    // --------------------------------------------------

    double cos_theta2 = 0.0;        // ← ★ここを書き換える


    // acosに渡せる範囲は -1 ～ +1
    cos_theta2 = clamp(cos_theta2, -1.0, 1.0);


    // --------------------------------------------------
    // STEP 7
    // cos(theta2)から実際の角度theta2を求める
    //
    // ★穴⑤
    // 逆余弦 acos を使ってください
    // --------------------------------------------------

    double th2 = 0.0;                // ← ★ここを書き換える


    // --------------------------------------------------
    // STEP 8
    // 肘を反対側へ曲げられるようにする
    //
    // ★穴⑥
    // elbowDownFlagがfalseなら
    // th2の正負を反転してください
    // --------------------------------------------------

    // ★ここに処理を追加する


    // --------------------------------------------------
    // STEP 9
    // 肩の角度を求めるための補助値
    //
    // ★穴⑦
    //
    // k1 = L1 + L2 cos(th2)
    // k2 =      L2 sin(th2)
    //
    // --------------------------------------------------

    double k1 = L1;                // ← ★ここを書き換える
    double k2 = 0.0;               // ← ★ここを書き換える


    // --------------------------------------------------
    // STEP 10
    // 最後に肩の角度を補正する
    //
    // 現在のangは単純に
    //
    // 「目標そのものの方向」
    //
    // になっている。
    //
    // ★穴⑧
    //
    // atan2(k2,k1)を利用して
    // 正しい肩角度th1を求めてください
    // --------------------------------------------------

    double th1 = ang;              // ← ★ここを書き換える


    // --------------------------------------------------
    // 求めた角度を実際の関節角度へ反映
    // --------------------------------------------------

    theta1 = th1;
    theta2 = th2;

}




void windowToWorld(int wx, int wy, double& outX, double& outY) {
    outX = wx - WIN_W / 2.0;
    outY = (WIN_H - wy) - WIN_H / 2.0;
}

void drawCircle(double x, double y, double r, int segments = 24) {
    glBegin(GL_POLYGON);
    for (int i = 0; i < segments; ++i) {
        double a = (2.0 * M_PI * i) / segments;
        glVertex2d(x + std::cos(a) * r, y + std::sin(a) * r);
    }
    glEnd();
}

void drawCross(double x, double y, double s = 8.0) {
    glBegin(GL_LINES);
    glVertex2d(x - s, y);
    glVertex2d(x + s, y);
    glVertex2d(x, y - s);
    glVertex2d(x, y + s);
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    solveIK_analytical(targetX, targetY, elbowDown);

    double x0 = 0.0, y0 = 0.0;
    double x1 = x0 + L1 * std::cos(theta1);
    double y1 = y0 + L1 * std::sin(theta1);
    double x2 = x1 + L2 * std::cos(theta1 + theta2);
    double y2 = y1 + L2 * std::sin(theta1 + theta2);

    glPushMatrix();
    glTranslatef(WIN_W / 2.0f, WIN_H / 2.0f, 0.0f);

    // グリッド（細い線）
    glColor3f(0.85f, 0.85f, 0.85f);
    glLineWidth(1.0f);
    glBegin(GL_LINES);
    for (int i = -WIN_W / 2; i <= WIN_W / 2; i += 40) {
        glVertex2i(i, -WIN_H / 2); glVertex2i(i, WIN_H / 2);
    }
    for (int j = -WIN_H / 2; j <= WIN_H / 2; j += 40) {
        glVertex2i(-WIN_W / 2, j); glVertex2i(WIN_W / 2, j);
    }
    glEnd();

    glColor3f(1.0f, 0.0f, 0.0f);
    drawCross(targetX, targetY, 8.0);

    glLineWidth(8.0f);
    glColor3f(0.2f, 0.6f, 1.0f);
    glBegin(GL_LINES);
    glVertex2d(x0, y0);
    glVertex2d(x1, y1);
    glEnd();

    glColor3f(0.1f, 0.1f, 0.1f);
    drawCircle(x0, y0, 10.0);

    glLineWidth(8.0f);
    glColor3f(0.2f, 1.0f, 0.4f);
    glBegin(GL_LINES);
    glVertex2d(x1, y1);
    glVertex2d(x2, y2);
    glEnd();

    glColor3f(0.1f, 0.1f, 0.1f);
    drawCircle(x1, y1, 8.0);

    glColor3f(0.0f, 0.0f, 0.0f);
    drawCircle(x2, y2, 6.0);

    glColor3f(0.0f, 0.0f, 0.0f);
    char buf[128];
    std::snprintf(buf, sizeof(buf), "th1: %.1f deg\nth2: %.1f deg", theta1 * 180.0 / M_PI, theta2 * 180.0 / M_PI);

    glRasterPos2f(-WIN_W / 2 + 8, WIN_H / 2 - 20);
    for (char* p = buf; *p; ++p) {
        if (*p == '\n') {
            glRasterPos2f(-WIN_W / 2 + 8, WIN_H / 2 - 36);
            continue;
        }
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *p);
    }

    glPopMatrix();

    glutSwapBuffers();
}

void reshape(int w, int h) {
    glViewport(0, 0, WIN_W, WIN_H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, WIN_W, 0, WIN_H, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void passiveMotion(int x, int y) {
    if (targetLocked) return;
    windowToWorld(x, y, targetX, targetY);
    glutPostRedisplay();
}

void mouseFunc(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        targetLocked = !targetLocked;
        windowToWorld(x, y, targetX, targetY);
        glutPostRedisplay();
    }
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case 0x1b:
        std::exit(0);
        break;
    case 'r':
    case 'R':
        theta1 = 0.3; theta2 = 0.3;
        targetX = 200; targetY = 100;
        glutPostRedisplay();
        break;
    case 'e':
    case 'E':
        elbowDown = !elbowDown;
        glutPostRedisplay();
        break;
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("インバース キネマティクス（２Link）");

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutPassiveMotionFunc(passiveMotion);
    glutMouseFunc(mouseFunc);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}