#include <GL/glut.h>
#include <cmath>
#include <cstdlib>
#include <ctime>

#define M_PI 3.14159265358979

// �E�B���h�E�T�C�Y
const int WIN_W = 800, WIN_H = 600;

// ���̃p�����[�^
float ballX = 0.0f, ballZ = 0.0f;
float ballVx = 0.0f, ballVz = 0.0f; // �����x�͏��������ɐݒ�
float ballRadius = 0.5f;
float ballAngle = 0.0f;
float rotAxisX = 0.0f, rotAxisY = 0.0f, rotAxisZ = 1.0f;

// ���C
const float mu = 0.002f; // �ɂ₩�Ɍ���
const float g = 9.8f;
float speedThreshold = 0.002f;

// ��
float floorSize = 10.0f;

// �������֐��i����ƍăX�^�[�g�ŋ��ʁj
void resetBall() {
    ballX = ((float)rand() / RAND_MAX - 0.5f) * (floorSize - 2 * ballRadius);
    ballZ = ((float)rand() / RAND_MAX - 0.5f) * (floorSize - 2 * ballRadius);

    // �����x�͖��񓯂��͈�
    ballVx = ((float)rand() / RAND_MAX - 0.5f) * 0.15f;
    ballVz = ((float)rand() / RAND_MAX - 0.5f) * 0.15f;

    ballAngle = 0.0f;
    rotAxisX = 0.0f; rotAxisY = 0.0f; rotAxisZ = 1.0f;
}

// �X�V
void update() {
    float v = sqrt(ballVx * ballVx + ballVz * ballVz);

    if (v > 1e-6f) {
        // ��]��
        rotAxisX = ballVz / v;
        rotAxisY = 0.0f;
        rotAxisZ = -ballVx / v;

        // ��]�p�X�V
        ballAngle += v / ballRadius;

        // ���C�ɂ�錸��
        float a = mu * g;
        float dt = 0.016f;
        float dv = a * dt;
        if (dv > v) dv = v;
        float factor = (v - dv) / v;
        ballVx *= factor;
        ballVz *= factor;
    }

    // �ʒu�X�V
    ballX += ballVx;
    ballZ += ballVz;

    // �ǂŔ���
    float limit = floorSize / 2 - ballRadius;
    if (ballX > limit || ballX < -limit) ballVx *= -1;
    if (ballZ > limit || ballZ < -limit) ballVz *= -1;

    // ��~���� & �����ăX�^�[�g
    v = sqrt(ballVx * ballVx + ballVz * ballVz);
    if (v < speedThreshold) {
        resetBall();
    }
}

// �`��
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(5, 5, 8, 0, 0, 0, 0, 1, 0);

    // ��
    glColor3f(0.8f, 0.8f, 0.8f);
    glBegin(GL_QUADS);
    glVertex3f(-floorSize / 2, 0, -floorSize / 2);
    glVertex3f(floorSize / 2, 0, -floorSize / 2);
    glVertex3f(floorSize / 2, 0, floorSize / 2);
    glVertex3f(-floorSize / 2, 0, floorSize / 2);
    glEnd();

    // ��
    glPushMatrix();
    glTranslatef(ballX, ballRadius, ballZ);
    glRotatef(ballAngle * 180.0 / M_PI, rotAxisX, rotAxisY, rotAxisZ);

    // ���̋�
    glColor3f(0.2f, 0.6f, 1.0f);
    glutSolidSphere(ballRadius, 24, 24);

    // ���C���[�t���[��
    glColor3f(0.9f, 0.9f, 0.1f);
    glutWireSphere(ballRadius * 1.001f, 24, 24);

    glPopMatrix();

    glutSwapBuffers();
}

// �^�C�}�[
void timer(int) {
    update();
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

// ���T�C�Y
void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)w / h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

// ���C��
int main(int argc, char** argv) {
    srand((unsigned int)time(nullptr));

    resetBall(); // ���񏉑��x�ݒ�

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("�{�[�����낪���R�c�i�����v�Z�Łj");

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.9f, 0.9f, 0.9f, 1.0f);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(16, timer, 0);

    glutMainLoop();
    return 0;
}
