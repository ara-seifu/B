﻿#include <GL/glut.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <chrono>

#define M_PI 3.14159265358979323846

using namespace std::chrono;

float ballX, ballY;
float ballVx, ballVy;
float g = -9.8f;

float fielderX = 20.0f;
float theta = 0.0f; // 頂点で固定する角度

bool apexReached = false;
bool ballCaught = false;

steady_clock::time_point lastTime;

// ボール初期化
void resetBall() {
    ballX = -30.0f;
    ballY = 1.0f;
    ballVy = 18.0f + rand() % 5;
    ballVx = 10.0f + rand() % 3;

    apexReached = false;
    ballCaught = false;
    theta = 0.0f;
    fielderX = 20.0f;

    lastTime = steady_clock::now();
}

// 円描画
void drawCircle(float x, float y, float r, float R, float G, float B) {
    glColor3f(R, G, B);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < 64; i++) {
        float th = i * 2.0f * M_PI / 64;
        glVertex2f(x + r * cos(th), y + r * sin(th));
    }
    glEnd();
}

void update() {
    steady_clock::time_point now = steady_clock::now();
    duration<float> elapsed = now - lastTime;
    float dt = elapsed.count();
    lastTime = now;

    if (ballCaught) return;

    // ボール運動
    ballX += ballVx * dt; 
    ballY += ballVy * dt;
    ballVy += g * dt;

    // 頂点判定
    if (!apexReached && ballVy < 0) {
        apexReached = true;
        theta = atan2(ballY, ballX - fielderX); // 頂点で角度固定
    }

    // 地面判定
    if (ballY <= 0) {
        ballY = 0;
        ballVy = 0;
        ballVx = 0;
        ballCaught = true;
        return;
    }

    // 頂点以降の外野手移動
    if (apexReached && !ballCaught) {
        float targetX = ballX - ballY / tan(theta);
        float dx = targetX - fielderX;

        float speedLimit = 15.0f * (1.0f + (15.0f - ballY) / 15.0f);
        if (dx > speedLimit * dt) dx = speedLimit * dt;
        if (dx < -speedLimit * dt) dx = -speedLimit * dt;

        fielderX += dx;
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    update();

    // 地面
    glColor3f(0.2f, 0.6f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(-50, 0); glVertex2f(50, 0);
    glVertex2f(50, -1); glVertex2f(-50, -1);
    glEnd();

    // ボール（白・小さめ・正円）
    drawCircle(ballX, ballY, 0.2f, 1, 1, 1);

    // 外野手（黄色）
    drawCircle(fielderX, 0.5f, 0.5f, 1, 1, 0);

    // 緑の直線
    glColor3f(0, 1, 0);
    glBegin(GL_LINES);
    glVertex2f(fielderX, 1.0f);
    glVertex2f(ballX, ballY);
    glEnd();

    glutSwapBuffers();
}

void timer(int v) { glutPostRedisplay(); glutTimerFunc(16, timer, 0); }
void reshape(int w, int h) { glViewport(0, 0, w, h); glMatrixMode(GL_PROJECTION); glLoadIdentity(); gluOrtho2D(-40, 40, -1, 20); glMatrixMode(GL_MODELVIEW); }
void keyboard(unsigned char key, int x, int y) {
    if (key == ' ') resetBall(); // スペースで再投球
}
void init() { glClearColor(0.2f, 0.4f, 0.8f, 1.0f); srand(time(nullptr)); resetBall(); }

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(1800, 600);
    glutCreateWindow("外野手 頂点角度固定でキャッチ（スペースでリトライ）");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(16, timer, 0);
    glutMainLoop();
    return 0;
}
