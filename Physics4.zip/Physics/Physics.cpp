// ============================================
// STEP 4 : 3D ������(�d�� + �� + �� + �����m�̏Փ�)
// ���S�C���p���X�@�i3D�j
// ============================================

#include <GL/freeglut.h>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <ctime>

// --------------------------------------------
// �Ȉ� 3D �x�N�g��
// --------------------------------------------
struct Vec3 {
    float x, y, z;
    Vec3(float x = 0, float y = 0, float z = 0) : x(x), y(y), z(z) {}

    Vec3 operator+(const Vec3& o) const { return Vec3(x + o.x, y + o.y, z + o.z); }
    Vec3 operator-(const Vec3& o) const { return Vec3(x - o.x, y - o.y, z - o.z); }
    Vec3 operator*(float s) const { return Vec3(x * s, y * s, z * s); }
    Vec3& operator+=(const Vec3& o) { x += o.x; y += o.y; z += o.z; return *this; }
};

float dot(const Vec3& a, const Vec3& b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

Vec3 normalize(const Vec3& v) {
    float len = std::sqrt(dot(v, v));
    if (len == 0) return Vec3(0, 0, 0);
    return Vec3(v.x / len, v.y / len, v.z / len);
}

// --------------------------------------------
// ��
// --------------------------------------------
struct Ball {
    Vec3 pos;    // �ʒu
    Vec3 vel;    // ���x
    float radius;
    float mass;
};

std::vector<Ball> balls;

// --------------------------------------------
float dt = 0.016f;
float gravity = -9.8f;
float restitution = 0.9f;      // ���̒e��
float floorRest = 0.8f;        // ���̒e��
float FLOOR_SIZE = 10.0f;      // �ǁ^���̍L��

// --------------------------------------------
// �J����
// --------------------------------------------
float camAngleX = 30.0f;
float camAngleY = 30.0f;
float camDist = 30.0f;
int prevMX = 0, prevMY = 0;
bool dragging = false;

// --------------------------------------------
// �������F�����_���ɋ���z�u
// --------------------------------------------
void initBalls()
{
    balls.clear();
    balls.resize(5);
    std::srand((unsigned)time(NULL));

    for (int i = 0; i < balls.size(); i++) {
        balls[i].radius = 1.0f;
        balls[i].mass = 1.0f;

        balls[i].pos = Vec3(
            ((rand() / float(RAND_MAX)) - 0.5f) * FLOOR_SIZE,
            5.0f + (rand() / float(RAND_MAX)) * 3,
            ((rand() / float(RAND_MAX)) - 0.5f) * FLOOR_SIZE
        );

        balls[i].vel = Vec3(
            ((rand() / float(RAND_MAX)) - 0.5f) * 5,
            0,
            ((rand() / float(RAND_MAX)) - 0.5f) * 5
        );
    }
}

// --------------------------------------------
// �� vs ��
// --------------------------------------------
void collideFloor(Ball& b)
{
    float bottom = b.pos.y - b.radius;
    if (bottom < 0) {
        b.pos.y = b.radius;
        if (b.vel.y < 0)
            b.vel.y = -b.vel.y * floorRest;

        // ��������
        b.vel.x *= 0.9f;
        b.vel.z *= 0.9f;
    }
}

// --------------------------------------------
// �� vs ��
// --------------------------------------------
void collideWalls(Ball& b)
{
    float r = b.radius;
    float L = FLOOR_SIZE;

    if (b.pos.x > L - r) {
        b.pos.x = L - r;
        if (b.vel.x > 0) b.vel.x = -b.vel.x * floorRest;
    }
    if (b.pos.x < -L + r) {
        b.pos.x = -L + r;
        if (b.vel.x < 0) b.vel.x = -b.vel.x * floorRest;
    }

    if (b.pos.z > L - r) {
        b.pos.z = L - r;
        if (b.vel.z > 0) b.vel.z = -b.vel.z * floorRest;
    }
    if (b.pos.z < -L + r) {
        b.pos.z = -L + r;
        if (b.vel.z < 0) b.vel.z = -b.vel.z * floorRest;
    }
}

// --------------------------------------------
// �� vs ���i3D�C���p���X�j
// --------------------------------------------
void collideBallBall(Ball& a, Ball& b)
{
    Vec3 diff = b.pos - a.pos;
    float dist = std::sqrt(dot(diff, diff));
    float rsum = a.radius + b.radius;

    if (dist < rsum) {
        // �@���x�N�g��
        Vec3 n = normalize(diff);

        // ���Α��x
        Vec3 rv = b.vel - a.vel;
        float relVel = dot(rv, n);

        if (relVel > 0) return;

        // �C���p���X j
        float j = -(1 + restitution) * relVel;
        j /= (1 / a.mass + 1 / b.mass);

        Vec3 impulse = n * j;

        // ���x�C��
        a.vel = a.vel - impulse * (1.0f / a.mass);
        b.vel = b.vel + impulse * (1.0f / b.mass);

        // �߂荞�݉���
        float penetration = rsum - dist;
        Vec3 corr = n * (penetration * 0.5f);
        a.pos = a.pos - corr;
        b.pos = b.pos + corr;
    }
}

// --------------------------------------------
// update
// --------------------------------------------
void update()
{
    for (auto& b : balls) {
        // �d��
        b.vel.y += gravity * dt;

        // �ʒu�X�V
        b.pos += b.vel * dt;

        // ���E��
        collideFloor(b);
        collideWalls(b);
    }

    // �����m
    for (int i = 0; i < balls.size(); i++) {
        for (int j = i + 1; j < balls.size(); j++) {
            collideBallBall(balls[i], balls[j]);
        }
    }
}

// --------------------------------------------
// �`��
// --------------------------------------------
void drawFloor()
{
    glDisable(GL_LIGHTING);
    glColor3f(0.3f, 0.3f, 0.3f);

    glBegin(GL_QUADS);
    glVertex3f(-FLOOR_SIZE, 0, -FLOOR_SIZE);
    glVertex3f(FLOOR_SIZE, 0, -FLOOR_SIZE);
    glVertex3f(FLOOR_SIZE, 0, FLOOR_SIZE);
    glVertex3f(-FLOOR_SIZE, 0, FLOOR_SIZE);
    glEnd();

    glEnable(GL_LIGHTING);
}

void drawBalls()
{
    for (int i = 0; i < balls.size(); i++) {
        float c = i / float(balls.size());

        glColor3f(0.2f + c, 0.5f, 1.0f - c);

        glPushMatrix();
        glTranslatef(balls[i].pos.x, balls[i].pos.y, balls[i].pos.z);
        glutSolidSphere(balls[i].radius, 24, 24);
        glPopMatrix();
    }
}

// --------------------------------------------
void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // ���e
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60, 16.0 / 9.0, 0.1, 1000);

    // �J����
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    float rx = camAngleX * 3.1415f / 180;
    float ry = camAngleY * 3.1415f / 180;

    float ex = camDist * cosf(rx) * cosf(ry);
    float ey = camDist * sinf(rx);
    float ez = camDist * cosf(rx) * sinf(ry);

    gluLookAt(ex, ey, ez, 0, 0, 0, 0, 1, 0);

    // ���C�g
    float lightPos[] = { 10,20,10,1 };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

    drawFloor();
    drawBalls();

    glutSwapBuffers();
}

// --------------------------------------------
// �}�E�X�Ŏ��_��]
// --------------------------------------------
void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) { dragging = true; prevMX = x; prevMY = y; }
        else dragging = false;
    }
}

void motion(int x, int y) {
    if (!dragging) return;

    camAngleY += (x - prevMX) * 0.4f;
    camAngleX += (y - prevMY) * 0.4f;

    if (camAngleX > 80) camAngleX = 80;
    if (camAngleX < -10) camAngleX = -10;

    prevMX = x;
    prevMY = y;
}

// --------------------------------------------
void timer(int v) {
    update();
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

// --------------------------------------------
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1280, 720);
    glutCreateWindow("STEP 4 : 3D ������(�d�� + �� + �� + �����m�̏Փ�)");

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    initBalls();

    glutDisplayFunc(display);
    glutTimerFunc(16, timer, 0);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);

    glutMainLoop();
    return 0;
}
