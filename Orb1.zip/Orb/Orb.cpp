#define _USE_MATH_DEFINES
#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <string>

// ======================= �\���� =======================
struct Planet {
    std::string name;
    float a;           // �O�������a (AU)
    float ecc;         // �ΐS��
    float inclination; // �O���X�Ίp (�x)
    float period;      // ���]�����i���j
    float radius;      // �f�����a (�`��p)
    float color[3];    // �F
};

// ======================= �f���f�[�^ =======================
std::vector<Planet> planets = {
    {"Mercury", 0.387f, 0.206f, 7.0f,    88.0f,   0.02f, {0.5f, 0.5f, 0.5f}},
    {"Venus",   0.723f, 0.007f, 3.4f,   225.0f,   0.05f, {1.0f, 0.8f, 0.2f}},
    {"Earth",   1.000f, 0.017f, 0.0f,   365.0f,   0.05f, {0.2f, 0.2f, 1.0f}},
    {"Mars",    1.524f, 0.093f, 1.85f,  687.0f,   0.04f, {1.0f, 0.3f, 0.3f}},
    {"Jupiter", 5.203f, 0.049f, 1.3f,  4331.0f,   0.10f, {1.0f, 0.6f, 0.2f}},
    {"Saturn",  9.537f, 0.056f, 2.5f, 10747.0f,   0.09f, {1.0f, 0.8f, 0.5f}},
    {"Uranus", 19.191f, 0.047f, 0.8f, 30589.0f,   0.07f, {0.5f, 0.8f, 1.0f}},
    {"Neptune",30.068f, 0.009f, 1.8f, 59800.0f,   0.07f, {0.2f, 0.4f, 1.0f}},
};

// ?? ���f�[�^�i�n�����S�j
Planet moon = { "Moon", 0.00257f, 0.055f, 5.0f, 27.3f, 0.015f, {0.8f, 0.8f, 0.8f} };

// ======================= �O���[�o���ϐ� =======================
float simDay = 0.0f;
float simSpeed = 5.0f;  // 1�t���[��������̓���
bool paused = false;

// �J��������
float camAngleX = 20.0f, camAngleY = -30.0f, camDist = 30.0f;

// ======================= �f���{���̕`�� =======================
void drawPlanets() {
    for (auto& p : planets) {
        glPushMatrix();

        // --- �f���̋O���i���z���S�j��`�� ---
        glColor3f(0.5f, 0.5f, 0.5f);
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < 360; i++) {
            float theta = i * M_PI / 180.0f;
            float r = p.a * (1 - p.ecc * p.ecc) / (1 + p.ecc * cos(theta));
            float x = r * cos(theta);
            float y = r * sin(theta);
            glVertex3f(x, 0, y);
        }
        glEnd();

        // --- �f���̈ʒu�v�Z ---
        float M = 2 * M_PI * simDay / p.period;
        float E = M + p.ecc * sin(M); // �P�v���[�������̋ߎ�
        float x = p.a * (cos(E) - p.ecc);
        float y = p.a * sqrt(1 - p.ecc * p.ecc) * sin(E);

        glRotatef(p.inclination, 1, 0, 0);
        glTranslatef(x, 0, y);

        // --- �f���{�� ---
        glColor3fv(p.color);
        glutSolidSphere(p.radius, 20, 20);

        // --- �n���Ȃ猎��`�� ---
        if (p.name == "Earth") {
            glPushMatrix();

            // ���̋O��
            glColor3f(0.5f, 0.5f, 0.5f);
            glBegin(GL_LINE_LOOP);
            for (int i = 0; i < 360; i++) {
                float theta = i * M_PI / 180.0f;
                float r = moon.a * (1 - moon.ecc * moon.ecc) / (1 + moon.ecc * cos(theta));
                float xx = r * cos(theta);
                float yy = r * sin(theta);
                glVertex3f(xx, 0, yy);
            }
            glEnd();

            // ���̈ʒu�v�Z
            float Mm = 2 * M_PI * simDay / moon.period;
            float Em = Mm + moon.ecc * sin(Mm);
            float xm = moon.a * (cos(Em) - moon.ecc);
            float ym = moon.a * sqrt(1 - moon.ecc * moon.ecc) * sin(Em);

            glRotatef(moon.inclination, 1, 0, 0);
            glTranslatef(xm, 0, ym);

            // ���{��
            glColor3fv(moon.color);
            glutSolidSphere(moon.radius, 16, 16);

            glPopMatrix();
        }

        glPopMatrix();
    }
}

// ======================= �f�B�X�v���C�R�[���o�b�N =======================
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // �J����
    glTranslatef(0, 0, -camDist);
    glRotatef(camAngleX, 1, 0, 0);
    glRotatef(camAngleY, 0, 1, 0);

    // ���z
    glColor3f(1.0f, 1.0f, 0.0f);
    glutSolidSphere(0.2f, 30, 30);

    // �f���{��
    drawPlanets();

    glutSwapBuffers();
}

// ======================= �A�j���[�V���� =======================
void idle() {
    if (!paused) simDay += simSpeed;
    glutPostRedisplay();
}

// ======================= ���͏��� =======================
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case 27: exit(0); break; // ESC
    case ' ': paused = !paused; break;
    case '/': simSpeed *= 2; break;
    case '-': simSpeed /= 2; if (simSpeed < 0.1f) simSpeed = 0.1f; break;
    case 'q': case 'Q': camAngleX += 5; break;
    case 'e': case 'E': camAngleX -= 5; break;
    }
}

void specialKeys(int key, int x, int y) {
    switch (key) {
    case GLUT_KEY_LEFT:  camAngleY -= 5; break;
    case GLUT_KEY_RIGHT: camAngleY += 5; break;
    case GLUT_KEY_UP:    camAngleX += 5; break;
    case GLUT_KEY_DOWN:  camAngleX -= 5; break;
    case GLUT_KEY_PAGE_UP:   camDist -= 1; if (camDist < 2) camDist = 2; break;
    case GLUT_KEY_PAGE_DOWN: camDist += 1; break;
    }
}

// ======================= �E�B���h�E���T�C�Y =======================
void reshape(int w, int h) {
    if (h == 0) h = 1;
    float aspect = (float)w / (float)h;

    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, aspect, 0.1, 100.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

// ======================= OpenGL������ =======================
void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0, 0, 0, 1);
}

// ======================= ���C���֐� =======================
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1200, 800);
    glutCreateWindow("���z�n�\��");

    init();

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glutReshapeFunc(reshape);

    glutMainLoop();
    return 0;
}
