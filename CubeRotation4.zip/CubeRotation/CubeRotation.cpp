﻿#ifdef _WIN32 
#include <windows.h>
#endif
#include <GL/glut.h>
#include <cmath>
#include <chrono>

// ----------------------
// 光源のワールド座標（固定）
// ----------------------
// ここでは光源を固定している。立方体が回転しても光源位置は変わらない。
float lightPos[3] = { 3.0f, 3.0f, 3.0f };

// ----------------------
// 回転関数（Y軸）
// ----------------------
// v[3] : 回転させたい頂点または法線ベクトル
// deg : 回転角（度単位）
// Y軸回りの回転行列を手計算で適用している
static void rotateY(float v[3], float deg) {
    float rad = deg * 3.14159265f / 180.0f; // 度→ラジアン変換
    float x = v[0] * cos(rad) + v[2] * sin(rad); // X' = X cosθ + Z sinθ
    float z = -v[0] * sin(rad) + v[2] * cos(rad); // Z' = -X sinθ + Z cosθ
    v[0] = x;
    v[2] = z;
}

// ----------------------
// 回転関数（X軸）
// ----------------------
// X軸回りの回転。YとZを回転させる
static void rotateX(float v[3], float deg) {
    float rad = deg * 3.14159265f / 180.0f;
    float y = v[1] * cos(rad) - v[2] * sin(rad); // Y' = Y cosθ - Z sinθ
    float z = v[1] * sin(rad) + v[2] * cos(rad); // Z' = Y sinθ + Z cosθ
    v[1] = y;
    v[2] = z;
}

// ----------------------
// 法線ベクトルを求める
// ----------------------
static void cross(float a[3], float b[3], float n[3]) {

//=============================================================
// １．外積を求める
//=============================================================
    n[0] = a[1] * b[2] - a[2] * b[1];
    n[1] = a[2] * b[0] - a[0] * b[2];
    n[2] = a[0] * b[1] - a[1] * b[0];

//=============================================================
// ２．正規化（長さを０とする）
//=============================================================
    float len = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);
    if (len > 1e-6f) {
        n[0] /= len; n[1] /= len; n[2] /= len;
    }

//=============================================================
// ここまで
//=============================================================
}


// ----------------------
// 四角形描画＋法線＋自前ライティング
// ----------------------
// v0～v3 : 四角形の頂点（回転済みワールド座標）
// normal : 回転済みの法線ベクトル
static void drawQuad(float v0[3], float v1[3], float v2[3], float v3[3], float normal[3]) {

    float ambient   = 0.5f; // 環境光（光が当たらなくても少し明るく）
    float intensity = 1.0f; // この平面にあたる光の量(０～１）

//=============================================================
// ３．この四角形の中心座標を求める
//=============================================================
    float center[3] = {
        (v0[0] + v1[0] + v2[0] + v3[0]) / 4.0f,
        (v0[1] + v1[1] + v2[1] + v3[1]) / 4.0f,
        (v0[2] + v1[2] + v2[2] + v3[2]) / 4.0f
    };

//=============================================================
// ４．光源方向ベクトルを求める
//=============================================================
    float lightDir[3] = {
        lightPos[0] - center[0],
        lightPos[1] - center[1],
        lightPos[2] - center[2]
    };

//=============================================================
// ５．光源方向ベクトルを正規化（長さを１に）する
//=============================================================
    float len = sqrt(lightDir[0] * lightDir[0] + lightDir[1] * lightDir[1] + lightDir[2] * lightDir[2]);
    for (int i = 0; i < 3; i++) 
        lightDir[i] /= len; // 単位ベクトル化

//=============================================================
// ６．光源方向ベクトルと法線ベクトルの関係から
// 　　その面にあたる光の量(intensity)を求める
//=============================================================
    intensity = normal[0] * lightDir[0] + normal[1] * lightDir[1] + normal[2] * lightDir[2];


//=============================================================
// ７．求めた光の量（intensity）に環境光（ambient)を加える
//=============================================================
    intensity = intensity * (1.0f - ambient) + ambient; // 環境光を足す

//=============================================================
// ８．求めた光の量（intensity）を修正する（０から１の範囲に収める）
//=============================================================
    if (intensity < 0)
        intensity = 0;
    if (intensity > 1) 
        intensity = 1;

//=============================================================
// ここまで
//=============================================================

    glDisable(GL_LIGHTING); // OpenGLの固定機能光源は使わず自前計算

    // ------------------------
    // 面描画（緑色、明暗反映）
    glColor3f(0,intensity,  0); // 緑チャンネルに明暗を反映
    glBegin(GL_QUADS);
    glVertex3fv(v0);
    glVertex3fv(v1);
    glVertex3fv(v2);
    glVertex3fv(v3);
    glEnd();

    // ------------------------
    // 輪郭線描画
    glColor3f(0, 0, 0);
    glBegin(GL_LINE_LOOP);
    glVertex3fv(v0);
    glVertex3fv(v1);
    glVertex3fv(v2);
    glVertex3fv(v3);
    glEnd();

    // ------------------------
    // 法線ベクトル表示（中心から伸ばす）
    glLineWidth(2.0f);
    glColor3f(0, 0, 0);
    glBegin(GL_LINES);
    glVertex3fv(center);
    glVertex3f(center[0] + normal[0] * 1.0f,
        center[1] + normal[1] * 1.0f,
        center[2] + normal[2] * 1.0f);
    glEnd();
    glLineWidth(1.0f); // 元に戻す
}

// ----------------------
// 立方体描画
// ----------------------
// angleY,X : 秒単位で回転角
static void drawCube(float angleY, float angleX) {

    // 頂点（局所座標）
    float v[8][3] = {
        {-1,-1,-1}, // 0
        { 1,-1,-1}, // 1
        { 1, 1,-1}, // 2
        {-1, 1,-1}, // 3
        {-1,-1, 1}, // 4
        { 1,-1, 1}, // 5
        { 1, 1, 1}, // 6
        {-1, 1, 1}  // 7
    };

    // 法線ベクトル
    float normals[6][3];

//=============================================================
// ９．６面分の法線ベクトルを求める
//=============================================================

    // 平面（頂点のインデックス）順番に注意
    int s[6][4] = {
        {3,2,1,0}, // back
        {4,5,6,7}, // front
        {7,3,0,4}, // left
        {1,2,6,5}, // right
        {3,7,6,2}, // top
        {0,1,5,4}, // bottom
    };

    for (int i = 0; i < 6; i++) {  // 平面数分法線ベクトルを設定
        float edge1[3] = { v[s[i][0]][0] - v[s[i][1]][0], v[s[i][0]][1] - v[s[i][1]][1], v[s[i][0]][2] - v[s[i][1]][2] };
        float edge2[3] = { v[s[i][1]][0] - v[s[i][2]][0], v[s[i][1]][1] - v[s[i][2]][1], v[s[i][1]][2] - v[s[i][2]][2] };

        cross(edge1, edge2, normals[i]);
    }

//=============================================================
// ここまで
//=============================================================

    // ------------------------
    // 回転（頂点と法線を同じ回転）
    // 法線は向きを持つベクトルなので、頂点と同様に回転する
    for (int i = 0; i < 8; i++) {
        rotateY(v[i], angleY);
        rotateX(v[i], angleX);
    }
    for (int i = 0; i < 6; i++) {
        rotateY(normals[i], angleY);
        rotateX(normals[i], angleX);
    }

    // ------------------------
    // 頂点順（CCW）で描画
    drawQuad(v[0], v[1], v[2], v[3], normals[0]); // back
    drawQuad(v[4], v[5], v[6], v[7], normals[1]); // front
    drawQuad(v[0], v[4], v[7], v[3], normals[2]); // left
    drawQuad(v[1], v[5], v[6], v[2], normals[3]); // right
    drawQuad(v[3], v[2], v[6], v[7], normals[4]); // top
    drawQuad(v[0], v[1], v[5], v[4], normals[5]); // bottom
}

// ----------------------
//　display()
// ----------------------
static void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(0, 0, -8); // カメラを後ろに引く

    // ------------------------
    // 時間計測による回転角
    static auto start = std::chrono::steady_clock::now();
    auto now = std::chrono::steady_clock::now();
    float elapsed = std::chrono::duration<float>(now - start).count();

    float angleY = elapsed * 30.0f; // Y軸回転 30度/秒
    float angleX = elapsed * 20.0f; // X軸回転 20度/秒

    drawCube(angleY, angleX);

    // ------------------------
    // 光源位置表示（黄色線）
    glDisable(GL_LIGHTING);
    glColor3f(1, 1, 0);
    glBegin(GL_LINES);
    glVertex3f(0, 0, 0);        // 原点から
    glVertex3fv(lightPos);    // 光源まで
    glEnd();
    glEnable(GL_LIGHTING);

    glutSwapBuffers(); // ダブルバッファ
}

// ----------------------
//　init()
// ----------------------
static void init() {
    glEnable(GL_DEPTH_TEST); // Zバッファ有効
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // 背景白

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45, 1, 0.1, 20); // 視野角45度、アスペクト比1、前後クリップ
}


// ----------------------
//　idle()
// ----------------------
static void idle() { glutPostRedisplay(); } // 毎フレーム再描画

/// ----------------------
//　main()
// ----------------------
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(600, 600);
    glutCreateWindow("全6面法線＋固定光源デモ");

    init();
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutMainLoop();
    return 0;
}
