#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <string>

struct Vec3 {
    float x, y, z;
    Vec3(float x = 0, float y = 0, float z = 0) :x(x), y(y), z(z) {}
    Vec3 operator+(const Vec3& v)const { return { x + v.x,y + v.y,z + v.z }; }
    Vec3 operator-(const Vec3& v)const { return { x - v.x,y - v.y,z - v.z }; }
    Vec3 operator*(float s)const { return { x * s,y * s,z * s }; }
    Vec3 operator/(float s)const { return { x / s,y / s,z / s }; }
};

float length(const Vec3& v) { return std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z); }
Vec3 normalize(const Vec3& v) { float l = length(v); return (l > 1e-6) ? v / l : Vec3(); }

// ----------------- �I�u�W�F�N�g -----------------
struct Object {
    Vec3 pos, vel;
    std::vector<Vec3> trail;
};

struct Explosion {
    Vec3 pos;
    float timer;
};

Object target, missile;
std::vector<Explosion> explosions;

const float TARGET_SPEED = 70.0f;
const float MISSILE_SPEED = 200.0f;
const float HIT_DIST = 20.0f;
const float TURN_SPEED = 2.0f; // �~�T�C�������W��
const float TARGET_TURN_SPEED = 1.5f; // �G����X�s�[�h�irad/s�j

int score = 0;

// �J�������[�h
enum CameraMode { CAM_CHASE, CAM_FIXED };
CameraMode camMode = CAM_CHASE;

// ----------------- ������ -----------------
void reset() {
    target.pos = Vec3(
        -300.0f + static_cast<float>(rand() % 200),
        static_cast<float>(rand() % 100 - 50),
        static_cast<float>(rand() % 200 - 100)
    );
    target.vel = Vec3(TARGET_SPEED, 0.0f, 0.0f);

    missile.pos = Vec3(0.0f, 0.0f, 0.0f);
    missile.vel = Vec3(0.0f, 0.0f, 0.0f);

    target.trail.clear();
    missile.trail.clear();
}

// ----------------- �G�X�V -----------------
void updateTarget(float dt) {
    static float t = 0; t += dt;

    // ��{�֍s�^��
    target.pos.z = 50 + sin(glutGet(GLUT_ELAPSED_TIME) / 500.0f) * 30.0f;

    // �~�T�C�������x�N�g��
    Vec3 toMissile = normalize(missile.pos - target.pos);
    float dist = length(missile.pos - target.pos);

    // �߂Â�����U�^�[���������v�Z
    Vec3 targetDir = normalize(target.vel);
    Vec3 escapeDir = normalize(target.pos - missile.pos); // �~�T�C�����牓���������

    // �����_���ɃJ�[�u��]������
    float angle = 0.0f;
    if (dist < 200.0f && rand() % 50 == 0) { // �ߋ����������Ń^�[���J�n
        angle = TARGET_TURN_SPEED * dt; // rad/s
        if (rand() % 2) angle = -angle;
    }
    else {
        // ���ʂ̎֍s�J�[�u
        angle = 0.5f * dt;
    }

    // Z����]�i�����ʐ���j
    float cosA = cos(angle);
    float sinA = sin(angle);
    Vec3 newDir;
    newDir.x = targetDir.x * cosA - targetDir.y * sinA;
    newDir.y = targetDir.x * sinA + targetDir.y * cosA;
    newDir.z = targetDir.z; // �㉺�͂��̂܂�
    target.vel = normalize(newDir) * TARGET_SPEED;

    // �ʒu�X�V
    target.pos = target.pos + target.vel * dt;
    target.trail.push_back(target.pos);
}

// ----------------- �~�T�C���X�V -----------------
void updateMissile(float dt) {
    Vec3 dir = normalize(target.pos - missile.pos);
    Vec3 desired = dir * MISSILE_SPEED;

    missile.vel = missile.vel + (desired - missile.vel) * TURN_SPEED * dt;
    missile.pos = missile.pos + missile.vel * dt;
    missile.trail.push_back(missile.pos);
}

// ----------------- �`�� -----------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // ===== �J���� =====
    Vec3 eye, center;
    if (camMode == CAM_CHASE) {
        Vec3 dir = normalize(missile.vel);
        if (length(missile.vel) < 1e-6) dir = { 1,0,0 };
        eye = missile.pos - dir * 80.0f + Vec3(0, 20, 20);
        center = missile.pos + dir * 200.0f;
    }
    else {
        eye = Vec3(0, -600, 200); // �Œ莋�_
        center = Vec3(0, 0, 0);
    }
    gluLookAt(eye.x, eye.y, eye.z,
        center.x, center.y, center.z,
        0, 0, 1);

    // ===== �G�@�i�ԁj =====
    glColor3f(1, 0, 0);
    glPushMatrix();
    glTranslatef(target.pos.x, target.pos.y, target.pos.z);
    glutSolidCube(10);
    glPopMatrix();

    // ===== �~�T�C���i�΁j =====
    glColor3f(0, 1, 0);
    glPushMatrix();
    glTranslatef(missile.pos.x, missile.pos.y, missile.pos.z);
    glutSolidSphere(5, 12, 12);
    glPopMatrix();

    // ===== �O�� =====
    glColor3f(1, 0, 0);
    glBegin(GL_LINE_STRIP);
    for (auto& p : target.trail) glVertex3f(p.x, p.y, p.z);
    glEnd();

    glColor3f(0, 1, 0);
    glBegin(GL_LINE_STRIP);
    for (auto& p : missile.trail) glVertex3f(p.x, p.y, p.z);
    glEnd();

    // ===== �X�R�A�\�� =====
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 800, 0, 600);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glColor3f(1, 1, 0);
    std::string s = "Score: " + std::to_string(score);
    glRasterPos2i(10, 580);
    for (char c : s) glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, c);

    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    glutSwapBuffers();
}

// ----------------- �A�C�h�� -----------------
void idle() {
    static int prev = glutGet(GLUT_ELAPSED_TIME);
    int now = glutGet(GLUT_ELAPSED_TIME);
    float dt = (now - prev) / 1000.0f;
    prev = now;

    updateTarget(dt);
    updateMissile(dt);

    if (length(target.pos - missile.pos) < HIT_DIST) {
        score++;
        explosions.push_back({ target.pos, 0.3f });
        reset();
    }

    glutPostRedisplay();
}

// ----------------- �L�[�{�[�h -----------------
void keyboard(unsigned char key, int x, int y) {
    if (key == 'c' || key == 'C') camMode = CAM_CHASE;
    if (key == 'f' || key == 'F') camMode = CAM_FIXED;
}

// ----------------- ������ -----------------
void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0, 0, 0, 1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, 800.0 / 600.0, 1.0, 5000.0);
    glMatrixMode(GL_MODELVIEW);
}

// ----------------- main -----------------
int main(int argc, char** argv) {
    srand((unsigned)time(NULL));
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("�M���ǔ��~�T�C���R�c��");
    init();
    reset();
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
