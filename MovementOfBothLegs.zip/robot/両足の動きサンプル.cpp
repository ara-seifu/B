﻿#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define PI 3.14159265

// --------------------
// アニメーション用時間管理
// --------------------
float t = 0.0f; // アニメーション経過時間 [秒]
float dt = 0.016f; // フレーム時間間隔（約60FPSで0.016秒/フレーム）

// --------------------
// モーションパラメータ（歩行時の角度など）
// --------------------
float f = 1.0f; // 歩行サイクル周波数 [Hz] （1秒で1周期）
float A_thigh = 30.0f; // 大腿の振れ幅（°）
float A_shin = 40.0f; // 下腿の補助振れ幅（°）
float theta0_thigh = 0.0f; // 大腿基準角度（オフセット）
float theta0_shin = 20.0f; // 下腿基準角度（オフセット）

// --------------------
// 脚の部位長さ
// --------------------
float thigh_length = 0.6f; // 大腿の長さ
float shin_length = 0.5f; // 下腿の長さ

// -------------------------------------------------------------
// 脚の角度を時間 t から計算する関数
// thigh_angle と shin_angle に角度（°）を格納
// -------------------------------------------------------------
void calculate_leg_motion(float t, float* thigh_angle, float* shin_angle) {
    // 大腿角：正弦波で振動（t=0で0）
    *thigh_angle = A_thigh * sinf(2.0f * PI * f * t);

    // 下腿角：大腿が前に出るときだけ曲げる
    if (*thigh_angle < 0)
        *shin_angle = -A_shin * (*thigh_angle / -A_thigh); // 正規化
    else
        *shin_angle = 0.0f;
}

// -------------------------------------------------------------
// 角度（度）をラジアンに変換する関数
// OpenGLでは sin/cos がラジアン単位なので変換が必要
// -------------------------------------------------------------
float to_radian(float deg) {
    return deg * PI / 180.0f;
}

// -------------------------------------------------------------
// 片脚を描画する関数
// thigh_angle: 大腿角度[°]
// shin_angle : 下腿角度[°]
// r,g,b : 線の色
// -------------------------------------------------------------
void draw_leg(float thigh_angle, float shin_angle, float r, float g, float b) {
    // 大腿角度をラジアンに変換
    float thigh_rad = to_radian(-thigh_angle); // 左向きにするため符号反転

    // 大腿の先端座標
    float thigh_x = -thigh_length * sinf(thigh_rad); // 左向き
    float thigh_y = -thigh_length * cosf(thigh_rad);

    // 下腿の角度（大腿角 + 下腿角）
    float shin_rad = thigh_rad + to_radian(shin_angle);

    // 下腿の先端座標
    float shin_x = -shin_length * sinf(shin_rad);   // 左向き
    float shin_y = -shin_length * cosf(shin_rad);

    // 線の太さを指定して描画
    glLineWidth(5.0f);
    glBegin(GL_LINES);
    glColor3f(r, g, b);

    // 大腿描画（股関節 → 膝）
    glVertex2f(0.0f, 0.0f);
    glVertex2f(thigh_x, thigh_y);

    // 下腿描画（膝 → 足首）
    glVertex2f(thigh_x, thigh_y);
    glVertex2f(thigh_x + shin_x, thigh_y + shin_y);

    glEnd();

}

// -------------------------------------------------------------
// 描画関数（毎フレーム呼び出される）
// -------------------------------------------------------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT); // 画面クリア
    glLoadIdentity();
    glTranslatef(0.0f, 0.3f, 0.0f); // 全体を少し上に移動（画面中央調整）

    // 右脚の角度計算
    float thigh_angle1, shin_angle1;
    calculate_leg_motion(t, &thigh_angle1, &shin_angle1);

    // 左脚は位相を0.5周期ずらす（左右交互に動く）
    float thigh_angle2, shin_angle2;
    calculate_leg_motion(t + 0.5f / f, &thigh_angle2, &shin_angle2);

    // 右脚描画（赤）
    draw_leg(thigh_angle1, shin_angle1, 1.0f, 0.0f, 0.0f);
    // 左脚描画（緑）
    draw_leg(thigh_angle2, shin_angle2, 0.0f, 0.6f, 0.0f);

    glutSwapBuffers(); // ダブルバッファの切り替え

}

// -------------------------------------------------------------
// タイマーコールバック（フレーム更新）
// -------------------------------------------------------------
void timer(int value) {
    t += dt; // 経過時間を更新
    glutPostRedisplay(); // 再描画要求
    glutTimerFunc((int)(dt * 1000), timer, 0); // 次フレーム呼び出し
}

// -------------------------------------------------------------
// 初期化処理（OpenGL設定）
// -------------------------------------------------------------
void init() {
    glClearColor(1, 1, 1, 1); // 背景色：白
    glMatrixMode(GL_PROJECTION); // 投影行列モード
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1); // 2D表示範囲
    glMatrixMode(GL_MODELVIEW); // モデルビュー行列モード
}

// -------------------------------------------------------------
// メイン関数
// -------------------------------------------------------------
int main(int argc, char* argv[]) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(500, 500); // ウィンドウサイズ
    glutCreateWindow("脚の動き"); // ウィンドウタイトル

    init();                                // 初期化処理
    glutDisplayFunc(display);              // 描画関数登録
    glutTimerFunc(0, timer, 0);            // タイマー開始

    glutMainLoop();                         // メインループ
    return 0;

}