﻿#include <GL/glut.h>
#include <cmath>
#include <cstdio>

// M_PI が未定義の場合に定義
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ウィンドウサイズ
const int WIN_W = 800;
const int WIN_H = 600;

// ロボットアームのリンク長さ
const double L1 = 160.0; // 基本リンク（根元から肘まで）
const double L2 = 120.0; // 中間リンク（肘から手首まで）
const double L3 = 80.0;  // 末端リンク（手首から先端まで）

// 各関節角（ラジアン単位）
double theta1 = 0.0; // リンク1の角度
double theta2 = 0.0; // リンク2の角度（リンク1基準）
double theta3 = 0.0; // リンク3の角度（リンク1+リンク2基準）

// 目標位置（マウス指定）
double targetX = 200.0;
double targetY = 100.0;

// 目標位置固定フラグ（マウスクリックで切替）
bool targetLocked = false;

// 肘の向きフラグ（true: 肘下向き / false: 肘上向き）
bool elbowDown = true;

// 値を範囲内に制限する関数
inline double clamp(double v, double lo, double hi) {
    return (v < lo) ? lo : (v > hi) ? hi : v;
}

// -------------------------------
// 3リンク逆運動学解析関数
// tx, ty: 目標座標
// elbowDownFlag: 肘の向き
// -------------------------------
void solveIK_3link(double tx, double ty, bool elbowDownFlag) {
    double dx = tx;
    double dy = ty;

    // 原点から目標までの距離
    double d = std::sqrt(dx * dx + dy * dy);

    double maxReach = L1 + L2 + L3; // 最大到達距離

    if (d > maxReach) {
        // 到達不可能な場合は、腕を伸ばした姿勢で目標方向に向ける
        double ang = std::atan2(dy, dx); // 目標方向の角度
        theta1 = ang; // 基本リンク角度
        theta2 = 0.0; // 中間リンクはまっすぐ
        theta3 = 0.0; // 末端リンクもまっすぐ
        return;
    }

    // 末端リンクL3を除いた距離で2リンクIKを計算
    double r = clamp(d - L3, 0.0, L1 + L2);

    // cosθ2 を求める（三角法）
    // r^2 = L1^2 + L2^2 + 2*L1*L2*cosθ2 から cosθ2 = (r^2 - L1^2 - L2^2)/(2*L1*L2)
    double cos_theta2 = clamp((r * r - L1 * L1 - L2 * L2) / (2.0 * L1 * L2), -1.0, 1.0);
    double th2 = std::acos(cos_theta2); // 肘角度
    if (!elbowDownFlag) th2 = -th2;    // 肘向き反転

    // θ1 の計算（リンク1の角度）
    double k1 = L1 + L2 * std::cos(th2); // cos成分の合成
    double k2 = L2 * std::sin(th2);      // sin成分の合成
    double ang = std::atan2(dy, dx);     // 原点から目標までの角度
    double th1 = ang - std::atan2(k2, k1); // リンク1の角度を決定

    theta1 = th1;
    theta2 = th2;

    // リンク2の末端座標計算（リンク1基準）
    double x1 = L1 * std::cos(theta1);
    double y1 = L1 * std::sin(theta1);
    double x2 = x1 + L2 * std::cos(theta1 + theta2);
    double y2 = y1 + L2 * std::sin(theta1 + theta2);

    // リンク3の角度（手先が目標を向くように調整）
    theta3 = std::atan2(dy - y2, dx - x2) - (theta1 + theta2);
}

// -------------------------------
// ウィンドウ座標 -> ワールド座標変換
// -------------------------------
void windowToWorld(int wx, int wy, double& outX, double& outY) {
    outX = wx - WIN_W / 2.0;            // Xは中央基準
    outY = (WIN_H - wy) - WIN_H / 2.0;  // Yは上下反転して中央基準
}

// -------------------------------
// 円描画
// -------------------------------
void drawCircle(double x, double y, double r, int segments = 24) {
    glBegin(GL_POLYGON);
    for (int i = 0; i < segments; i++) {
        double a = 2 * M_PI * i / segments;
        glVertex2d(x + std::cos(a) * r, y + std::sin(a) * r);
    }
    glEnd();
}

// -------------------------------
// 十字描画（目標マーカー用）
// -------------------------------
void drawCross(double x, double y, double s = 8.0) {
    glBegin(GL_LINES);
    glVertex2d(x - s, y); glVertex2d(x + s, y);
    glVertex2d(x, y - s); glVertex2d(x, y + s);
    glEnd();
}

// -------------------------------
// 描画関数
// -------------------------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 逆運動学計算
    solveIK_3link(targetX, targetY, elbowDown);

    // 各リンクの座標計算
    double x0 = 0, y0 = 0; // 原点
    double x1 = x0 + L1 * std::cos(theta1);
    double y1 = y0 + L1 * std::sin(theta1);
    double x2 = x1 + L2 * std::cos(theta1 + theta2);
    double y2 = y1 + L2 * std::sin(theta1 + theta2);
    double x3 = x2 + L3 * std::cos(theta1 + theta2 + theta3);
    double y3 = y2 + L3 * std::sin(theta1 + theta2 + theta3);

    // 原点を画面中央に移動
    glPushMatrix();
    glTranslatef(WIN_W / 2.0f, WIN_H / 2.0f, 0.0f);

    // 背景グリッド描画
    glColor3f(0.85f, 0.85f, 0.85f);
    glLineWidth(1.0f);
    glBegin(GL_LINES);
    for (int i = -WIN_W / 2; i <= WIN_W / 2; i += 40) { glVertex2i(i, -WIN_H / 2); glVertex2i(i, WIN_H / 2); }
    for (int j = -WIN_H / 2; j <= WIN_H / 2; j += 40) { glVertex2i(-WIN_W / 2, j); glVertex2i(WIN_W / 2, j); }
    glEnd();

    // 目標マーカー描画
    glColor3f(1.0f, 0.0f, 0.0f);
    drawCross(targetX, targetY, 8.0);

    // 各リンク描画
    glLineWidth(8.0f);
    glColor3f(0.2f, 0.6f, 1.0f); glBegin(GL_LINES); glVertex2d(x0, y0); glVertex2d(x1, y1); glEnd();
    glColor3f(0.2f, 1.0f, 0.4f); glBegin(GL_LINES); glVertex2d(x1, y1); glVertex2d(x2, y2); glEnd();
    glColor3f(1.0f, 0.5f, 0.2f); glBegin(GL_LINES); glVertex2d(x2, y2); glVertex2d(x3, y3); glEnd();

    // 関節描画
    glColor3f(0.1f, 0.1f, 0.1f);
    drawCircle(x0, y0, 10.0);
    drawCircle(x1, y1, 8.0);
    drawCircle(x2, y2, 6.0);
    drawCircle(x3, y3, 6.0);

    glPopMatrix();
    glutSwapBuffers(); // ダブルバッファ入れ替え
}

// -------------------------------
// ウィンドウサイズ変更時
// -------------------------------
void reshape(int w, int h) {
    glViewport(0, 0, WIN_W, WIN_H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, WIN_W, 0, WIN_H, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

// -------------------------------
// マウス移動で目標更新（固定されていない場合のみ）
// -------------------------------
void passiveMotion(int x, int y) {
    if (targetLocked) return;
    windowToWorld(x, y, targetX, targetY);
    glutPostRedisplay();
}

// -------------------------------
// マウスクリックで目標固定/解除
// -------------------------------
void mouseFunc(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        targetLocked = !targetLocked;
        windowToWorld(x, y, targetX, targetY);
        glutPostRedisplay();
    }
}

// -------------------------------
// キーボード操作
// -------------------------------
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case 0x1b: std::exit(0); break; // Escで終了
    case 'r': case 'R':              // リセット
        theta1 = theta2 = theta3 = 0;
        targetX = 200; targetY = 100;
        glutPostRedisplay();
        break;
    case 'e': case 'E':              // 肘向き切替
        elbowDown = !elbowDown;
        glutPostRedisplay();
        break;
    }
}

// -------------------------------
// メイン関数
// -------------------------------
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("インバース キネマティクス（3Link）");
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // 背景色白

    // コールバック関数登録
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutPassiveMotionFunc(passiveMotion);
    glutMouseFunc(mouseFunc);
    glutKeyboardFunc(keyboard);

    glutMainLoop(); // メインループ開始
    return 0;
}
