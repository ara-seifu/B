﻿
#include <iostream>
#include <winsock2.h>

#pragma comment(lib,"ws2_32.lib")
#define CHAT_PORT			1024
#define SERVER_ADR          "127.0.0.1"     // リモートホストのアドレス

WSADATA			g_wsadata   ;			    // winsock dll

int main(void) {
 
    unsigned short port = CHAT_PORT     ;
    SOCKET sock                         ;
    char buf[64]                        ;

    struct sockaddr_in server_addr  = { 0 }                 ;

    server_addr.sin_family          = AF_INET               ;
    server_addr.sin_addr.s_addr     = inet_addr(SERVER_ADR) ;
    server_addr.sin_port            = htons(port)           ;

    // 1. Winsockを開始(WSAStartup())
    if (WSAStartup(MAKEWORD(2, 2), &g_wsadata) == SOCKET_ERROR) {
        WSACleanup()    ;
        return -1       ;
    }
    printf("startup.\n");

    // 2.ソケット生成(socket())
    sock = socket(AF_INET, SOCK_STREAM, 0)   ;
    if (sock == INVALID_SOCKET) {

        WSACleanup()    ;
        return -2       ;
    }
    printf("socket created.\n");

    // 3. ソケット接続準備(connect())　　
    //    bind()しなくても自動的にローカルのIPアドレス、ポートを登録してくれる
    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr))) {
        closesocket(sock)   ;
        WSACleanup()        ;
        return -3           ;
    }
    printf("connect completed.\n");
 
    printf("server address = %s\n", inet_ntoa(server_addr.sin_addr))    ;
    printf("server port    = %d\n", ntohs(server_addr.sin_port))        ;

    // 4.受信（recv())
    recv(sock, buf,sizeof(buf), 0)  ;
    printf("\nreceived: %s\n", buf)   ;


    // 5.ソケットクローズ(closesocket())
    closesocket(sock)   ;

    // 6.Winsockを終了
    WSACleanup()        ;

    return 0    ;
}


