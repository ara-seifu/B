﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <winsock2.h>

#pragma comment(lib,"ws2_32.lib")
#define HTTP_PORT	80

WSADATA	g_wsadata   ;			// winsock dll

int main(void) {
    SOCKET serverSock, clientSock   ;

    unsigned short port = HTTP_PORT ;
    char msg0[] = "<html><body>Hello, World</body></html>\n"     ;
    char msg[4096]  ;
    char buf[4096]  ;
    int  size       ;

    struct sockaddr_in client_addr          ;
    struct sockaddr_in server_addr  = { 0 } ;

    server_addr.sin_family          = AF_INET           ;
    server_addr.sin_addr.s_addr     = htonl(INADDR_ANY) ;   // 複数のNICへのアクセスを認める
    server_addr.sin_port            = htons(port)       ;  

    int len = sizeof(struct sockaddr_in)    ;

    // 1. Winsockを開始(WSAStartup())
    if (WSAStartup(MAKEWORD(2, 2), &g_wsadata) == SOCKET_ERROR) {	
        WSACleanup()    ;
        return -1       ;
    }
    printf("startup.\n")    ;

    // 2.ソケット生成(socket())
    serverSock = socket(AF_INET, SOCK_STREAM, 0)    ;
    if (serverSock == INVALID_SOCKET) {
        WSACleanup();
        return -2   ;
    }
    printf("socket created.\n") ;

    // 3. ソケット登録(bind())
    if (bind(serverSock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        closesocket(serverSock) ;
        WSACleanup()    ;
        return -3   ;

    }
    printf("bind completed.\n") ;

    // 4.ソケット接続準備(listen())
    if (listen(serverSock, 5) == SOCKET_ERROR) { //接続要求は通常は５
        closesocket(serverSock) ;
        WSACleanup()    ;
        return -4   ;

    }
    printf("listen completed.\n")   ;
    printf("accept start.\n")       ;

    printf("server address = %s\n", "127.0.0.1")    ;
    printf("server port    = %d\n", ntohs(server_addr.sin_port))       ;

    // 5.ソケット接続待機(accept())
    clientSock = accept(serverSock, (struct sockaddr*)&client_addr, &len);
    if (clientSock == INVALID_SOCKET) {
        closesocket(serverSock) ;
        WSACleanup()            ;
        return -5               ;
    }

    printf("accepted. completed\n")   ;       //接続完了
    closesocket(serverSock)           ;       //これ以上の接続要求は無視する

    printf("client address = %s\n", inet_ntoa(client_addr.sin_addr))    ;
    printf("client port    = %d\n", ntohs(client_addr.sin_port))        ;


    size=recv(clientSock, buf, sizeof(buf), 0);         // GET / HTTP/1.0...
    if (size < 0) {
        closesocket(clientSock);
        WSACleanup();
        return -6;
    }
    buf[size] = '\0';
    printf("\nreceived:[\n %s\n]\n", buf);  

    // 6.送信（send())



    sprintf(msg, "%s%s%s%d%s%s" ,
        "HTTP/1.1 200 OK\r\n"   ,
        "Content-Type: text/html\r\n",
        "Content-Length: "      ,
        (int)strlen(msg0)       ,
        "\r\n\r\n"              ,
        msg0)                   ;


    send(clientSock, msg, sizeof(msg),0)    ;  
    printf("\nsend:[\n %s\n]\n", msg)       ;

    // 7.ソケットクローズ(closesocket())
    closesocket(clientSock)                 ; 

    // 8.Winsockを終了
    WSACleanup()                            ;

    return 0    ;
}
