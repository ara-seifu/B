﻿#define _USE_MATH_DEFINES
#include <GL/glut.h>
#include <cmath>
#include <chrono>

// =====================
// クォータニオン構造体
// =====================
struct Quaternion {
    double w, x, y, z;
    Quaternion(double w = 1, double x = 0, double y = 0, double z = 0)
        : w(w), x(x), y(y), z(z) {
    }
};

// =====================
// グローバル変数
// =====================
Quaternion qCurrent;
bool dragging = false;
int lastX, lastY;
double lastVec[3];
int winW = 800, winH = 600;

//----------------------------------------------------------------
//  normalize() 正規化
//----------------------------------------------------------------
Quaternion normalize(const Quaternion& q) {
    double len = std::sqrt(q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z);
    if (len < 1e-12) return Quaternion(1, 0, 0, 0);
    return Quaternion(q.w / len, q.x / len, q.y / len, q.z / len);
}

//----------------------------------------------------------------
//  multiplay()
//----------------------------------------------------------------
Quaternion multiply(const Quaternion& a, const Quaternion& b) {
    return Quaternion(
        a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
        a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w
    );
}

//----------------------------------------------------------------
//  fromAxisAngle()
//----------------------------------------------------------------
Quaternion fromAxisAngle(double ax, double ay, double az, double angle) {
    double len = std::sqrt(ax * ax + ay * ay + az * az);
    if (len < 1e-12) return Quaternion(1, 0, 0, 0);
    ax /= len; ay /= len; az /= len;
    double half = angle * 0.5;
    double s = std::sin(half);
    return Quaternion(std::cos(half), ax * s, ay * s, az * s);
}

//----------------------------------------------------------------
//  toMatrix()
//----------------------------------------------------------------
void toMatrix(const Quaternion& q, double M[16]) {
    double w = q.w, x = q.x, y = q.y, z = q.z;
    double m00 = 1 - 2 * y * y - 2 * z * z; double m01 = 2 * x * y - 2 * w * z; double m02 = 2 * x * z + 2 * w * y;
    double m10 = 2 * x * y + 2 * w * z;   double m11 = 1 - 2 * x * x - 2 * z * z; double m12 = 2 * y * z - 2 * w * x;
    double m20 = 2 * x * z - 2 * w * y;   double m21 = 2 * y * z + 2 * w * x;   double m22 = 1 - 2 * x * x - 2 * y * y;

    M[0] = m00; M[1] = m10; M[2] = m20; M[3] = 0;
    M[4] = m01; M[5] = m11; M[6] = m21; M[7] = 0;
    M[8] = m02; M[9] = m12; M[10] = m22; M[11] = 0;
    M[12] = 0; M[13] = 0; M[14] = 0; M[15] = 1;
}


//----------------------------------------------------------------
// mapToSphere() スクリーン座標を単位球上に投影
//----------------------------------------------------------------
void mapToSphere(int x, int y, double out[3]) {

    double nx  ; // 正規化された座標
    double ny  ;

    double len2; // 中心(0,0)と nx,nyとの距離の２乗

//===================================================
// １．スクリーン座標を正規化する
//===================================================
    nx = (2.0 * x - winW) / winW;   // [-1, 1]
    ny = (winH - 2.0 * y) / winH;   // [-1, 1], 上下反転

//===================================================
// ２．中心からの長さを求める（円の中かどうかをチェックする）
//===================================================
    len2 = nx * nx + ny * ny; // ２乗でチェック

//===================================================
// ３．円の外にある（仮想球の外にある）場合の座標outを求める
//===================================================
    if (len2 > 1.0) { // 仮想球の外にある場合
        double norm = 1.0 / std::sqrt(len2); // 単位円上に押し付けるための正規化係数
        out[0] = nx * norm;      // ｘ、ｙは円周上に縮める
        out[1] = ny * norm;
        out[2] = 0.0;            // ｚ座標は０
    }
//===================================================
// ４．円の中にある（仮想球の中にある）場合の座標outを求める
//===================================================
    else {              // 仮想球の中にある
        out[0] = nx;                    // x,yはそのまま円の中に
        out[1] = ny;
        out[2] = std::sqrt(1.0 - len2); // 球の方程式 x² + y² + z² = 1 から
    }
}

//----------------------------------------------------------------
//  drawAxes() XYZ軸を描画（赤:X, 緑:Y, 青:Z）
//----------------------------------------------------------------
void drawAxes() {
    glBegin(GL_LINES);
    glColor3f(1, 0, 0); glVertex3f(0, 0, 0); glVertex3f(5, 0, 0);
    glColor3f(0, 1, 0); glVertex3f(0, 0, 0); glVertex3f(0, 5, 0);
    glColor3f(0, 0, 1); glVertex3f(0, 0, 0); glVertex3f(0, 0, 5);
    glEnd();
}

//----------------------------------------------------------------
//  drawCube() 立方体描画
//----------------------------------------------------------------
void drawCube() {
    glBegin(GL_QUADS);
    glColor3f(1, 0, 0); glVertex3f(-1, -1, 1); glVertex3f(1, -1, 1); glVertex3f(1, 1, 1); glVertex3f(-1, 1, 1);
    glColor3f(0, 1, 0); glVertex3f(-1, -1, -1); glVertex3f(-1, 1, -1); glVertex3f(1, 1, -1); glVertex3f(1, -1, -1);
    glColor3f(0, 0, 1); glVertex3f(-1, -1, -1); glVertex3f(-1, -1, 1); glVertex3f(-1, 1, 1); glVertex3f(-1, 1, -1);
    glColor3f(1, 1, 0); glVertex3f(1, -1, -1); glVertex3f(1, 1, -1); glVertex3f(1, 1, 1); glVertex3f(1, -1, 1);
    glColor3f(1, 0, 1); glVertex3f(-1, 1, -1); glVertex3f(-1, 1, 1); glVertex3f(1, 1, 1); glVertex3f(1, 1, -1);
    glColor3f(0, 1, 1); glVertex3f(-1, -1, -1); glVertex3f(1, -1, -1); glVertex3f(1, -1, 1); glVertex3f(-1, -1, 1);
    glEnd();
}

//----------------------------------------------------------------
//  display() 描画
//----------------------------------------------------------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(3, 3, 5, 0, 0, 0, 0, 1, 0);

    drawAxes();
    double M[16];
    toMatrix(qCurrent, M);
    glMultMatrixd(M);
    drawCube();

    glutSwapBuffers();
}

//----------------------------------------------------------------
//  reshape() ウィンドウリサイズ
//----------------------------------------------------------------
void reshape(int w, int h) {
    winW = w; winH = h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (double)w / h, 1.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

//----------------------------------------------------------------
//  mouse() マウス
//----------------------------------------------------------------
void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {

//===================================================
// Ａ．最初にマウスが押されたときの回転の起点ベクトルを取得
//===================================================
            dragging = true;
            mapToSphere(x, y, lastVec); 
            lastX = x; lastY = y;


//===================================================
// ここまで
//===================================================
        
        }
        else if (state == GLUT_UP) {
            dragging = false;
        }
    }
}

//----------------------------------------------------------------
//  motion()
//----------------------------------------------------------------
void motion(int x, int y) {
    if (!dragging) 
        return;

    double currVec[3]; // 現在の球面ベクトル
    double angle;      // 回転角度

//===================================================
// Ｂ．現在の球面ベクトルを毎フレーム取得
//===================================================
    mapToSphere(x, y, currVec);

//===================================================
// Ｃ．起点ベクトル（lastVec)と 現在の球面ベクトル(currVec)の内積から
// 　　回転角度 を計算（正規化されているので内積＝cos（回転角）） 
//===================================================
    double dot = lastVec[0] * currVec[0] + lastVec[1] * currVec[1] + lastVec[2] * currVec[2];
    if (dot >  1.0) dot =  1.0; // 丸め誤差対策
    if (dot < -1.0) dot = -1.0;
    angle = std::acos(dot);  //  θ = arccos(cosθ)

//===================================================
// Ｄ．起点ベクトル（lastVec)と 現在の球面ベクトル(currVec)の外積
// 　　(両者に垂直なベクトル＝回転軸)を計算 
//===================================================
    double axis[3] = {        // 回転軸
        lastVec[1] * currVec[2] - lastVec[2] * currVec[1],
        lastVec[2] * currVec[0] - lastVec[0] * currVec[2],
        lastVec[0] * currVec[1] - lastVec[1] * currVec[0]
    };

//===================================================
// Ｅ．回転軸と回転角からクォータニオンを作る
//===================================================
    Quaternion delta = fromAxisAngle(axis[0], axis[1], axis[2], angle);
    qCurrent = multiply(delta, qCurrent); // 現在のオブジェクトの回転




//===================================================
// ここまで
//===================================================
    qCurrent = normalize(qCurrent);      // 正規化


    // 起点ベクトル（lastVec)を更新
    for (int i = 0; i < 3; i++) 
        lastVec[i] = currVec[i];

    glutPostRedisplay();
}

//----------------------------------------------------------------
//  init()
//----------------------------------------------------------------
void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(1, 1, 1, 1);
    qCurrent = Quaternion(1, 0, 0, 0);
}

//----------------------------------------------------------------
//  main()
//----------------------------------------------------------------
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(winW, winH);
    glutCreateWindow("マウスで立方体回転（Arcball）");

    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);

    glutMainLoop();
    return 0;
}
