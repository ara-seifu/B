﻿#include <GL/glut.h>
#include <vector>

struct Laser {
    float x, y;      // 始点
    float vx, vy;    // 速度
    float length;    // レーザーの長さ
};

std::vector<Laser> lasers;

float playerX = 0.0f;
float playerY = -0.8f;

int lastTime = 0;

// --- レーザー発射 ---
void shootLaser() {
    Laser l;
    l.x = playerX;
    l.y = playerY;
    l.vx = 0.0f;
    l.vy = 1.0f;    // 上方向に高速
    l.length = 1.0f; // レーザー長さ
    lasers.push_back(l);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー（青）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(playerX, playerY);
    glEnd();

    // レーザー（黄）
    glLineWidth(4.0f);
    glBegin(GL_LINES);
    glColor3f(1.0f, 0.8f, 0.0f);
    for (auto& l : lasers) {
        glVertex2f(l.x, l.y);
        glVertex2f(l.x, l.y + l.length);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    // レーザー移動
    for (auto it = lasers.begin(); it != lasers.end();) {
        it->y += it->vy * dt;

        // 画面上端で削除
        if (it->y > 1.0f) {
            it = lasers.erase(it);
        }
        else {
            ++it;
        }
    }

    glutPostRedisplay();
}

// キーでレーザー発射
void keyboard(unsigned char key, int, int) {
    if (key == ' ') shootLaser();
}

// プレイヤー移動
void specialKeys(int key, int, int) {
    float move = 0.05f;
    if (key == GLUT_KEY_LEFT)  playerX -= move;
    if (key == GLUT_KEY_RIGHT) playerX += move;
    if (playerX < -1.0f) playerX = -1.0f;
    if (playerX > 1.0f)  playerX = 1.0f;
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("レーザー弾(Spaceで発射）");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys); // ←矢印キー

    glutMainLoop();
    return 0;
}
