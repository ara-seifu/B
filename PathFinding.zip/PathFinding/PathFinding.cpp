﻿#include <iostream> 
#include <vector>
#include <queue>
#include <algorithm>
#include <functional>
#include <conio.h>   // _kbhit, _getch (Windows)
#include <windows.h> // Sleep, system("cls")
#include <cstdlib>
#include <ctime>

using namespace std;

// 2D座標を表す構造体
struct Vec2 { int x, y; bool operator==(const Vec2& o) const { return x == o.x && y == o.y; } };

// マップの幅・高さ（定数）
const int MAP_W = 30;
const int MAP_H = 16;

// マップ定義（文字列配列）
// '#' = 壁、'.' = 通路、'E' は敵、'P' はプレイヤー（描画時に置き換え）
vector<string> mapTemplate = {

    "##############################",
    "#............##.............#",
    "#..####......##......####...#",
    "#..#..#................#..#.#",
    "#..#..#..######..######.#..#.#",
    "#..####..#....#..#....#.#..#.#",
    "#........#....#..#....#.#..#.#",
    "#####....######..######.#..#.#",
    "#..............##......#..#.#",
    "#..######......##......#..#.#",
    "#..#....#............#.#..#.#",
    "#..#....#..######..###.#..#.#",
    "#..#....#..#....#..#..#....#.#",
    "#..........#....#..#........#",
    "#.........................E.#",
    "##############################"
};

// --------------------------------------------------
// ヘルパー関数
// --------------------------------------------------

// 指定座標が歩行可能かどうかを判定する（範囲外・壁・他の敵でブロックされていないか）
bool isWalkable(int x, int y, const vector<string>& map, const vector<Vec2>& enemies, const Vec2& player) {
    if (x < 0 || x >= MAP_W || y < 0 || y >= MAP_H) return false; // マップ外は不可
    char c = map[y][x];
    if (c == '#') return false; // 壁は不可
    // 他の敵がいるタイルも通れない（敵同士でブロック）
    for (auto& e : enemies) if (e.x == x && e.y == y) return false;
    // プレイヤーの位置は敵にとっては歩行可能（敵はプレイヤーを目標にする）
    return true;
}

// ヒューリスティック（マンハッタン距離）
int heuristic(const Vec2& a, const Vec2& b) {

    return abs(a.x - b.x) + abs(a.y - b.y);
}

// 経路復元：cameFrom テーブルからスタート→ゴールのパスを再構築する
vector<Vec2> reconstruct_path(const vector<vector<Vec2>>& cameFrom, Vec2 current) {

    vector<Vec2> total_path;
    total_path.push_back(current);
    // cameFrom の終端は {-1,-1} で示される
    while (!(cameFrom[current.y][current.x] == Vec2{ -1,-1 })) {
        current = cameFrom[current.y][current.x];
        total_path.push_back(current);
    }
    reverse(total_path.begin(), total_path.end());
    return total_path;
}

// --------------------------------------------------
// A* アルゴリズム
// --------------------------------------------------
// map: マップ情報
// start: 開始座標
// goal: 目標座標
// enemies: 現在の敵の位置（自身以外を障害として扱う）
// 戻り値: スタートとゴールを含む経路（見つからなければ空ベクター）
vector<Vec2> a_star(const vector<string>& map, Vec2 start, Vec2 goal, const vector<Vec2>& enemies) {

    // スタートとゴールが同じならすぐ返す
    if (start == goal) return { start };

    // gスコア（スタートからノードまでのコスト）を大きい値で初期化
    vector<vector<int>> gScore(MAP_H, vector<int>(MAP_W, INT_MAX));
    // fスコア（g + ヒューリスティック）も同様に
    vector<vector<int>> fScore(MAP_H, vector<int>(MAP_W, INT_MAX));
    // openSet に入っているかを素早く判定するフラグ配列
    vector<vector<bool>> openSetFlag(MAP_H, vector<bool>(MAP_W, false));
    // 経路復元用の親ノードテーブル（未訪問は {-1,-1}）
    vector<vector<Vec2>> cameFrom(MAP_H, vector<Vec2>(MAP_W, Vec2{ -1,-1 }));

    // 優先度付きキュー用のノード定義（f が小さい順）
    struct Node { int f; int g; Vec2 pos; };
    struct Cmp { bool operator()(const Node& a, const Node& b) const { return a.f > b.f; } };

    priority_queue<Node, vector<Node>, Cmp> openSet;

    // スタートを初期化
    gScore[start.y][start.x] = 0;
    fScore[start.y][start.x] = heuristic(start, goal);
    openSet.push({ fScore[start.y][start.x], 0, start });
    openSetFlag[start.y][start.x] = true;

    // 4方向（右、左、下、上）
    const vector<Vec2> dirs = { {1,0},{-1,0},{0,1},{0,-1} };

    // メインループ
    while (!openSet.empty()) {
        Node current = openSet.top(); openSet.pop();
        Vec2 cpos = current.pos;
        openSetFlag[cpos.y][cpos.x] = false; // 取り出したのでフラグを下げる

        // ゴールに到達したら経路を返す
        if (cpos == goal) {
            return reconstruct_path(cameFrom, cpos);
        }

        // 隣接ノードを走査
        for (auto d : dirs) {
            Vec2 neighbor{ cpos.x + d.x, cpos.y + d.y };
            // 範囲チェック
            if (neighbor.x < 0 || neighbor.x >= MAP_W || neighbor.y < 0 || neighbor.y >= MAP_H) continue;
            // 通行可能か確認（他の敵は障害とする）
            if (!isWalkable(neighbor.x, neighbor.y, map, enemies, start)) continue;

            int tentative_g = gScore[cpos.y][cpos.x] + 1; // グリッドは等コスト
            if (tentative_g < gScore[neighbor.y][neighbor.x]) {
                // より良い経路を発見した場合は情報を更新
                cameFrom[neighbor.y][neighbor.x] = cpos;
                gScore[neighbor.y][neighbor.x] = tentative_g;
                fScore[neighbor.y][neighbor.x] = tentative_g + heuristic(neighbor, goal);
                if (!openSetFlag[neighbor.y][neighbor.x]) {
                    openSet.push({ fScore[neighbor.y][neighbor.x], gScore[neighbor.y][neighbor.x], neighbor });
                    openSetFlag[neighbor.y][neighbor.x] = true;
                }
            }
        }
    }

    // 探索失敗（到達不可能）
    return {}; // 空のベクター
}

// --------------------------------------------------
// 描画関数：マップコピーを作ってプレイヤーと敵を上書きして表示する
// --------------------------------------------------
void render(const vector<string>& map, const Vec2& player, const vector<Vec2>& enemies) {

    // 描画用にマップをコピー
    vector<string> screen = map;
    // プレイヤーを 'P' で上書き（範囲チェックあり）
    if (player.y >= 0 && player.y < MAP_H && player.x >= 0 && player.x < MAP_W)
        screen[player.y][player.x] = 'P';

    // 敵を 'E' で上書き
    for (auto& e : enemies) {
        if (e.y >= 0 && e.y < MAP_H && e.x >= 0 && e.x < MAP_W)
            screen[e.y][e.x] = 'E';
    }

    // コンソールに行単位で出力
    for (int y = 0; y < MAP_H; ++y) {
        cout << screen[y] << "\n";
    }
}

// --------------------------------------------------
// メイン処理
// --------------------------------------------------
int main() {

    // 乱数初期化（敵のスポーンなどで使用）
    srand((unsigned)time(nullptr));

    // 作業用マップをテンプレートからコピー
    vector<string> map = mapTemplate;

    // プレイヤーの初期位置を探す（最初に見つけた '.' に置く）
    Vec2 player{ 1,1 };
    bool found = false;
    for (int y = 0; y < MAP_H && !found; ++y) for (int x = 0; x < MAP_W && !found; ++x) if (map[y][x] == '.') { player = { x,y }; found = true; }

    // 敵の初期位置をいくつか作る（プレイヤーからある程度離れた '.' を選ぶ）
    vector<Vec2> enemies;
    for (int y = MAP_H - 2; y > 0 && enemies.size() < 4; --y) for (int x = MAP_W - 2; x > 0 && enemies.size() < 4; --x) {
        if (map[y][x] == '.') {
            Vec2 c{ x,y };
            if (heuristic(c, player) > 8) enemies.push_back(c); // プレイヤーから一定距離あるものだけ
        }
    }

    bool running = true; // ゲームループ継続フラグ
    bool gameOver = false; // ゲームオーバーフラグ
    int turn = 0; // ターン数

    // ゲーム説明を表示して開始待ち
    cout << "A* Chase Game - Controls: W A S D to move, q to quit.\n";
    cout << "Enemies (E) chase you (P) with A* pathfinding. Walk on '.' only.\n";
    cout << "Press any key to start...";
    _getch();

    // メインループ
    while (running) {
        system("cls"); // 画面クリア（Windows専用）
        cout << "Turn: " << turn << "\n";
        render(map, player, enemies);

        // ゲームオーバー処理
        if (gameOver) {
            cout << "Game Over! You were caught. Press q to quit.\n";
            int ch = _getch();
            if (ch == 'q' || ch == 'Q') running = false;
            continue; // 次のループへ（終了待ち）
        }

        cout << "Move (W/A/S/D), q to quit: ";
        int ch = _getch(); // キー入力を待つ
        Vec2 newPlayer = player; // 仮の移動先
        if (ch == 'w' || ch == 'W') newPlayer.y -= 1;
        else if (ch == 's' || ch == 'S') newPlayer.y += 1;
        else if (ch == 'a' || ch == 'A') newPlayer.x -= 1;
        else if (ch == 'd' || ch == 'D') newPlayer.x += 1;
        else if (ch == 'q' || ch == 'Q') { running = false; break; }

        // プレイヤーの移動が有効か確認（範囲・壁・敵）
        if (newPlayer.x >= 0 && newPlayer.x < MAP_W && newPlayer.y >= 0 && newPlayer.y < MAP_H && map[newPlayer.y][newPlayer.x] != '#') {
            bool collideEnemy = false;
            for (auto& e : enemies) if (e == newPlayer) collideEnemy = true;
            if (!collideEnemy) player = newPlayer; // 敵と重ならないなら移動を確定
        }

        // 敵のターン：それぞれ A* でプレイヤーへの経路を計算し、1 ステップだけ進む
        vector<Vec2> newEnemies = enemies; // 更新後の敵位置を格納
        for (size_t i = 0; i < enemies.size(); ++i) {
            Vec2 epos = enemies[i];
            // 自身以外の敵を障害物として渡す
            vector<Vec2> others;
            for (size_t j = 0; j < enemies.size(); ++j) if (j != i) others.push_back(enemies[j]);

            // A* 実行（自身の位置からプレイヤーへ）
            vector<Vec2> path = a_star(map, epos, player, others);
            if (path.size() >= 2) {
                Vec2 step = path[1]; // 1 ステップ分だけ進む
                // 他の敵の新しい位置と衝突しないか確認
                bool blocked = false;
                for (size_t j = 0; j < newEnemies.size(); ++j) if (j != i && newEnemies[j] == step) blocked = true;
                if (!blocked) newEnemies[i] = step; // 衝突しなければ新位置を採用
                else {
                    // 衝突時のフォールバックは現状『動かない』にしている
                }
            }
            else {
                // 経路が見つからない、または既にプレイヤーと同位置ならゲームオーバー判定
                if (epos == player) { gameOver = true; }
            }
        }

        // 更新後の敵位置を反映
        enemies = newEnemies;

        // 移動後にプレイヤーと敵が重なっていないか最終チェック
        for (auto& e : enemies) if (e == player) gameOver = true;

        turn++;
    }

    cout << "Thanks for playing.\n";
    return 0;
}
