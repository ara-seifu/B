// ============================================
// STEP 3 : 2D�ix,z�j�ŋ����m���Փ˂���
// �ړI�F�C���p���X�@�i�@�������̂݁j�̓���
// ============================================

#include <GL/freeglut.h>
#include <cmath>
#include <vector>

// ----------------------------------------------------
// 2D�x�N�g���ix,z�j�����ŕ����������iy�͌Œ�j
// ----------------------------------------------------
struct Vec2 {
    float x, z;
    Vec2(float x = 0, float z = 0) : x(x), z(z) {}

    Vec2 operator+(const Vec2& o) const { return Vec2(x + o.x, z + o.z); }
    Vec2 operator-(const Vec2& o) const { return Vec2(x - o.x, z - o.z); }
    Vec2 operator*(float s) const { return Vec2(x * s, z * s); }
};

// ����
float dot(const Vec2& a, const Vec2& b) {
    return a.x * b.x + a.z * b.z;
}

// ���K��
Vec2 normalize(const Vec2& v) {
    float len = std::sqrt(v.x * v.x + v.z * v.z);
    if (len == 0) return Vec2(0, 0);
    return Vec2(v.x / len, v.z / len);
}

// ----------------------------------------------------
// ���i�ʒu�� x,z�Ay ���Œ�l�ɂ��ĕ`��p�Ɏg���j
// ----------------------------------------------------
struct Ball {
    Vec2 pos;     // 2D�ʒu (x,z)
    Vec2 vel;     // 2D���x (x,z)
    float y;      // �`��p����
    float radius;
    float mass;
};

std::vector<Ball> balls;

// ���ԃX�e�b�v
float dt = 0.016f;

// �����W���i1.0 = ���S�e���j
float restitution = 1.0f;

// ----------------------------------------------------
// �������F2�̋��������������ďՓ�
// ----------------------------------------------------
void initBalls() {
    balls.clear();
    balls.resize(2);

    balls[0].pos = Vec2(-4, 0);
    balls[0].vel = Vec2(+3, 0);
    balls[0].radius = 1.0f;
    balls[0].mass = 1.0f;
    balls[0].y = 1.0f;

    balls[1].pos = Vec2(+4, 0);
    balls[1].vel = Vec2(-2, 0);
    balls[1].radius = 1.0f;
    balls[1].mass = 1.0f;
    balls[1].y = 1.0f;
}

// ----------------------------------------------------
// 2D �C���p���X�Փˁi�@�������̂݁j
// ----------------------------------------------------
void collideBalls(Ball& a, Ball& b)
{
    Vec2 diff = b.pos - a.pos;
    float dist = std::sqrt(dot(diff, diff));
    float rsum = a.radius + b.radius;

    if (dist < rsum) {
        // ---- �@���x�N�g���ia��b�j ----
        Vec2 n = normalize(diff);

        // ---- ���Α��x ----
        Vec2 rv = b.vel - a.vel;
        float relVel = dot(rv, n);  // �@�������̑��Α��x

        // ����Ă���Ȃ�Փˏ������Ȃ�
        if (relVel > 0) return;

        // ---- �C���p���X�̑傫�� j ----
        float j = -(1 + restitution) * relVel;
        j /= (1.0f / a.mass + 1.0f / b.mass);

        // ---- ���x���C�� ----
        Vec2 impulse = n * j;

        a.vel = a.vel - impulse * (1.0f / a.mass);
        b.vel = b.vel + impulse * (1.0f / b.mass);

        // ---- �߂荞�݉��� ----
        float penetration = rsum - dist;
        Vec2 correction = n * (penetration * 0.5f);

        a.pos = a.pos - correction;
        b.pos = b.pos + correction;
    }
}

// ----------------------------------------------------
// update
// ----------------------------------------------------
void update() {
    // �ʒu�X�V
    for (auto& b : balls) {
        b.pos = b.pos + b.vel * dt;
    }

    // �Փ�
    collideBalls(balls[0], balls[1]);
}

// ----------------------------------------------------
// timer
// ----------------------------------------------------
void timer(int v) {
    update();
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

// ----------------------------------------------------
// �`��
// ----------------------------------------------------
void drawSphere(const Ball& b, float r, float g, float bl)
{
    glColor3f(r, g, bl);
    glPushMatrix();
    glTranslatef(b.pos.x, b.y, b.pos.z);
    glutSolidSphere(b.radius, 24, 24);
    glPopMatrix();
}

void drawFloor()
{
    glDisable(GL_LIGHTING);
    glColor3f(0.3f, 0.3f, 0.3f);

    glBegin(GL_QUADS);
    glVertex3f(-10, 0, -10);
    glVertex3f(10, 0, -10);
    glVertex3f(10, 0, 10);
    glVertex3f(-10, 0, 10);
    glEnd();

    glEnable(GL_LIGHTING);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // --- ���e ---
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60, 16.0 / 9.0, 0.1, 1000);

    // --- �J���� ---
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(15, 10, 15,   // camera pos
        0, 0, 0,      // target
        0, 1, 0);     // up

    // ���C�g
    GLfloat lightPos[] = { 10,20,10,1 };
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

    // ��
    drawFloor();

    // ��
    drawSphere(balls[0], 0.9f, 0.2f, 0.2f);
    drawSphere(balls[1], 0.2f, 0.2f, 0.9f);

    glutSwapBuffers();
}

// ----------------------------------------------------
// main
// ----------------------------------------------------
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1280, 720);
    glutCreateWindow("STEP 3 :  2D�ix,z�j�ŋ����m���Փ˂���");

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    initBalls();

    glutDisplayFunc(display);
    glutTimerFunc(16, timer, 0);

    glutMainLoop();
    return 0;
}
