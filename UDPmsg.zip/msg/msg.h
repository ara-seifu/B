#define _CRT_SECURE_NO_WARNINGS

#include <windows.h>
#include <stdio.h>
#include <process.h>
#include <synchapi.h>
#include "resource.h"

#pragma comment(lib,"ws2_32.lib")


                                                     
#define BLOADCAST_ADR         "192.168.20.255"           // 200�����̃u���[�h�L���X�g�A�h���X





#define MSG_PORT			1025
#define BUFSIZE             1024
#define STRSIZE             128


extern WSADATA				g_wsadata			    ;			    // winsock dll
extern SOCKET				g_sock          	    ;
extern HWND					g_hwndList			    ;				// ���X�g�{�b�N�X�̃n���h��
extern HINSTANCE			g_hInst				    ;
extern HWND					g_hWnd				    ;
extern char                 g_myName[BUFSIZE]       ;
extern char                 g_ipaddress[STRSIZE]    ;



LRESULT CALLBACK decideMyName(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
int  initReceiveSocket(void)        ;
int  broadcastMessage(void)         ;
int  closeSocket(void)              ;
void ServerThread(void* lpvoid)     ;
int  sendMessageToRemotehost(char* remotehostIP, char* msg) ;
void addList(char* from, char* ip)  ;
