//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// Resource.rc �Ŏg�p
//
#define IDD_MAINDIALOG                  101
#define IDD_DIALOG1                     103
#define IDD_STARTDLG                    103
#define IDC_EDIT1                       1001
#define IDC_EDIT                        1001
#define IDC_EDIT_MYNAME                 1001
#define IDC_MESSAGE                     1001
#define IDC_LIST1                       1002
#define IDC_LIST                        1002
#define IDC_SEND                        1003
#define IDC_UPDATE                      1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
