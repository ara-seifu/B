﻿// ボールを横に投げるシミュレーション (C++/GLUT)

#include <GL/glut.h>
#include <cmath>
#include <vector>

// ウィンドウサイズ
const int WIN_W = 800;
const int WIN_H = 600;
constexpr double PI = 3.14159265358979323846;

// 物理定数
const float g  = 9.8f  ;            // 重力加速度 (m/s^2)
const float dt = 0.016f;            // タイムステップ (秒) ≒ 60fps
const float restitution    = 0.6f ; // 反発係数
const float groundFriction = 0.98f; // 接地摩擦

// スケーリング（物理m→画面px）
const float SCALE = 80.0f   ;      

// ボール状態
struct Vec2 { float x, y; };
Vec2 pos = { 0.5f, 7.0f };      // 初期位置 (m) 
Vec2 vel = { 4.0f, 0.0f };      // 初速度 (m/s) 
const float ballRadius = 0.1f;  // 0.1m（半径）


// 軌跡を保存する配列
std::vector<Vec2> trail;

//-------------------------------------------------------
//    drawCircle() 　円を表示する（２Ｄ表示の為に独自で用意）
//-------------------------------------------------------
void drawCircle(float radius, int segments) 
{
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(0, 0); // 中心
    for (int i = 0; i <= segments; i++) {
        float theta = 2.0f * PI * float(i) / float(segments);
        float x = radius * cosf(theta);
        float y = radius * sinf(theta);
        glVertex2f(x, y);
    }
    glEnd();
}

//-------------------------------------------------------
//    display() 　描画用イベントハンドラ
//-------------------------------------------------------
void display() 
{

    glClear(GL_COLOR_BUFFER_BIT);

    // 軌跡の描画
    if (!trail.empty()) {
        glColor3f(1, 1, 0); // 黄色い線
        glBegin(GL_LINE_STRIP);
        for (auto& p : trail) {
            glVertex2f(p.x * SCALE, p.y * SCALE);
        }
        glEnd();
    }

    // ボール描画 
    glPushMatrix();
    glTranslatef(pos.x * SCALE, pos.y * SCALE, 0.0f);
    glColor3f(1, 0, 0);
    drawCircle(ballRadius * SCALE, 64);  // OpenGLでは２Ｄで円は描けないので自前の関数を呼び出し
    glPopMatrix();



    glutSwapBuffers();  // ダブルバッファリング

}

//-------------------------------------------------------
//    update() 　タイマーから起動されるイベントハンドラ
//-------------------------------------------------------
void update(int value) 
{
    // 前フレームの中心高さ
    float prevY = pos.y;

    // --- 速度更新（重力） ---
    // vel は中心の速度（yが下向きに負になる方向）
    vel.y += -g * dt; // 下向きに負の増加

    // 予測（中心）
    float nextX = pos.x + vel.x * dt;
    float nextY = pos.y + vel.y * dt;

   
    pos.x = nextX;
    pos.y = nextY;

        // 軌跡に追加
    trail.push_back(pos); // ボールの現在位置 pos を軌跡リスト trail の末尾に追加する
  

    if (pos.x * SCALE > WIN_W || pos.y * SCALE < 0 || pos.y * SCALE > WIN_H) { // 繰り返し
        pos = { 0.5f, 7.0f };   // 初期位置
        vel = { 4.0f, 0.0f };   // 初速度
        trail.clear();        // 軌跡リセット
    }

    // 軌跡が増えすぎるなら古い点を削除
    if (trail.size() > 2000) {
        trail.erase(trail.begin(), trail.begin() + 200);
    }

    glutPostRedisplay();
    glutTimerFunc(int(dt * 1000), update, 0);

}

//-------------------------------------------------------
//    reshape() 　サイズ変更時のイベントハンドラ
//-------------------------------------------------------
void reshape(int w, int h) 
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WIN_W, 0, WIN_H);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

}

//-------------------------------------------------------
//    main()
//-------------------------------------------------------
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("ボールを横に投げる");

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(int(dt * 1000), update, 0);

    glutMainLoop();
 
    return 0;

}
