﻿#include <GL/glut.h> 
#include <cmath>
#include <vector>
#include <ctime>

struct HomingBullet {
    float x, y;
    float vx, vy;   // 速度ベクトル
    float speed;    // 最大速度
};

std::vector<HomingBullet> bullets;

// プレイヤー位置
float playerX = 0.0f;
float playerY = -0.8f;
// 敵位置
float enemyX = 0.0f;
float enemyY = 0.8f;

int lastTime = 0;
float shootTimer = 0.0f; // 自動発射タイマー

// キー状態
bool keyState[256] = { false };
bool specialKeyState[256] = { false };

// 移動範囲
const float minX = -1.0f;
const float maxX = 1.0f;
const float minY = -1.0f;
const float maxY = 1.0f;

// --- 弾を自機に向けて発射 ---
void shootHoming(float speed) {
    HomingBullet b;
    b.x = enemyX;
    b.y = enemyY;
    b.speed = speed;

    // 初期速度（下方向へ発射）
    b.vx = 0.0f;
    b.vy = -speed;

    bullets.push_back(b);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー（青）
    glPointSize(10.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(playerX, playerY);
    glEnd();

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 自機追尾弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    float moveSpeed = 1.0f * dt;

    // --- プレイヤー移動（矢印キー） ---
    if (specialKeyState[GLUT_KEY_LEFT])  playerX -= moveSpeed;
    if (specialKeyState[GLUT_KEY_RIGHT]) playerX += moveSpeed;
    if (specialKeyState[GLUT_KEY_UP])    playerY += moveSpeed;
    if (specialKeyState[GLUT_KEY_DOWN])  playerY -= moveSpeed;

    // --- 画面端制御 ---
    if (playerX < minX) playerX = minX;
    if (playerX > maxX) playerX = maxX;
    if (playerY < minY) playerY = minY;
    if (playerY > maxY) playerY = maxY;

    // --- 手動発射 ---
    if (keyState[' ']) shootHoming(0.5f);

    // --- 自動発射（0.5秒間隔） ---
    shootTimer += dt;
    if (shootTimer > 0.5f) {
        shootHoming(0.5f);
        shootTimer = 0.0f;
    }

    // --- 弾の追尾更新（慣性付き） ---
    for (auto& b : bullets) {
        // プレイヤー方向
        float dx = playerX - b.x;
        float dy = playerY - b.y;
        float dist = sqrt(dx * dx + dy * dy);

        if (dist > 0.001f) {
            // 目標方向の単位ベクトル
            float tx = dx / dist;
            float ty = dy / dist;

            // 旋回率（どれくらいその理想方向に「寄せる」かを決める係数(小さいほどゆるやかに追尾）)
            float turnRate = 1.6f * dt;

            // 速度ベクトルを少しずつ目標方向に寄せる
            b.vx = (1 - turnRate) * b.vx + turnRate * tx * b.speed;
            b.vy = (1 - turnRate) * b.vy + turnRate * ty * b.speed;

            // 正規化して速度一定に
            float vlen = sqrt(b.vx * b.vx + b.vy * b.vy);
            if (vlen > 0.001f) {
                b.vx = b.vx / vlen * b.speed;
                b.vy = b.vy / vlen * b.speed;
            }
        }

        // 速度で位置更新
        b.x += b.vx * dt;
        b.y += b.vy * dt;
    }

    glutPostRedisplay();
}
 
// --- キー押下・離上 ---
void keyDown(unsigned char key, int, int) { keyState[key] = true; }
void keyUp(unsigned char key, int, int) { keyState[key] = false; }
void specialDown(int key, int, int) { specialKeyState[key] = true; }
void specialUp(int key, int, int) { specialKeyState[key] = false; }

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("慣性付き追尾弾（Space:発射／矢印キー:移動）");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    glutKeyboardFunc(keyDown);
    glutKeyboardUpFunc(keyUp);
    glutSpecialFunc(specialDown);
    glutSpecialUpFunc(specialUp);

    glutMainLoop();
    return 0;
}
