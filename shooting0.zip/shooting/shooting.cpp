﻿#include <GL/glut.h>    // OpenGL Utility Toolkit のヘッダ
#include <cmath>        // 三角関数や数学関数を使うためのヘッダ
#include <vector>       // 動的配列（弾リスト用）
#include <chrono>       // 時間計測に使用
#include <algorithm>    // remove_if などを使うためのヘッダ

// 円周率の定義
constexpr float PI = 3.14159265358979323846f;

// ウィンドウサイズ
const int WIDTH  = 600;   // 横幅
const int HEIGHT = 600;   // 縦幅

// 弾の情報を保持する構造体
struct Bullet {
    float  x, y;   // 位置座標
    float vx, vy;   // 速度（単位: 座標/秒）
};

// 発射された弾を格納するコンテナ
std::vector<Bullet> bullets;

// プレイヤーの位置
float playerX =  0.0f;   // プレイヤーのX座標（画面中央）
float playerY = -0.8f;   // プレイヤーのY座標（画面下寄り）

// 前フレームの時間を記録する変数
std::chrono::high_resolution_clock::time_point prevTime;

// --- 弾発射関数 ---
// 引数 speed        : 弾速（座標/秒）
void shoot(float speed) {
    float angle = PI / 2.0f; // 基準角度（90度＝真上）

    // 新しい弾を作成
    Bullet b;

    b.x = playerX;                 // 発射位置はプレイヤー位置
    b.y = playerY;

    b.vx = speed * cosf(angle) ;    // 速度X成分
    b.vy = speed * sinf(angle) ;    // 速度Y成分

    // リストに追加
    bullets.push_back(b);
}

// --- 描画処理 ---
void display() {
    // 前フレームからの経過時間 Δt を計算（単位: 秒）
    auto now = std::chrono::high_resolution_clock::now();
    std::chrono::duration<float> elapsed = now - prevTime;
    float dt = elapsed.count(); // 経過時間
    prevTime = now;             // 今回の時間を記録

    // 画面をクリア
    glClear(GL_COLOR_BUFFER_BIT);

    // --- プレイヤー描画 ---
    glColor3f(0.0f, 1.0f, 0.0f); // 緑色
    glBegin(GL_TRIANGLES);       // 三角形で描画
    glVertex2f(playerX, playerY);               // 上の頂点
    glVertex2f(playerX - 0.05f, playerY - 0.1f);// 左下の頂点
    glVertex2f(playerX + 0.05f, playerY - 0.1f);// 右下の頂点
    glEnd();

    // --- 弾の更新 ---
    for (auto& b : bullets) {
        b.x += b.vx * dt; // Δx = vx * Δt
        b.y += b.vy * dt; // Δy = vy * Δt
    }

    // --- 画面外の弾を削除 ---
    // -1.2〜1.2 の範囲外に出た弾は消す
    bullets.erase(std::remove_if(bullets.begin(), bullets.end(),
        [](const Bullet& b) {
            return (b.x < -1.2f || b.x > 1.2f || b.y < -1.2f || b.y > 1.2f);
        }), bullets.end());

    // --- 弾の描画 ---
    glColor3f(1.0f, 0.0f, 0.0f); // 赤色
    glPointSize(5.0f);           // 点の大きさを指定
    glBegin(GL_POINTS);
    for (const auto& b : bullets) {
        glVertex2f(b.x, b.y);    // 各弾を描画
    }
    glEnd();

    // バッファを入れ替えて画面表示
    glutSwapBuffers();
}

// --- 毎フレーム更新処理 ---
void idle() {
    glutPostRedisplay(); // 再描画を要求
}

// --- キーボード入力処理 ---
void keyboard(unsigned char key, int x, int y) {
    if (key == ' ') {
        // スペースキーが押されたら弾を発射
        // 速度 = 0.6 (座標/秒)
        shoot(0.6f);
    }
}

// --- 初期化処理 ---
void init() {
    glClearColor(0, 0, 0, 1);        // 背景を黒に設定
    glMatrixMode(GL_PROJECTION);     // 投影行列モードに切り替え
    glLoadIdentity();                // 単位行列にリセット
    gluOrtho2D(-1, 1, -1, 1);        // 2D直交投影（描画範囲を -1〜1 に設定）
}

// --- メイン関数 ---
int main(int argc, char** argv) {
    glutInit(&argc, argv);                          // GLUT初期化
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);    // ダブルバッファ＋RGBモード
    glutInitWindowSize(WIDTH, HEIGHT);              // ウィンドウサイズ指定
    glutCreateWindow("シューティングスケルトン");          // ウィンドウ生成

    init(); // 初期化処理

    // コールバック関数の登録
    glutDisplayFunc(display);   // 描画処理
    glutIdleFunc(idle);         // フレーム更新処理
    glutKeyboardFunc(keyboard); // キー入力処理

    // 初期の時間を記録
    prevTime = std::chrono::high_resolution_clock::now();

    // メインループ開始
    glutMainLoop();
    return 0;
}