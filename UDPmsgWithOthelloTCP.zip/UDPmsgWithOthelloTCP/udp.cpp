#include "msg.h"
#include "othello.h"

BOOL            g_UDPEndflag;
char            g_recvString[BUFSIZE];
char            g_enemyIP[STRSIZE];
char            g_enemyName[STRSIZE];
//============================�@online ��������@==============================================
//----------------------------------------------------------------------
int inviteGameToRemotehost(char* remotehostIP)
{
    unsigned short port = MSG_PORT;
    SOCKET      sock;
    int         size;
    struct sockaddr_in server_addr = { 0 };
    char s[BUFSIZE];
    int  sendSize;
    int len = sizeof(struct sockaddr_in);

    sprintf_s(s, "GAM %s %s", g_myName, g_ipaddress);

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(remotehostIP);
    server_addr.sin_port = htons(port);

    // 2.�\�P�b�g����(socket())
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == INVALID_SOCKET) {
        return -2;
    }

    // 3.���M�isendto())
    size = (int)strlen(s) + 1;
    sendSize = sendto(sock, s, size, 0, (sockaddr*)&server_addr, sizeof(sockaddr));
    if (sendSize != size) {
        closesocket(sock);
        return -3;
    }

    closesocket(sock);
    return(0);
}

//----------------------------------------------------------------------
int acceptGameToRemotehost(char* remotehostIP)
{
    unsigned short port = MSG_PORT;
    SOCKET      sock;
    int         size;
    struct sockaddr_in server_addr = { 0 };
    char s[BUFSIZE];
    int  sendSize;
    int len = sizeof(struct sockaddr_in);

     sprintf_s(s, "GOK %s %s", g_myName, g_ipaddress);

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(remotehostIP);
    server_addr.sin_port = htons(port);

    // 2.�\�P�b�g����(socket())
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == INVALID_SOCKET) {
        return -2;
    }

    // 3.���M�isendto())
    size = (int)strlen(s) + 1;
    sendSize = sendto(sock, s, size, 0, (sockaddr*)&server_addr, sizeof(sockaddr));
    if (sendSize != size) {
        closesocket(sock);
        return -3;
    }

    closesocket(sock);
    return(0);
}

//----------------------------------------------------------------------
int refuseGameToRemotehost(char* remotehostIP)
{
    unsigned short port = MSG_PORT;
    SOCKET      sock;
    int         size;
    struct sockaddr_in server_addr = { 0 };
    char s[BUFSIZE];
    int  sendSize;
    int len = sizeof(struct sockaddr_in);

    sprintf_s(s, "GNG %s %s", g_myName, g_ipaddress);


    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(remotehostIP);
    server_addr.sin_port = htons(port);

    // 2.�\�P�b�g����(socket())
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == INVALID_SOCKET) {
        return -2;
    }

    // 3.���M�isendto())
    size = (int)strlen(s) + 1;
    sendSize = sendto(sock, s, size, 0, (sockaddr*)&server_addr, sizeof(sockaddr));
    if (sendSize != size) {
        closesocket(sock);
        return -3;
    }

    closesocket(sock);
    return(0);
}

//----------------------------------------------------------------------
int closeUDPSocket(void)
{
    // 5.�\�P�b�g�N���[�Y(closesocket())
//    closesocket(g_UDPsock)             ;   // ���b�Z�[�W�p
//    closesocket(g_accept_socket)    ;   //�@�Q�[���p

    g_UDPEndflag = TRUE;

    // 6.Winsock���I��
    WSACleanup();

    return 0;
}


//----------------------------------------------------------------------
char* ReturnMyIpAddress(void)		//�@gethostname()��windows�̃o�O�i�H�j�ŃG���[���b�Z�[�W�o�邯�ǋC�ɂ��Ȃ��Ă���
{
    int			re;
    char		name[STRSIZE], * ip = NULL;
    PHOSTENT	hostinfo;

    re = gethostname(name, sizeof(name));
    if (re == 0) {
        if ((hostinfo = gethostbyname(name)) != NULL) {
            ip = inet_ntoa(*(struct in_addr*)*hostinfo->h_addr_list);
            strcpy_s(g_ipaddress, ip);
        }
    }

    return ip;
}



//----------------------------------------------------------------------
int initReceiveSocket(void)
{
    unsigned short port = MSG_PORT;
    struct sockaddr_in server_addr = { 0 };

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);   // ������NIC�ւ̃A�N�Z�X��F�߂�
    server_addr.sin_port = htons(port);
 
    //   // 1. Winsock���J�n(WSAStartup())
    if (WSAStartup(MAKEWORD(2, 2), &g_wsadata) == SOCKET_ERROR) {
        WSACleanup();
        return -1;
    }

    // 2.�\�P�b�g����(socket())
    g_UDPsock = socket(AF_INET, SOCK_DGRAM, 0);
    if (g_UDPsock == INVALID_SOCKET) {
        return -2;
    }

    // 3. �\�P�b�g�o�^(bind())
    if (bind(g_UDPsock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        return -3;

    }
    ReturnMyIpAddress();

    _beginthread(ServerThread, 0, NULL);	            // ��M�X���b�h�N��	

    return(0);

}



//----------------------------------------------------------------------
int broadcastMessage(void)
{
    char s[STRSIZE];
    int yes = 1;
    int  sendSize;
    struct sockaddr_in server_addr = { 0 };
    unsigned short port = MSG_PORT;
    SOCKET sock1;

    
    // 2.�\�P�b�g����(socket())
    sock1 = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock1 == INVALID_SOCKET) {
        return -2;
    }

    // �u���[�h�L���X�g�ł���悤�ɐݒ�
    if (setsockopt(sock1, SOL_SOCKET, SO_BROADCAST, (char*)&yes, sizeof(yes)) != 0) {
           return -3;
    }

    sprintf_s(s, "WHO %s %s", g_myName, g_ipaddress);


    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(BLOADCAST_ADR);
    server_addr.sin_port = htons(port);

    // 3.���M�isendto())
    sendSize = sendto(sock1, s, (int)strlen(s)+1, 0, (sockaddr*)&server_addr, sizeof(sockaddr));
    if (sendSize != strlen(s)+1) {
        MessageBox(NULL, (LPCSTR)"send error", s, MB_OK);
         return -4;
    }

    closesocket(sock1);

    return(0);
}



//----------------------------------------------------------------------
int tellWhoIam(char* remotehostIP)
{
    unsigned short port = MSG_PORT;
    SOCKET      sock;
    struct sockaddr_in server_addr = { 0 };
    int         size;

    char s[BUFSIZE];


    int  sendSize;
    int len = sizeof(struct sockaddr_in);

    sprintf_s(s, "IAM %s %s", g_myName, g_ipaddress)    ;


    server_addr.sin_family = AF_INET    ;
    server_addr.sin_addr.s_addr = inet_addr(remotehostIP)   ;
    server_addr.sin_port = htons(port)  ;



    // 2.�\�P�b�g����(socket())
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock == INVALID_SOCKET) {
        return -2;
    }

    size = (int)strlen(s) + 1   ;

    // 3.���M�isendto())
    sendSize = sendto(sock, s, size, 0, (sockaddr*)&server_addr, sizeof(sockaddr));
    if (sendSize != size) {
        closesocket(sock)   ;
        return -3   ;
    }

    closesocket(sock);
    return(0)   ;
}

//----------------------------------------------------------------------
int sendMessageToRemotehost(char *remotehostIP, char* msg)
{
    unsigned short port = MSG_PORT  ;
    SOCKET      sock    ;
    int         size    ;
    struct sockaddr_in server_addr = { 0 }  ;
    char s[BUFSIZE]     ;
    int  sendSize       ;
    int len = sizeof(struct sockaddr_in)    ;

    sprintf_s(s, "MSG %s %s", g_myName, msg);

    server_addr.sin_family = AF_INET        ;
    server_addr.sin_addr.s_addr = inet_addr(remotehostIP)   ;
    server_addr.sin_port = htons(port)      ;

    // 2.�\�P�b�g����(socket())
    sock = socket(AF_INET, SOCK_DGRAM, 0)   ;
    if (sock == INVALID_SOCKET) {
         return -2  ;
    }

    // 3.���M�isendto())
    size = (int)strlen(s) + 1   ;
    sendSize = sendto(sock, s, size, 0, (sockaddr*)&server_addr, sizeof(sockaddr))  ;
    if (sendSize != size) {
        closesocket(sock)   ;
        return -3           ;
    }

    closesocket(sock)   ;
    return(0)           ;
}



//----------------------------------------------------------------------
void ServerThread(void* lpvoid)		// ��M�X���b�h�iUDP�T�[�o�[���j
{
    char buf[BUFSIZE]   ;
    int  receivedSize   ;
    int  len    = sizeof(struct sockaddr_in)    ;
    int  i      = 0     ;

    struct sockaddr_in	client_addr ;
    g_UDPEndflag = FALSE;

    while (!g_UDPEndflag) {
        receivedSize = recvfrom(g_UDPsock, buf, sizeof(buf), 0, (sockaddr*)&client_addr, &len);
        char* cmd   ;
        char* from  ;
        char* msg   ;
        char* ip    ;
        char  title[BUFSIZE];

        if (receivedSize != SOCKET_ERROR) {

            strcpy_s(g_recvString, buf);

            cmd = from = buf    ;
            while (*from != ' ')
                from++      ;
            *from++ = '\0'  ;

            msg = from;
            while (*msg != ' ')
                msg++       ;
            *msg++ = '\0'   ;

            ip = inet_ntoa(client_addr.sin_addr)    ;

 
            if (!strcmp(cmd, "MSG")) {              // ���b�Z�[�W���͂���
                sprintf_s(title, BUFSIZE - 1, "%s(%s)", from, ip);
                MessageBox(g_hWnd, (LPCSTR)msg, title, MB_OK);
            }

            else if (!strcmp(cmd, "WHO")) {         // �u���[�h�L���X�g���b�Z�[�W���͂���
                addList(from, ip)    ;              // ���X�g�ɒǉ�
                tellWhoIam(ip)      ;              // �ԐM
            }

            else if (!strcmp(cmd, "IAM")) {         // �u���[�h�L���X�g�̕ԐM���͂���
                addList(from, ip); // ���X�g�ɒǉ�
            }

            else if (!strcmp(cmd, "GAM")) {         // �Q�[���̂��U�����͂���
                SendMessage(g_hWnd, MSG_GAMEREQ, 0, 0);
            }
            else if (!strcmp(cmd, "GOK")) {         // �Q�[���̂��U�����������ꂽ
                SendMessage(g_hWnd, MSG_GAMEACCEPT, 0, 0);
            }
            else if (!strcmp(cmd, "GNG")) {         // �Q�[���̂��U�������₳�ꂽ
                SendMessage(g_hWnd, MSG_GAMEREFUSE, 0, 0);
            }



        }

    }
    closesocket(g_UDPsock);
    _endthread()    ;
}
