#include "msg.h"
#include "othello.h"
#include "resource.h"
#include <stdio.h>
#include <stdlib.h>

HWND g_othelloWnd;

char g_player;      // �l�Ԃ̃R�}
char g_turn;        // ME / YOU
BOOL g_isVsCPU;

//-------------------------------------------------
int g_button[LEN][LEN] = {
 {IDC_BUTTON_00,IDC_BUTTON_01,IDC_BUTTON_02,IDC_BUTTON_03,IDC_BUTTON_04,IDC_BUTTON_05,IDC_BUTTON_06,IDC_BUTTON_07},
 {IDC_BUTTON_10,IDC_BUTTON_11,IDC_BUTTON_12,IDC_BUTTON_13,IDC_BUTTON_14,IDC_BUTTON_15,IDC_BUTTON_16,IDC_BUTTON_17},
 {IDC_BUTTON_20,IDC_BUTTON_21,IDC_BUTTON_22,IDC_BUTTON_23,IDC_BUTTON_24,IDC_BUTTON_25,IDC_BUTTON_26,IDC_BUTTON_27},
 {IDC_BUTTON_30,IDC_BUTTON_31,IDC_BUTTON_32,IDC_BUTTON_33,IDC_BUTTON_34,IDC_BUTTON_35,IDC_BUTTON_36,IDC_BUTTON_37},
 {IDC_BUTTON_40,IDC_BUTTON_41,IDC_BUTTON_42,IDC_BUTTON_43,IDC_BUTTON_44,IDC_BUTTON_45,IDC_BUTTON_46,IDC_BUTTON_47},
 {IDC_BUTTON_50,IDC_BUTTON_51,IDC_BUTTON_52,IDC_BUTTON_53,IDC_BUTTON_54,IDC_BUTTON_55,IDC_BUTTON_56,IDC_BUTTON_57},
 {IDC_BUTTON_60,IDC_BUTTON_61,IDC_BUTTON_62,IDC_BUTTON_63,IDC_BUTTON_64,IDC_BUTTON_65,IDC_BUTTON_66,IDC_BUTTON_67},
 {IDC_BUTTON_70,IDC_BUTTON_71,IDC_BUTTON_72,IDC_BUTTON_73,IDC_BUTTON_74,IDC_BUTTON_75,IDC_BUTTON_76,IDC_BUTTON_77}
};

//-------------------------------------------------
void updateButton(UINT id, char c)
{
    char s[2];
    s[0] = c;
    s[1] = '\0';
    SendMessage(GetDlgItem(g_othelloWnd, id), WM_SETTEXT, 0, (LPARAM)s);
}

//-------------------------------------------------
void initField(char f[LEN][LEN])
{
    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            f[y][x] = BLANK;

    f[3][3] = f[4][4] = WHITE;
    f[3][4] = f[4][3] = BLACK;

    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            updateButton(g_button[y][x], f[y][x]);
}

//-------------------------------------------------
char* beInField(char f[LEN][LEN], int y, int x)
{
    if (x < 0 || x >= LEN || y < 0 || y >= LEN) return NULL;
    return &f[y][x];
}

//-------------------------------------------------
int directCount(int y, int x, int dy, int dx, char c, char f[LEN][LEN], int set)
{
    int cnt = 0;
    char* p;

    y += dy; x += dx;

    while ((p = beInField(f, y, x)) && *p != c) {
        if (*p == BLANK) return 0;
        cnt++;
        y += dy; x += dx;
    }

    if (!p) return 0;

    if (set && cnt > 0) {
        y -= dy; x -= dx;
        for (int i = 0; i < cnt; i++) {
            f[y][x] = c;
            updateButton(g_button[y][x], c);
            y -= dy; x -= dx;
        }
    }
    return cnt;
}

//-------------------------------------------------
int setPos(int y, int x, char c, char f[LEN][LEN], int set)
{
    int sum = 0;
    sum += directCount(y, x, -1, 0, c, f, set);
    sum += directCount(y, x, 1, 0, c, f, set);
    sum += directCount(y, x, 0, -1, c, f, set);
    sum += directCount(y, x, 0, 1, c, f, set);
    sum += directCount(y, x, -1, -1, c, f, set);
    sum += directCount(y, x, -1, 1, c, f, set);
    sum += directCount(y, x, 1, -1, c, f, set);
    sum += directCount(y, x, 1, 1, c, f, set);

    if (set && sum > 0) {
        f[y][x] = c;
        updateButton(g_button[y][x], c);
    }
    return sum;
}

//-------------------------------------------------
int caseMyTurn(char f[LEN][LEN], char player)
{
    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            if (f[y][x] == BLANK && setPos(y, x, player, f, 0) > 0)
                return 1;
    return 0;
}

//-------------------------------------------------
int blankCellCount(char f[LEN][LEN])
{
    int n = 0;
    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            if (f[y][x] == BLANK) n++;
    return n;
}

//-------------------------------------------------
BOOL isGameFinished(char f[LEN][LEN])
{
    if (!blankCellCount(f)) return TRUE;
    if (!caseMyTurn(f, BLACK) && !caseMyTurn(f, WHITE)) return TRUE;
    return FALSE;
}

//-------------------------------------------------
int human(char f[LEN][LEN], char p, int x, int y)
{
    if (f[y][x] != BLANK) return 0;
    if (setPos(y, x, p, f, 0) <= 0) return 0;
    return setPos(y, x, p, f, 1);
}

//-------------------------------------------------
int cpu(char f[LEN][LEN], char p)
{
    int best = 0, bx = -1, by = -1;
    for (int y = 0; y < LEN; y++)
        for (int x = 0; x < LEN; x++)
            if (f[y][x] == BLANK) {
                int c = setPos(y, x, p, f, 0);
                if (c > best) {
                    best = c;
                    bx = x; by = y;
                }
            }
    if (best > 0)
        setPos(by, bx, p, f, 1);
    return best;
}

//-------------------------------------------------
void countStone(char f[LEN][LEN], int* black, int* white)
{
    *black = 0;
    *white = 0;

    for (int y = 0; y < LEN; y++) {
        for (int x = 0; x < LEN; x++) {
            if (f[y][x] == BLACK) (*black)++;
            else if (f[y][x] == WHITE) (*white)++;
        }
    }
}

//====================================================================
LRESULT playOthello(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static char field[LEN][LEN];
    static HWND hTurn;
    char s[64];

    switch (msg) {

    case WM_INITDIALOG:
        g_othelloWnd = hWnd;
        initField(field);
        hTurn = GetDlgItem(hWnd, IDC_TURN);
        g_turn = ME;
        SendMessage(hWnd, MSG_MYTURN, 0, 0);
        return TRUE;

    case WM_COMMAND:
    {
        if (g_turn != ME) return TRUE;

        int x = -1, y = -1;
        for (y = 0; y < LEN; y++)
            for (x = 0; x < LEN; x++)
                if (g_button[y][x] == LOWORD(wParam)) goto FOUND;
        return TRUE;

    FOUND:
        if (human(field, g_player, x, y)) {
            if (isGameFinished(field)) {
                SendMessage(hWnd, MSG_FINISHED, 0, 0);
                return TRUE;
            }
            g_turn = YOU;
            SendMessage(hWnd, MSG_COMTURN, 0, 0);
        }
        return TRUE;
    }

    case MSG_MYTURN:
        SendMessage(hTurn, WM_SETTEXT, 0, (LPARAM)"���Ȃ��̃^�[���ł�");
        if (!caseMyTurn(field, g_player)) {
            MessageBox(hWnd, "�łĂ�ꏊ���Ȃ��̂Ńp�X���܂�", "PASS", MB_OK);
            g_turn = YOU;
            SendMessage(hWnd, MSG_COMTURN, 0, 0);
        }
        return TRUE;

    case MSG_COMTURN:
    {
        char cpuPlayer = (g_player == WHITE ? BLACK : WHITE);
        SendMessage(hTurn, WM_SETTEXT, 0, (LPARAM)"�G�̃^�[���ł�");

        if (!caseMyTurn(field, cpuPlayer)) {
            if (isGameFinished(field)) {
                SendMessage(hWnd, MSG_FINISHED, 0, 0);
                return TRUE;
            }
            g_turn = ME;
            SendMessage(hWnd, MSG_MYTURN, 0, 0);
            return TRUE;
        }

        cpu(field, cpuPlayer);

        if (isGameFinished(field)) {
            SendMessage(hWnd, MSG_FINISHED, 0, 0);
            return TRUE;
        }

        g_turn = ME;
        SendMessage(hWnd, MSG_MYTURN, 0, 0);
        return TRUE;
    }

    case MSG_FINISHED:
    {
        int black, white;
        char msg[128];

        countStone(field, &black, &white);

        if (black > white) {
            sprintf_s(msg, "�Q�[���I��\n\n���̏����I\n��:%d  ��:%d", black, white);
        }
        else if (white > black) {
            sprintf_s(msg, "�Q�[���I��\n\n���̏����I\n��:%d  ��:%d", black, white);
        }
        else {
            sprintf_s(msg, "�Q�[���I��\n\n��������\n��:%d  ��:%d", black, white);
        }

        MessageBox(hWnd, msg, "Finished", MB_OK);
        EndDialog(hWnd, 0);
        return TRUE;
    }


    }
    return FALSE;
}
