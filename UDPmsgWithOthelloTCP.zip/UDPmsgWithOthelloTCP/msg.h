#define _CRT_SECURE_NO_WARNINGS
#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <process.h>
#include <synchapi.h>
#include "resource.h"

#pragma comment(lib,"ws2_32.lib")

                                                     
#define BLOADCAST_ADR         "192.168.20.255"           // �u���[�h�L���X�g�A�h���X�@�@200����
//#define BLOADCAST_ADR         "192.168.21.255"           // �u���[�h�L���X�g�A�h���X   201����
//#define BLOADCAST_ADR         "192.168.26.255"           // �u���[�h�L���X�g�A�h���X   203����
//#define BLOADCAST_ADR         "192.168.0.255"           // �u���[�h�L���X�g�A�h���X   ����




#define MSG_PORT			1024
#define GAME_PORT			1025


#define BUFSIZE             1024
#define STRSIZE             128


#define GAME_NOT_START      0
#define GAME_SERVER_STATE   1
#define GAME_CLIENT_STATE   2





extern WSADATA				g_wsadata			    ;			    // winsock dll
extern SOCKET				g_UDPsock          	    ;
extern HWND					g_hwndList			    ;				// ���X�g�{�b�N�X�̃n���h��
extern HINSTANCE			g_hInst				    ;
extern HWND					g_hWnd				    ;
extern char                 g_myName[BUFSIZE]       ;
extern char                 g_ipaddress[STRSIZE]    ;
extern char                 g_recvString[BUFSIZE]   ;
extern char                 g_recvString2[BUFSIZE];
extern HWND                 g_othelloWnd            ;
extern char                 g_enemyIP[STRSIZE]      ;
extern char                 g_enemyName[STRSIZE]    ;





LRESULT CALLBACK decideMyName(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)        ;
int sendQuitInformationToRemotehost2(void);
int closeUDPSocket(void);
int  broadcastMessage(void)                     ;
int  closeTCPSocket2(void)                          ;
void ServerThread(void* lpvoid)                 ;
int  sendMessageToRemotehost(char* remotehostIP, char* msg)         ;
int inviteGameToRemotehost(char* remotehostIP);
int acceptGameToRemotehost(char* remotehostIP);
int refuseGameToRemotehost(char* remotehostIP);
void addList(char* from, char* ip)              ;
int  initReceiveSocket(void)                    ;
int	 BeginGameServer2(unsigned short port)       ;
int ConnectToOthello2(unsigned short port, char* ip);