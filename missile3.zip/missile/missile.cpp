﻿#define _USE_MATH_DEFINES

#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <ctime>

using std::sin;
using std::cos;
using std::atan2;
using std::sqrt;

// ---------------------------- 定数 ----------------------------
const int WIN_W = 1200;
const int WIN_H = 800;
const float DT = 0.016f;          // 60FPS
const float WORLD_X = 500.0f;
const float WORLD_Y = 350.0f;

const float TARGET_SPEED = 120.0f;
const float TARGET_MAX_TURN_RATE = 1.5f; // rad/s
const float MISSILE_SPEED = 200.0f;
const float MISSILE_TURN_RATE = 2.2f;    // rad/s

const float MISSILE_HIT_DIST = 15.0f;
const float MISSILE_LOST_DIST = 600.0f;
const float MISSILE_LOST_TIME = 2.0f;

// ---------------------------- 構造体 ----------------------------
struct Vec2 {
    float x, y;
    Vec2(float X = 0, float Y = 0) :x(X), y(Y) {}
    Vec2 operator+(const Vec2& o)const { return Vec2(x + o.x, y + o.y); }
    Vec2 operator-(const Vec2& o)const { return Vec2(x - o.x, y - o.y); }
    Vec2 operator*(float s)const { return Vec2(x * s, y * s); }
};

struct Trail {
    std::vector<Vec2> pts;
    void add(const Vec2& p) {
        pts.push_back(p);
        if (pts.size() > 500) pts.erase(pts.begin());
    }
    void draw(float r, float g, float b) {
        glColor3f(r, g, b);
        glBegin(GL_LINE_STRIP);
        for (auto& p : pts) glVertex2f(p.x, p.y);
        glEnd();
    }
};

struct Entity {
    Vec2 pos, vel;
    float heading;
    Trail trail;
    void addTrail() { trail.add(pos); }
};

Entity target, missile;

// ---------------------------- シミュレーション状態 ----------------------------
enum SimState { RUNNING, HIT, LOST };
SimState simState = RUNNING;
float lostTimer = 0.0f;

// ---------------------------- ユーティリティ ----------------------------
float frand(float a, float b) { return a + (b - a) * (rand() / (float)RAND_MAX); }
float wrapAngle(float a) { while (a > M_PI) a -= 2 * M_PI; while (a < -M_PI) a += 2 * M_PI; return a; }
float clamp(float v, float mn, float mx) { return (v < mn ? mn : (v > mx ? mx : v)); }


void initSimulation();

// ---------------------------- ターゲット更新 ----------------------------
void updateTarget(float dt) {
    static float tAccum = 0.0f;
    tAccum += dt;

    float dHeading = 0.6f * sin(0.7f * tAccum) + 0.4f * sin(1.3f * tAccum + 2.0f);

    // 端に近づいたらUターン
    float marginX = WORLD_X * 0.85f, marginY = WORLD_Y * 0.85f;
    if (target.pos.x > marginX) dHeading += 1.5f;
    if (target.pos.x < -marginX) dHeading += -1.5f;
    if (target.pos.y > marginY) dHeading += -1.5f;
    if (target.pos.y < -marginY) dHeading += 1.5f;

    dHeading = clamp(dHeading, -TARGET_MAX_TURN_RATE, TARGET_MAX_TURN_RATE);
    target.heading = wrapAngle(target.heading + dHeading * dt);
    target.vel = Vec2(cos(target.heading), sin(target.heading)) * TARGET_SPEED;
    target.pos = target.pos + target.vel * dt;
    target.addTrail();
}

// ---------------------------- ミサイル更新 ----------------------------
void updateMissile(float dt) {
    // 相対位置ベクトル r = ターゲット位置 - ミサイル位置
    Vec2 r = target.pos - missile.pos;
    // ターゲットの速度ベクトル
    Vec2 v = target.vel;
    // ミサイルの速度（一定）
    float s = MISSILE_SPEED;

    // 距離の2乗（r^2）、ターゲット速度の2乗（v^2）、内積 r·v
    float r2 = r.x * r.x + r.y * r.y;
    float v2 = v.x * v.x + v.y * v.y;
    float rv = r.x * v.x + r.y * v.y;

    // 二次方程式の係数（t は衝突までの時間）
    // ||r + v*t|| = s*t を展開 → A t^2 + B t + C = 0
    float A = v2 - s * s;
    float B = 2 * rv;
    float C = r2;

    float t = 0.0f; // 迎撃までの時間

    if (fabs(A) < 1e-6f) {
        // A ≈ 0 → 速度差が小さい場合は線形方程式 B t + C = 0 で解く
        if (fabs(B) > 1e-6f) t = -C / B;
    }
    else {
        // 判別式 D = B^2 - 4AC
        float D = B * B - 4 * A * C;
        if (D >= 0) {
            float sqrtD = sqrt(D);
            float t1 = (-B + sqrtD) / (2 * A);
            float t2 = (-B - sqrtD) / (2 * A);
            // 正の解で、より早く衝突する方を選ぶ
            if (t1 > 0 && t2 > 0) t = std::min(t1, t2);
            else if (t1 > 0) t = t1;
            else if (t2 > 0) t = t2;
        }
    }

    // 迎撃点 aim = t 秒後のターゲット位置
    // 解がない場合は現在のターゲット位置を狙う
    Vec2 aim = (t > 0) ? target.pos + v * t : target.pos;

    // ミサイルから迎撃点までの相対ベクトル
    float dx = aim.x - missile.pos.x;
    float dy = aim.y - missile.pos.y;
    // 目標角度
    float desired = atan2(dy, dx);

    // 現在の向きとの角差を -π..π に丸める
    float diff = wrapAngle(desired - missile.heading);
    // 1フレームで旋回できる最大角度で制限
    diff = clamp(diff, -MISSILE_TURN_RATE * dt, MISSILE_TURN_RATE * dt);

    // ミサイルの向きを更新（再度 wrap で安定化）
    missile.heading = wrapAngle(missile.heading + diff);

    // ミサイルの速度ベクトルを更新（向きに沿う）
    missile.vel = Vec2(cos(missile.heading), sin(missile.heading)) * s;

    // 位置を更新
    missile.pos = missile.pos + missile.vel * dt;

    // 軌跡やパーティクルの演出
    missile.addTrail();
}


// ---------------------------- シミュレーション更新 ----------------------------
void updateSimulation(float dt) {
    if (simState != RUNNING) return;

    updateTarget(dt);
    updateMissile(dt);

    float dx = target.pos.x - missile.pos.x;
    float dy = target.pos.y - missile.pos.y;
    float dist = sqrt(dx * dx + dy * dy);

    if (dist < MISSILE_HIT_DIST) {
        simState = HIT;
        std::cout << "命中!\n";
        glutTimerFunc(1000, [](int) { initSimulation(); }, 0);
        return;
    }
    if (dist > MISSILE_LOST_DIST) {
        lostTimer += dt;
        if (lostTimer > MISSILE_LOST_TIME) {
            simState = LOST;
            std::cout << "振り切り成功!\n";
            glutTimerFunc(1000, [](int) { initSimulation(); }, 0);
            return;
        }
    }
    else {
        lostTimer = 0.0f;
    }
}

// ---------------------------- 初期化 ----------------------------
void initSimulation() {
    simState = RUNNING;
    lostTimer = 0.0f;

    target.pos = Vec2(frand(-200, 200), frand(-100, 100));
    target.heading = frand(-M_PI, M_PI);
    target.vel = Vec2(cos(target.heading), sin(target.heading)) * TARGET_SPEED;
    target.trail.pts.clear();

    missile.pos = Vec2(0, -200);
    missile.heading = 0.0f;
    missile.vel = Vec2(cos(missile.heading), sin(missile.heading)) * MISSILE_SPEED;
    missile.trail.pts.clear();
}

// ---------------------------- 描画 ----------------------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 軌跡
    target.trail.draw(0.0f, 1.0f, 0.0f);
    missile.trail.draw(1.0f, 0.0f, 0.0f);

    // 戦闘機
    glPushMatrix();
    glTranslatef(target.pos.x, target.pos.y, 0);
    glRotatef(target.heading * 180.0 / M_PI, 0, 0, 1);
    glColor3f(0, 1, 0);
    glBegin(GL_TRIANGLES);
    glVertex2f(15, 0); glVertex2f(-10, 7); glVertex2f(-10, -7);
    glEnd();
    glPopMatrix();

    // ミサイル
    glPushMatrix();
    glTranslatef(missile.pos.x, missile.pos.y, 0);
    glRotatef(missile.heading * 180.0 / M_PI, 0, 0, 1);
    glColor3f(1, 0, 0);
    glBegin(GL_TRIANGLES);
    glVertex2f(12, 0); glVertex2f(-8, 5); glVertex2f(-8, -5);
    glEnd();
    glPopMatrix();

    glutSwapBuffers();
}

// ---------------------------- タイマー ----------------------------
void timer(int) {
    if (simState == RUNNING) updateSimulation(DT);
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

// ---------------------------- メイン ----------------------------
int main(int argc, char** argv) {
    srand((unsigned)time(NULL));
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("熱源追尾ミサイルのシミュレーション（プロジェクタイル迎撃の数式版）");
    glClearColor(0, 0, 0, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-WORLD_X, WORLD_X, -WORLD_Y, WORLD_Y);

    initSimulation();
    glutDisplayFunc(display);
    glutTimerFunc(16, timer, 0);
    glutMainLoop();
    return 0;
}
