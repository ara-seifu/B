﻿#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <chrono>
#include <algorithm>
#include <cstdlib> // rand()

constexpr float PI = 3.14159265358979323846f;

// ウィンドウサイズ
const int WIDTH = 800;
const int HEIGHT = 800;

// 弾の構造体
struct Bullet {
    float x, y;   // 位置
    float vx, vy; // 速度
};

std::vector<Bullet> bullets;

// 発射位置（敵の位置）
float enemyX = 0.0f;
float enemyY = 0.0f;

// 時間管理
std::chrono::high_resolution_clock::time_point prevTime;
float fireTimer = 0.0f;
float fireInterval = 0.05f; // 発射間隔（秒）

// 発射角度
float spiralAngle = 0.0f;
float angleSpeed = PI / 36.0f; // 回転スピード（デフォルト5度）

// --- ランダム回転スパイラル発射 ---
void shootRandomSpiral(float speed, int arms = 4) {
    for (int i = 0; i < arms; i++) {
        float angle = spiralAngle + i * (2 * PI / arms);

        Bullet b;
        b.x = enemyX;
        b.y = enemyY;
        b.vx = cosf(angle) * speed;
        b.vy = sinf(angle) * speed;
        bullets.push_back(b);
    }

    // 角度を進める（ランダム変化あり）
    spiralAngle += angleSpeed;

    // 時々ランダムに回転方向・速さを変更
    if (rand() % 60 == 0) {
        float randomDir = (rand() % 2 == 0) ? 1.0f : -1.0f;
        angleSpeed = randomDir * (PI / (30 + rand() % 60));
        // 3〜9度ぐらいでランダム回転
    }

    if (spiralAngle > 2 * PI) spiralAngle -= 2 * PI;
}

// --- 描画 ---
void display() {
    // Δt計算
    auto now = std::chrono::high_resolution_clock::now();
    std::chrono::duration<float> elapsed = now - prevTime;
    float dt = elapsed.count();
    prevTime = now;

    fireTimer += dt;

    // 一定間隔で発射
    if (fireTimer >= fireInterval) {
        fireTimer = 0.0f;
        shootRandomSpiral(0.6f, 6); // 6本のランダムスパイラル
    }

    glClear(GL_COLOR_BUFFER_BIT);

    // 敵（発射源）
    glColor3f(0.0f, 0.8f, 0.3f);
    glBegin(GL_QUADS);
    glVertex2f(enemyX - 0.05f, enemyY - 0.05f);
    glVertex2f(enemyX + 0.05f, enemyY - 0.05f);
    glVertex2f(enemyX + 0.05f, enemyY + 0.05f);
    glVertex2f(enemyX - 0.05f, enemyY + 0.05f);
    glEnd();

    // 弾の更新
    for (auto& b : bullets) {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
    }

    // 画面外の弾を削除
    bullets.erase(std::remove_if(bullets.begin(), bullets.end(),
        [](const Bullet& b) {
            return (b.x < -1.2f || b.x > 1.2f || b.y < -1.2f || b.y > 1.2f);
        }), bullets.end());

    // 弾の描画
    glColor3f(1.0f, 0.0f, 0.0f);
    glPointSize(4.0f);
    glBegin(GL_POINTS);
    for (const auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

// --- idle更新 ---
void idle() {
    glutPostRedisplay();
}

// --- 初期化 ---
void init() {
    glClearColor(0, 0, 0, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);
}

// --- メイン関数 ---
int main(int argc, char** argv) {
    srand((unsigned)time(NULL));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WIDTH, HEIGHT);
    glutCreateWindow("ランダム回転スパイラル弾");

    init();

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    prevTime = std::chrono::high_resolution_clock::now();

    glutMainLoop();
    return 0;
}
