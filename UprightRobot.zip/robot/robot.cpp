﻿#define _USE_MATH_DEFINES
#include <windows.h>
#include <GL/gl.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>

// アニメーションのフレームレートを固定 (1秒間に60回描画)
#define FPS 60

// 歩行周期を時間で定義  （１周１２秒）
#define WALK_CYCLE_SEC 12.0

// 歩行のステップ周期 (WALK_CYCLE_SECの1/10で１サイクル)
#define STEP_CYCLE_SEC (WALK_CYCLE_SEC / 10.0)


//------------------------------------
// myBox()     箱表示
//------------------------------------
static void myBox(double x, double y, double z){
    GLdouble hx = x * 0.5, hz = z * 0.5;
    GLdouble vertex[][3] = {
      {-hx, -y, -hz}, {hx, -y, -hz}, {hx, 0.0, -hz}, {-hx, 0.0, -hz},
      {-hx, -y,  hz}, {hx, -y,  hz}, {hx, 0.0,  hz}, {-hx, 0.0,  hz}
    };
    const static int face[][4] = {
      {0,1,2,3},{1,5,6,2},{5,4,7,6},{4,0,3,7},{4,5,1,0},{3,2,6,7}
    };
    const static GLdouble normal[][3] = {
      {0,0,-1},{1,0,0},{0,0,1},{-1,0,0},{0,-1,0},{0,1,0}
    };
    const static GLfloat red[] = { 0.8,0.2,0.2,1.0 };
    glMaterialfv(GL_FRONT, GL_DIFFUSE, red);
    glBegin(GL_QUADS);
    for (int j = 0; j < 6; ++j) {
        glNormal3dv(normal[j]);
        for (int i = 3; i >= 0; --i) {
            glVertex3dv(vertex[face[j][i]]);
        }
    }
    glEnd();
}

//------------------------------------
// armleg()     手足表示
//------------------------------------
static void armleg(double girth, double length, double r1, double r2){
    glRotated(r1, 1, 0, 0) ;      // r1回転
    myBox(girth, length, girth);  // 上腕・太腿

    glTranslated(0, -0.05-length, 0);  // 長さ + 0.05 下に
    glRotated(r2, 1, 0, 0)     ;    // r2回転
    myBox(girth, length, girth);    // 腕、下肢
}

//------------------------------------
// myGround()       地面を描画
//------------------------------------
static void myGround(double height){
    const static GLfloat ground[][4] = {
      {0.6,0.6,0.6,1.0}, {0.3,0.3,0.3,1.0}
    };

    glBegin(GL_QUADS);
    glNormal3d(0, 1, 0);
    for (int j = -5; j <= 5; ++j) {     // １０×１０のタイルを敷きつめる
        for (int i = -5; i < 5; ++i) {
            glMaterialfv(GL_FRONT, GL_DIFFUSE, ground[(i + j) & 1]);
            glVertex3d(i, height, j)        ;
            glVertex3d(i, height, j + 1)    ;
            glVertex3d(i + 1, height, j + 1);
            glVertex3d(i + 1, height, j)    ;
        }
    }
    glEnd();
}

//------------------------------------
// display()    
//------------------------------------
// 画面描画用の関数（GLUTのディスプレイコールバックとして登録される）
// キャラクター（人型）を歩行アニメーションで表示する
static void display(void) {
    // 光源位置の設定（x=3, y=4, z=5 の方向から光が当たる）
    const static GLfloat lightpos[] = { 3,4,5,1 };

    // アニメーション用の時間計測変数
    static double total_elapsed_time = 0.0; // 累積経過時間（秒）
    static int prev_time = 0;               // 前フレームの時間（ミリ秒）
    int current_time = glutGet(GLUT_ELAPSED_TIME); // 現在の経過時間（ミリ秒単位）

    // 初回呼び出し時はprev_timeが0なので、現在時刻で初期化
    if (prev_time == 0)
        prev_time = current_time;

    // Δt（経過時間差）を算出（秒単位に変換）
    double delta_time = (current_time - prev_time) / 1000.0;

    // 前フレーム時刻を更新
    prev_time = current_time;

    // 累積経過時間を更新
    total_elapsed_time += delta_time;

    // --- アニメーション用の周期パラメータを算出 ---
    // t: 歩行動作（足の前後運動）サイクル
    double t = fmod(total_elapsed_time, STEP_CYCLE_SEC) / STEP_CYCLE_SEC;
    // s: 位置移動（円運動）サイクル
    double s = fmod(total_elapsed_time, WALK_CYCLE_SEC) / WALK_CYCLE_SEC;


    // 歩行用の正弦波（周期運動）を生成
    double walk = sin(2.0 * M_PI * t);

    double ll1, rl1; // 左右の大腿の角度
    double ll2, rl2; // 左右の脛の角度
    double la1, ra1; // 左右の上腕の角度
    double la2, ra2; // 左右の前腕の角度

    // ロボットの座標(半径3の円を歩く）
    double px;
    double pz;
    double h; // ロボットの高さ（ｙ座標））

    // 向きを進行方向に合わせるための回転角度
    double r ;


    walk = 0.0L;

    // --- 各部位の回転角度を算出 ---
    // 足の動き：左右逆方向に振る（sin波の符号で前後交互に動く）
    ll1 =  0.0;   // 左大腿の基本角度
    rl1 =  0.0;   // 右大腿の基本角度

    // 足の膝関節的な補助動き（前に振るときのみ曲げる）
    ll2 =  0.0;  // 左脛
    rl2 =  0.0;  // 右脛 

    // 腕の動き：足と逆位相に動かす
    la1 =  0.0;  // 左腕
    ra1 =  0.0;  // 右腕

    // 腕の肘の補助動作（後ろに振るときのみ曲げる）
    la2 =  0.0;    // 左肘
    ra2 =  0.0;    // 右肘


//---------------------------------------------------------------------------------
    // --- 位置と姿勢のアニメーション ---
    // キャラクターを円運動で移動させる（半径3の円を歩く）


    // ① sの値によって、ロボットの座標（px,pz）を更新する（高さhは固定値とする）
    px = 0.0L;
    pz = 0.0L;
    h  = 0.05; // 固定値（上下に動かせば自然になるはず）


    // ②向きを進行方向に合わせる為の角度（ｒ）を求める
    r = 0;


//---------------------------------------------------------------------------------



    // --- OpenGLによる描画処理 ---
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // 画面と深度バッファをクリア
    glLoadIdentity(); // モデルビュー行列を初期化

    // 光源位置を設定
    glLightfv(GL_LIGHT0, GL_POSITION, lightpos);

    // カメラ位置を固定（視点位置を設定）
    // 視点 (0,1,10) → 注視点 (0,0,0) → 上方向 (0,1,0)
    gluLookAt(0, 1, 10, 0, 0, 0, 0, 1, 0);

    // 地面を描画
    myGround(-1.8);

    // キャラクターの位置と姿勢を反映
    glTranslated(px, h, pz);   // 円運動による位置移動
    glRotated(r, 0, 1, 0);     // 回転（進行方向に向ける）

    // --- キャラクター本体の描画 --- 

    myBox(0.20, 0.25, 0.22);    // 【頭部】幅0.20、高さ0.25、奥行き0.22の直方体を描画

    glTranslated(0, -0.3, 0);   // 座標系をY方向に -0.3 移動（頭の下に胴体を配置するため）
    myBox(0.4, 0.6, 0.3);       // 【胴体】幅0.4、高さ0.6、奥行き0.3の直方体を描画


    // 各部位（腕や脚）を独立して動かすため、glPushMatrix/glPopMatrixを使う
    // → 現在の座標変換状態（モデル行列）を保存・復元できる

    // --- 左足の描画 ---
    glPushMatrix();              // 現在の変換行列をスタックに保存
    glTranslated(0.1, -0.65, 0); // 胴体の中心から少し左(X=+0.1)、下(Y=-0.65)へ移動して左足の起点位置に
    armleg(0.2, 0.4, ll1, ll2);  // 左足を描画（長さ0.4・太さ0.2・角度ll1, ll2でアニメーション制御）
    glPopMatrix();               // 保存していた行列を復元（次の部位に影響を与えないようにする）

    // --- 右足の描画 ---
    glPushMatrix();              // 現在の変換状態を保存
    glTranslated(-0.1, -0.65, 0);// 胴体の中心から少し右(X=-0.1)、下(Y=-0.65)へ移動して右足の起点位置に
    armleg(0.2, 0.4, rl1, rl2);  // 右足を描画（長さ0.4・太さ0.2・角度rl1, rl2でアニメーション制御）
    glPopMatrix();               // 状態を復元


    // --- 左腕の描画 ---
    glPushMatrix();              // 現在の変換状態を保存
    glTranslated(0.28, 0, 0);    // 胴体の中心から左(X=+0.28)へ移動して左腕の付け根位置に
    armleg(0.16, 0.4, la1, la2); // 左腕を描画（長さ0.4・太さ0.16・角度la1, la2でアニメーション制御）
    glPopMatrix();               // 状態を復元


    // --- 右腕の描画 ---
    glPushMatrix();              // 現在の変換状態を保存
    glTranslated(-0.28, 0, 0);   // 胴体の中心から右(X=-0.28)へ移動して右腕の付け根位置に
    armleg(0.16, 0.4, ra1, ra2); // 右腕を描画（長さ0.4・太さ0.16・角度ra1, ra2でアニメーション制御）
    glPopMatrix();               // 状態を復元（これで全身の描画完了）


    // 描画結果を画面に反映（ダブルバッファリング）
    glutSwapBuffers();
}

//------------------------------------
// timer()      タイマー（再描画を要求）
//------------------------------------
static void timer(int value){
    glutPostRedisplay();
    glutTimerFunc(1000 / FPS, timer, 0);
}

//------------------------------------
// resize()      座標系の変換
//------------------------------------
static void resize(int w, int h){
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(30.0, (double)w / (double)h, 1.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

//------------------------------------
// keyboard()   
//------------------------------------
static void keyboard(unsigned char key, int x, int y){
    if (key == 0x1b || key == 'q') exit(0);
}

//------------------------------------
// init()     
//------------------------------------
static void init(void){
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
}

//------------------------------------
// main()       
//------------------------------------
int main(int argc, char* argv[]){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DEPTH | GLUT_DOUBLE);
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("ロボットの歩行");

    glutDisplayFunc(display);
    glutReshapeFunc(resize);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(1000 / FPS, timer, 0); 

    init();
    glutMainLoop();
    return 0;
}
