﻿#include <GL/glut.h>
#include <cmath>
#include <cstdio>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ウィンドウサイズ
const int WIN_W = 800;
const int WIN_H = 600;

// 2本のアームの長さ
const double L1 = 160.0;
const double L2 = 120.0;

// 関節の角度
// FKでは、この角度から手先の位置を計算する
double theta1 = 0.3;
double theta2 = 0.3;


// --------------------------------------------------
// 円を描画する関数
// --------------------------------------------------
void drawCircle(double x, double y, double r, int segments = 24) {

    glBegin(GL_POLYGON);

    for (int i = 0; i < segments; ++i) {

        double a = (2.0 * M_PI * i) / segments;

        glVertex2d(
            x + std::cos(a) * r,
            y + std::sin(a) * r
        );
    }

    glEnd();
}


// --------------------------------------------------
// 十字を描画する関数
// --------------------------------------------------
void drawCross(double x, double y, double s = 8.0) {

    glBegin(GL_LINES);

    glVertex2d(x - s, y);
    glVertex2d(x + s, y);

    glVertex2d(x, y - s);
    glVertex2d(x, y + s);

    glEnd();
}


// --------------------------------------------------
// 画面描画
// --------------------------------------------------
void display() {

    // 画面を消去
    glClear(GL_COLOR_BUFFER_BIT);


    // ==================================================
    // FK（Forward Kinematics：順運動学）
    // ==================================================
    //
    // 関節角度
    //
    // theta1
    // theta2
    //
    // から、
    //
    // 肘の位置 (x1,y1)
    // 手先の位置 (x2,y2)
    //
    // を計算する
    // ==================================================


    // アームの根元
    double x0 = 0.0;
    double y0 = 0.0;


    // --------------------------------------------------
    // 第1リンク
    //
    // theta1から肘の位置を求める
    //
    // x = L cosθ
    // y = L sinθ
    // --------------------------------------------------

    double x1 = x0 + L1 * std::cos(theta1);
    double y1 = y0 + L1 * std::sin(theta1);


    // --------------------------------------------------
    // 第2リンク
    //
    // theta2は第1リンクからさらに曲がる角度なので、
    //
    // theta1 + theta2
    //
    // が第2リンクの実際の角度になる
    // --------------------------------------------------

    double x2 =
        x1 + L2 * std::cos(theta1 + theta2);

    double y2 =
        y1 + L2 * std::sin(theta1 + theta2);


    // --------------------------------------------------
    // 描画開始
    // --------------------------------------------------

    glPushMatrix();

    // 原点を画面中央へ移動
    glTranslatef(
        WIN_W / 2.0f,
        WIN_H / 2.0f,
        0.0f
    );


    // --------------------------------------------------
    // グリッド
    // --------------------------------------------------

    glColor3f(0.85f, 0.85f, 0.85f);
    glLineWidth(1.0f);

    glBegin(GL_LINES);

    // 縦線
    for (int i = -WIN_W / 2;
        i <= WIN_W / 2;
        i += 40) {

        glVertex2i(i, -WIN_H / 2);
        glVertex2i(i, WIN_H / 2);
    }

    // 横線
    for (int j = -WIN_H / 2;
        j <= WIN_H / 2;
        j += 40) {

        glVertex2i(-WIN_W / 2, j);
        glVertex2i(WIN_W / 2, j);
    }

    glEnd();


    // --------------------------------------------------
    // 第1リンク
    // --------------------------------------------------

    glLineWidth(8.0f);

    // 青色
    glColor3f(0.2f, 0.6f, 1.0f);

    glBegin(GL_LINES);

    // 根元
    glVertex2d(x0, y0);

    // 肘
    glVertex2d(x1, y1);

    glEnd();


    // --------------------------------------------------
    // 根元の関節
    // --------------------------------------------------

    glColor3f(0.1f, 0.1f, 0.1f);

    drawCircle(
        x0,
        y0,
        10.0
    );


    // --------------------------------------------------
    // 第2リンク
    // --------------------------------------------------

    glLineWidth(8.0f);

    // 緑色
    glColor3f(0.2f, 1.0f, 0.4f);

    glBegin(GL_LINES);

    // 肘
    glVertex2d(x1, y1);

    // 手先
    glVertex2d(x2, y2);

    glEnd();


    // --------------------------------------------------
    // 肘の関節
    // --------------------------------------------------

    glColor3f(0.1f, 0.1f, 0.1f);

    drawCircle(
        x1,
        y1,
        8.0
    );


    // --------------------------------------------------
    // 手先
    // --------------------------------------------------

    glColor3f(0.0f, 0.0f, 0.0f);

    drawCircle(
        x2,
        y2,
        6.0
    );


    // --------------------------------------------------
    // FKで求めた手先位置を赤い十字で表示
    // --------------------------------------------------

    glColor3f(1.0f, 0.0f, 0.0f);

    drawCross(
        x2,
        y2,
        10.0
    );


    // --------------------------------------------------
    // 角度と手先座標を文字で表示
    // --------------------------------------------------

    glColor3f(0.0f, 0.0f, 0.0f);

    char buf[256];

    std::snprintf(
        buf,
        sizeof(buf),
        "th1: %.1f deg\nth2: %.1f deg\nEnd: (%.1f, %.1f)",
        theta1 * 180.0 / M_PI,
        theta2 * 180.0 / M_PI,
        x2,
        y2
    );


    // 文字の開始位置
    float textX = -WIN_W / 2 + 8;
    float textY = WIN_H / 2 - 20;

    glRasterPos2f(textX, textY);


    // 1文字ずつ描画
    int line = 0;

    for (char* p = buf; *p; ++p) {

        // 改行の場合
        if (*p == '\n') {

            ++line;

            glRasterPos2f(
                textX,
                textY - 16 * line
            );

            continue;
        }

        glutBitmapCharacter(
            GLUT_BITMAP_HELVETICA_12,
            *p
        );
    }


    glPopMatrix();


    // ダブルバッファを交換
    glutSwapBuffers();
}


// --------------------------------------------------
// ウィンドウサイズ変更時
// --------------------------------------------------
void reshape(int w, int h) {

    glViewport(
        0,
        0,
        WIN_W,
        WIN_H
    );

    glMatrixMode(GL_PROJECTION);

    glLoadIdentity();

    glOrtho(
        0,
        WIN_W,
        0,
        WIN_H,
        -1,
        1
    );

    glMatrixMode(GL_MODELVIEW);

    glLoadIdentity();
}


// --------------------------------------------------
// キーボード操作
// --------------------------------------------------
void keyboard(unsigned char key, int x, int y) {

    switch (key) {

        // ESCキー
    case 0x1b:

        std::exit(0);

        break;


        // --------------------------------------------------
        // A / D
        //
        // 第1関節 theta1 を操作
        // --------------------------------------------------

    case 'a':
    case 'A':

        // 第1関節を反時計回りに回転
        theta1 += 0.1;

        glutPostRedisplay();

        break;


    case 'd':
    case 'D':

        // 第1関節を時計回りに回転
        theta1 -= 0.1;

        glutPostRedisplay();

        break;


        // --------------------------------------------------
        // W / S
        //
        // 第2関節 theta2 を操作
        // --------------------------------------------------

    case 'w':
    case 'W':

        // 第2関節を曲げる
        theta2 += 0.1;

        glutPostRedisplay();

        break;


    case 's':
    case 'S':

        // 第2関節を反対方向へ曲げる
        theta2 -= 0.1;

        glutPostRedisplay();

        break;


        // --------------------------------------------------
        // R
        //
        // 初期状態へ戻す
        // --------------------------------------------------

    case 'r':
    case 'R':

        theta1 = 0.3;
        theta2 = 0.3;

        glutPostRedisplay();

        break;
    }
}


// --------------------------------------------------
// main
// --------------------------------------------------
int main(int argc, char** argv) {

    // GLUT初期化
    glutInit(&argc, argv);


    // ダブルバッファ＋RGBA
    glutInitDisplayMode(
        GLUT_DOUBLE |
        GLUT_RGBA
    );


    // ウィンドウサイズ
    glutInitWindowSize(
        WIN_W,
        WIN_H
    );


    // ウィンドウ作成
    glutCreateWindow(
        "フォワード キネマティクス（A/D:肩　W/S:腕　R:リセット　ESC:終了）"
    );


    // 背景を白にする
    glClearColor(
        1.0f,
        1.0f,
        1.0f,
        1.0f
    );


    // 描画関数
    glutDisplayFunc(display);


    // ウィンドウサイズ変更時
    glutReshapeFunc(reshape);


    // キーボード
    glutKeyboardFunc(keyboard);


    // GLUTのイベントループ開始
    glutMainLoop();


    return 0;
}