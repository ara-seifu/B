﻿#include <GL/glut.h>
#include <cmath>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct WaveBullet {
    float x, y;
    float speed;
    float amplitude;
    float frequency;
    float startX;
    float time;
};

struct SpiralBullet {
    float cx, cy;
    float radius;
    float angle;
    float angularSpeed;
    float speed; // 中心から外へ移動
};

std::vector<WaveBullet> waveBullets;
std::vector<SpiralBullet> spiralBullets;

float playerX = 0.0f;
float playerY = -0.8f;
float enemyX = 0.0f;
float enemyY = 0.0f;

int lastTime = 0;

// --- 波弾弾幕 ---
void shootWavePattern(int count, float speed, float amplitude, float frequency, float spacing) {
    for (int i = 0; i < count; i++) {
        WaveBullet b;
        b.x = playerX + spacing * (i - count / 2);
        b.y = playerY;
        b.startX = b.x;
        b.speed = speed;
        b.amplitude = amplitude;
        b.frequency = frequency;
        b.time = 0.0f;
        waveBullets.push_back(b);
    }
}

// --- 回転スパイラル弾 ---
void shootSpiral(int n, float radius, float angularSpeed, float speed) {
    for (int i = 0; i < n; i++) {
        SpiralBullet b;
        b.cx = enemyX;
        b.cy = enemyY;
        b.radius = radius;
        b.angle = (2.0f * M_PI / n) * i;
        b.angularSpeed = angularSpeed;
        b.speed = speed;
        spiralBullets.push_back(b);
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー（青）
    glPointSize(10.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(playerX, playerY);
    glEnd();

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 波弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : waveBullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    // スパイラル弾（オレンジ）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.5f, 0.0f);
    for (auto& b : spiralBullets) {
        float x = b.cx + b.radius * cos(b.angle);
        float y = b.cy + b.radius * sin(b.angle);
        glVertex2f(x, y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    // 波弾更新
    for (auto& b : waveBullets) {
        b.time += dt;
        b.y += b.speed * dt;
        b.x = b.startX + b.amplitude * sin(b.frequency * b.time);
    }

    // スパイラル弾更新
    for (auto& b : spiralBullets) {
        b.angle += b.angularSpeed * dt;
        b.radius += b.speed * dt;
    }

    glutPostRedisplay();
}

void keyboard(unsigned char key, int, int) {
    if (key == ' ') {
        // 波弾5発
        shootWavePattern(5, 0.5f, 0.15f, 2 * M_PI, 0.1f);
        // スパイラル弾8発
        shootSpiral(8, 0.1f, 2.0f, 0.2f);
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("複雑弾幕デモ(Spaceで発射）");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
