﻿#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <utility>

using namespace std;

struct Point {
    int y, x;
};

// 4方向（上・下・左・右）
const int dy[4] = { -1, 1, 0, 0 };
const int dx[4] = { 0, 0, -1, 1 };

int main() {
    vector<string> maze = {
    "########################################",
    "#S.#..#...#.....#.......#...#...#...#.G#",
    "#..#..#...#......#....#.#.#.#.#.#.#.#..#",
    "#..#..#...#.########..#.#.#.#.#.#.#.#..#",
    "#..#..#...#......#....#.#.#.#.#.#.#.#..#",
    "#.........#####..#....#.#.#.#.#.#.#.#..#",
    "#########.#......#......#.#.#.#.#.###..#",
    "#......#..#.######......#.#.#.#.#...#..#",
    "#..#.#.#..#......#......#.#.#.#.#.#.#..#",
    "#..#.#.#..###.########.##.#.#.#.#.#.#..#",
    "#.........................#...#...#....#",
    "########################################"
    };

    size_t H = maze.size();
    size_t W = maze[0].size();

    Point start = { 0,0 }, goal = { 0,0 }; // 警告出るのが嫌なので一応初期化しておく

    for (auto& row : maze) cout << row << " (" << row.size() << ")\n";
    
    // スタートとゴールを探す
    for (int y = 0; y < H; ++y) {
        for (int x = 0; x < W; ++x) {
            if (maze[y][x] == 'S') start = { y, x };
            if (maze[y][x] == 'G') goal = { y, x };
        }
    }

    // 距離と前の位置を記録
    vector<vector<int>> dist(H, vector<int>(W, -1));
    vector<vector<Point>> prev(H, vector<Point>(W, { -1, -1 }));

    queue<Point> q;
    q.push(start);
    dist[start.y][start.x] = 0;

    // BFS開始
    while (!q.empty()) {
        Point cur = q.front(); q.pop();

        // ゴール到達
        if (cur.y == goal.y && cur.x == goal.x) break;

        for (int i = 0; i < 4; i++) {
            int ny = cur.y + dy[i];
            int nx = cur.x + dx[i];
            if (ny < 0 || ny >= H || nx < 0 || nx >= W) continue;
            if (maze[ny][nx] == '#') continue;
            if (dist[ny][nx] != -1) continue;

            dist[ny][nx] = dist[cur.y][cur.x] + 1;
            prev[ny][nx] = cur;
            q.push({ ny, nx });
        }
    }

    // 経路復元
    if (dist[goal.y][goal.x] == -1) {
        cout << "ゴールに到達できませんでした。\n";
        return 0;
    }

    Point cur = goal;
    while (!(cur.y == start.y && cur.x == start.x)) {
        if (maze[cur.y][cur.x] != 'G')
            maze[cur.y][cur.x] = '*';
        cur = prev[cur.y][cur.x];
    }

    // 出力
    cout << "最短距離: " << dist[goal.y][goal.x] << "\n";
    for (auto& row : maze) {
        cout << row << "\n";
    }

    return 0;
}