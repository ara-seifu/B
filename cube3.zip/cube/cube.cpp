﻿// 経過時間に基づいて回転 → PC性能に依存せず同じ速度で回転
// 1回転 = 約5秒

#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>

#define ESC 0x1b
#define PROJECTION true
#define MORECUBE true

static float rotX = 35.0f;  // X軸固定回転
static float rotY = 0.0f;   // Y軸は時間で回転

void drawAxes()
{
    float axisLength = 10.0f;

    glLineWidth(2.0f);
    glBegin(GL_LINES);

    // X軸 (赤)
    glColor3f(1.0, 0.0, 0.0);
    glVertex3f(0.0, 0.0, 0.0);
    glVertex3f(axisLength, 0.0, 0.0);

    // Y軸 (緑)
    glColor3f(0.0, 1.0, 0.0);
    glVertex3f(0.0, 0.0, 0.0);
    glVertex3f(0.0, axisLength, 0.0);

    // Z軸 (青)
    glColor3f(0.0, 0.0, 1.0);
    glVertex3f(0.0, 0.0, 0.0);
    glVertex3f(0.0, 0.0, axisLength);

    glEnd();
}

// グリッドの描画 (XZ平面)
void drawGrid(int size, int step)
{
    glColor3f(0.7, 0.7, 0.7); // 灰色
    glLineWidth(1.0f);
    glBegin(GL_LINES);

    for (int i = -size; i <= size; i += step) {
        // X方向の線 (Zを変化)
        glVertex3f((float)i, 0.0f, (float)-size);
        glVertex3f((float)i, 0.0f, (float)size);

        // Z方向の線 (Xを変化)
        glVertex3f((float)-size, 0.0f, (float)i);
        glVertex3f((float)size, 0.0f, (float)i);
    }

    glEnd();
}


//-------------------------------------------------
//      drawCube()  立方体を表示
//-------------------------------------------------
void drawCube()
{
    glBegin(GL_QUADS);

    // +X
    glColor3f(1, 0, 0);  glNormal3f(1, 0, 0);
    glVertex3f(0.5f, -0.5f, -0.5f) ;
    glVertex3f(0.5f,  0.5f, -0.5f) ;
    glVertex3f(0.5f,  0.5f,  0.5f) ;
    glVertex3f(0.5f, -0.5f,  0.5f) ;

    // -X
    glColor3f(0, 1, 0);  glNormal3f(-1, 0, 0);
    glVertex3f(-0.5f, -0.5f,  0.5f) ;
    glVertex3f(-0.5f,  0.5f,  0.5f) ;
    glVertex3f(-0.5f,  0.5f, -0.5f) ;
    glVertex3f(-0.5f, -0.5f, -0.5f) ;

    // +Y
    glColor3f(0, 0, 1);  glNormal3f(0, 1, 0);
    glVertex3f(-0.5f, 0.5f, -0.5f) ;
    glVertex3f(-0.5f, 0.5f,  0.5f) ;
    glVertex3f( 0.5f, 0.5f,  0.5f) ;
    glVertex3f( 0.5f, 0.5f, -0.5f) ;

    // -Y
    glColor3f(1, 1, 0);  glNormal3f(0, -1, 0);
    glVertex3f(-0.5f, -0.5f,  0.5f) ;
    glVertex3f(-0.5f, -0.5f, -0.5f) ;
    glVertex3f( 0.5f, -0.5f, -0.5f) ;
    glVertex3f( 0.5f, -0.5f,  0.5f) ;

    // +Z
    glColor3f(0, 1, 1);  glNormal3f(0, 0, 1);
    glVertex3f( 0.5f, -0.5f, 0.5f) ;
    glVertex3f( 0.5f,  0.5f, 0.5f) ;
    glVertex3f(-0.5f,  0.5f, 0.5f) ;
    glVertex3f(-0.5f, -0.5f, 0.5f) ;

    // -Z
    glColor3f(1, 0, 1);  glNormal3f(0, 0, -1);
    glVertex3f(-0.5f, -0.5f, -0.5f) ;
    glVertex3f(-0.5f,  0.5f, -0.5f) ;
    glVertex3f( 0.5f,  0.5f, -0.5f) ;
    glVertex3f( 0.5f, -0.5f, -0.5f) ;

    glEnd();
}


//-------------------------------------------------
//      display()  ウインドウサイズが変更された際のコールバック関数
//-------------------------------------------------
void display()
{
// 色バッファ（画面の色データ）と 深度バッファ（奥行きデータ）を消去し
// 前フレームの残像が残らないようにする。
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    glMatrixMode(GL_MODELVIEW) ;        // モデルビュー行列を使うモードに変更
 
    glLoadIdentity() ;  // 行列をリセット（単位行列）→ このあとでカメラ変換・物体変換を順に積み重ねていく
    glTranslatef(0.0f, 0.0f, -3.5f) ;   //カメラから見て Z軸方向に - 3.5 移動する。これで画面に収まる位置に配置される

    glRotatef(rotX, 1, 0, 0);   // X軸まわりにrotXだけ回転（ここでは固定値）
    glRotatef(rotY, 0, 1, 0);   // Y軸まわりにrotYだけ回転（5秒(5000ms)で1回転するよう rotYが変化していく）



    // 本体（塗りつぶし）
    glEnable(GL_POLYGON_OFFSET_FILL);

    // わずかに奥にずらして描画する → 後で描く輪郭線がチラチラせず、きれいに重なるようにする
    glPolygonOffset(1.0f, 1.0f);

    drawCube();

#if MORECUBE
    glPushMatrix();                             // カレントの変換行列を保存
    glRotatef(45.0, 1, 1, 1);   // X軸まわりY軸まわりに45.0だけ回転
    glTranslatef(2.0, 0.0, 0.0);                // 指定された座標に移動
    drawCube() ;
    glPopMatrix();                              // カレントの変換行列を復帰 
#endif

    glDisable(GL_POLYGON_OFFSET_FILL);




    // 輪郭線
    glLineWidth(1.5f) ; // 線の太さを1.5に
    glColor3f(0, 0, 0); // 色を黒に
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE) ; // 立体の輪郭を線だけで描画するモードに
    drawCube() ;

#if MORECUBE
    glPushMatrix();                             // カレントの変換行列を保存
    glRotatef(45.0, 1, 1, 1);   // X軸まわりY軸まわりに45.0だけ回転
    glTranslatef(2.0, 0.0, 0.0);                // 指定された座標に移動
    drawCube();
    glPopMatrix();                              // カレントの変換行列を復帰 
#endif

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL) ; // モードを元に戻す

    drawGrid(10, 1); // 10x10 のグリッド
    drawAxes();      // 座標軸

    glutSwapBuffers() ; // ダブルバッファリングを使って描画を入れ替え

}

//-------------------------------------------------
//      reshape()  ウインドウサイズが変更された際のコールバック関数
//-------------------------------------------------
void reshape(int w, int h) 
{
    if (h == 0) 
        h = 1 ;                     // ウィンドウの高さ h が 0 だと アスペクト比の計算でゼロ除算になってしまうので強制的に 1 に
    
    glViewport(0, 0, w, h);         // ウィンドウ内の描画に使う範囲を再設定

    glMatrixMode(GL_PROJECTION);   // 投影行列を指定
    glLoadIdentity();              // 現在の行列を 単位行列にリセット

#if PROJECTION                   // 透視投影

// 視野角を 90°に  アスペクト比 を ウィンドウ幅 / 高さに   描画範囲を手前 0.1 〜 奥 100.0　に
    gluPerspective(90.0, (double)w / (double)h, 0.1, 100.0) ;

#else                               // 平行投影

    double aspect = (double)w / (double)h;
    double size = 2.0; // 見える範囲のスケール

    if (aspect >= 1.0) {
        // 横長画面
        glOrtho(-size * aspect, size * aspect, -size, size, 0.1, 100.0);
    }
    else {
        // 縦長画面
        glOrtho(-size, size, -size / aspect, size / aspect, 0.1, 100.0);
    }

#endif
}



//-------------------------------------------------
//      idle()  特に処理するイベントがない時に呼び出されるコールバック関数
//-------------------------------------------------
void idle() 
{
    // 経過時間 (ms) を取得
    int t = glutGet(GLUT_ELAPSED_TIME)  ; // プログラム開始からの経過時間(ミリ秒) を取得

    // 5秒(5000ms)で1回転  → 角速度 は 360度/5000ms = 0.036度/ms
    rotY  = fmod( t * 0.036f, 360.0f)    ; // rotY = (時間 × 角速度) % 360 

    glutPostRedisplay() ;   // 再描画
}

//-------------------------------------------------
//      keyboard()  キーボードが押された際に呼び出されるコールバック関数
//-------------------------------------------------
void keyboard(unsigned char key, int, int)  
{
    if (key == ESC) // エスケープで終了
        exit(0);
}

//-------------------------------------------------
//      main()  
//-------------------------------------------------
int main(int argc, char* argv[])
{
// 各種初期化
    glutInit(&argc, argv) ;
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH) ;
    glutInitWindowSize(800, 600)    ;
    glutCreateWindow("立方体回転")   ;

    glEnable(GL_DEPTH_TEST) ;                   // 描画計算におけるｚバッファを有効にする
    glShadeModel(GL_FLAT)   ;                   // フラットシェーディング
    glClearColor(0.95f, 0.95f, 0.98f, 1.0f) ;   // 背景を白に

// 各イベントハンドラ登録
    glutDisplayFunc(display);                   
    glutReshapeFunc(reshape);
    glutIdleFunc(idle)      ;
    glutKeyboardFunc(keyboard);

// メインループ
    glutMainLoop()  ;

    return 0 ;
}
