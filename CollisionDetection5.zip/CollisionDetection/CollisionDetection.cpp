﻿#define _USE_MATH_DEFINES
#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <unordered_map>
#include <iostream>
#include <chrono>
#include <cstdlib>

struct Vec3 { float x, y, z; Vec3(float x = 0, float y = 0, float z = 0) :x(x), y(y), z(z) {} Vec3 operator+(const Vec3& o)const { return Vec3(x + o.x, y + o.y, z + o.z); } Vec3 operator-(const Vec3& o)const { return Vec3(x - o.x, y - o.y, z - o.z); } Vec3 operator*(float s)const { return Vec3(x * s, y * s, z * s); } };

struct Box { Vec3 pos; float size; bool collided; };
std::vector<Box> boxes;
const float BOX_SIZE = 1.0f;

// Brute Force / Spatial Hash 切り替え
bool useSpatialHash = true;

// ---------------- AABB判定 ----------------
bool intersectAABB(const Box& a, const Box& b) {
    float ha = a.size * 0.5f, hb = b.size * 0.5f;
    if (fabs(a.pos.x - b.pos.x) > ha + hb) return false;
    if (fabs(a.pos.y - b.pos.y) > ha + hb) return false;
    if (fabs(a.pos.z - b.pos.z) > ha + hb) return false;
    return true;
}

// ---------------- 空間ハッシュ ----------------
struct Cell { int x, z; bool operator==(const Cell& o)const { return x == o.x && z == o.z; } };
struct CellHash { std::size_t operator()(const Cell& c)const { return std::hash<int>()(c.x) ^ (std::hash<int>()(c.z) << 1); } };
std::unordered_map<Cell, std::vector<int>, CellHash> spatialHash;

Cell getCell(const Vec3& pos, float cellSize = BOX_SIZE) { return Cell{ int(floor(pos.x / cellSize)),int(floor(pos.z / cellSize)) }; }

void buildSpatialHash() {
    spatialHash.clear();
    for (size_t i = 0; i < boxes.size(); i++) {
        Box& b = boxes[i];
        int minX = int(floor((b.pos.x - b.size / 2) / BOX_SIZE));
        int maxX = int(floor((b.pos.x + b.size / 2) / BOX_SIZE));
        int minZ = int(floor((b.pos.z - b.size / 2) / BOX_SIZE));
        int maxZ = int(floor((b.pos.z + b.size / 2) / BOX_SIZE));
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                spatialHash[{x, z}].push_back(i);
            }
        }
    }
}

// ---------------- 衝突判定 ----------------
void checkCollisions() {
    auto start = std::chrono::high_resolution_clock::now();
    for (auto& b : boxes) b.collided = false;

    if (useSpatialHash) {
        for (auto& kv : spatialHash) {
            int cx = kv.first.x, cz = kv.first.z;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Cell neighbor{ cx + dx,cz + dz };
                    if (spatialHash.find(neighbor) == spatialHash.end()) continue;
                    auto& indices = spatialHash[neighbor];
                    for (size_t i = 0; i < indices.size(); i++) {
                        for (size_t j = i + 1; j < indices.size(); j++) {
                            int idxA = indices[i], idxB = indices[j];
                            if (intersectAABB(boxes[idxA], boxes[idxB])) {
                                boxes[idxA].collided = true;
                                boxes[idxB].collided = true;
                            }
                        }
                    }
                }
            }
        }
    }
    else {
        for (size_t i = 0; i < boxes.size(); i++) {
            for (size_t j = i + 1; j < boxes.size(); j++) {
                if (intersectAABB(boxes[i], boxes[j])) {
                    boxes[i].collided = true;
                    boxes[j].collided = true;
                }
            }
        }
    }

    auto end = std::chrono::high_resolution_clock::now();
    double ms = std::chrono::duration<double, std::milli>(end - start).count();
    std::cout << (useSpatialHash ? "SpatialHash" : "BruteForce") << " collision check: " << ms << " ms, Boxes: " << boxes.size() << std::endl;
}

// ---------------- グリッド ----------------
void drawGrid(float size, int divs) {
    glColor3f(0.7f, 0.7f, 0.7f);
    glBegin(GL_LINES);
    for (int i = -divs; i <= divs; i++) {
        glVertex3f(i * size, 0, -divs * size); glVertex3f(i * size, 0, divs * size);
        glVertex3f(-divs * size, 0, i * size); glVertex3f(divs * size, 0, i * size);
    }
    glEnd();
}

// ---------------- 描画 ----------------
void drawScene() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(50, 50, 50, 0, 0, 0, 0, 1, 0);
    drawGrid(1.0f, 50);

    for (auto& b : boxes) {
        glColor4f(b.collided ? 0 : 0, b.collided ? 1 : 0, b.collided ? 0 : 1, 0.5f);
        glPushMatrix();
        glTranslatef(b.pos.x, b.pos.y + BOX_SIZE / 2.0f, b.pos.z);
        glutSolidCube(BOX_SIZE);
        glColor3f(0, 0, 0); glutWireCube(BOX_SIZE);
        glPopMatrix();
    }
    glutSwapBuffers();
}

// ---------------- ランダム生成 ----------------
void generateBoxes(int count) {
    boxes.clear();
    for (int i = 0; i < count; i++) {
        Box b;
        b.pos = Vec3((float)(rand() % 100 - 50), 0, (float)(rand() % 100 - 50));
        b.size = BOX_SIZE;
        b.collided = false;
        boxes.push_back(b);
    }
    if (useSpatialHash) buildSpatialHash();
    checkCollisions();
    glutPostRedisplay();
}

// ---------------- キーボード ----------------
void keyboard(unsigned char key, int x, int y) {
    if (key == 's' || key == 'S') {
        useSpatialHash = !useSpatialHash;
        std::cout << "Switching to " << (useSpatialHash ? "Spatial Hash" : "Brute Force") << std::endl;
        if (useSpatialHash) buildSpatialHash();
        checkCollisions();
        glutPostRedisplay();
    }
    if (key == 'r' || key == 'R') {
        generateBoxes(500); // デフォルト500個生成
    }
}

// ---------------- 初期化 ----------------
void init() {
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION); glLoadIdentity();
    gluPerspective(60, (double)w / h, 0.1, 200);
    glMatrixMode(GL_MODELVIEW);
}

// ---------------- main ----------------
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Collision Speed Demo - Large Scale");

    init();
    glutDisplayFunc(drawScene);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    generateBoxes(100); // 最初は100個生成
    glutMainLoop();
    return 0;
}
