﻿#define _USE_MATH_DEFINES
#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <iostream>

// ---------------------------- ベクトル構造体 ----------------------------
struct Vec3 {
    float x, y, z;
    Vec3(float x = 0, float y = 0, float z = 0) :x(x), y(y), z(z) {}
    Vec3 operator+(const Vec3& o) const { return Vec3(x + o.x, y + o.y, z + o.z); }
    Vec3 operator-(const Vec3& o) const { return Vec3(x - o.x, y - o.y, z - o.z); }
    Vec3 operator*(float s) const { return Vec3(x * s, y * s, z * s); }
};

// ---------------------------- 箱 ----------------------------
struct Box {
    Vec3 pos;     // 中心位置
    float size;   // 一辺の長さ
    bool collided; // 衝突フラグ
};

std::vector<Box> boxes;

// ---------------------------- AABB衝突判定 ----------------------------
bool intersectAABB(const Box& a, const Box& b) {
    float halfA = a.size * 0.5f;
    float halfB = b.size * 0.5f;

    if (fabs(a.pos.x - b.pos.x) > halfA + halfB) return false;
    if (fabs(a.pos.y - b.pos.y) > halfA + halfB) return false;
    if (fabs(a.pos.z - b.pos.z) > halfA + halfB) return false;

    return true;
}

// ---------------------------- 衝突チェック ----------------------------
void checkCollisions() {
    // フラグリセット
    for (auto& b : boxes) {
        b.collided = false;
    }

    // ペアごとに判定
    for (size_t i = 0; i < boxes.size(); i++) {
        for (size_t j = i + 1; j < boxes.size(); j++) {
            if (intersectAABB(boxes[i], boxes[j])) {
                boxes[i].collided = true;
                boxes[j].collided = true;
            }
        }
    }
}

// ---------------------------- マウスクリック座標をワールドに変換 ----------------------------
Vec3 getClickPositionOnGround(int mx, int my) {
    GLint viewport[4];
    GLdouble modelview[16], projection[16];
    glGetIntegerv(GL_VIEWPORT, viewport);
    glGetDoublev(GL_MODELVIEW_MATRIX, modelview);
    glGetDoublev(GL_PROJECTION_MATRIX, projection);

    double winX = (double)mx;
    double winY = (double)viewport[3] - (double)my; // Y反転

    GLdouble startX, startY, startZ;
    GLdouble endX, endY, endZ;

    // クリック位置からレイを作る
    gluUnProject(winX, winY, 0.0, modelview, projection, viewport,
        &startX, &startY, &startZ);
    gluUnProject(winX, winY, 1.0, modelview, projection, viewport,
        &endX, &endY, &endZ);

    Vec3 rayStart(startX, startY, startZ);
    Vec3 rayEnd(endX, endY, endZ);
    Vec3 rayDir = rayEnd - rayStart;

    // y=0 の平面との交点
    float t = -rayStart.y / rayDir.y;
    Vec3 hit = rayStart + rayDir * t;
    return hit;
}

// ---------------------------- マウス処理 ----------------------------
void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        Vec3 hit = getClickPositionOnGround(x, y);

        Box b;
        b.pos = hit;
        b.size = 2.0f;
        b.collided = false;

        boxes.push_back(b);

        checkCollisions();
        glutPostRedisplay();
    }
}

// 床のグリッドを描画
void drawGrid(float size, int divisions) {
    glColor3f(0.7f, 0.7f, 0.7f); // 薄いグレー
    glBegin(GL_LINES);
    for (int i = -divisions; i <= divisions; i++) {
        // Z方向の線
        glVertex3f(i * size, 0, -divisions * size);
        glVertex3f(i * size, 0, divisions * size);
        // X方向の線
        glVertex3f(-divisions * size, 0, i * size);
        glVertex3f(divisions * size, 0, i * size);
    }
    glEnd();
}
// ---------------------------- 描画 ----------------------------
void drawScene() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();
    gluLookAt(10, 10, 20, 0, 0, 0, 0, 1, 0);

    // === 床のグリッド ===
    drawGrid(1.0f, 20); // 1マス1.0、-20～20の範囲

    // === 箱を描画 ===
    for (auto& b : boxes) {
        if (b.collided) glColor4f(0, 1, 0, 0.5f); // 緑半透明
        else glColor4f(0, 0, 1, 0.5f);           // 青半透明

        glPushMatrix();
        glTranslatef(b.pos.x, b.pos.y + b.size / 2.0f, b.pos.z);
        glutSolidCube(b.size);

        // ワイヤーフレームを黒で描画
        glColor3f(0, 0, 0);
        glutWireCube(b.size);

        glPopMatrix();
    }

    glutSwapBuffers();
}

// ---------------------------- 初期化 ----------------------------
void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
}

// ---------------------------- リサイズ ----------------------------
void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45, (double)w / h, 0.1, 100);
    glMatrixMode(GL_MODELVIEW);
}

// ---------------------------- main ----------------------------
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Raycast + AABB + Spatial Hash Sample");

    init();

    glutDisplayFunc(drawScene);
    glutReshapeFunc(reshape);
    glutMouseFunc(mouse);

    glutMainLoop();
    return 0;
}
