﻿
#include <iostream>
#include <winsock2.h>

#pragma comment(lib,"ws2_32.lib")
#define CHAT_PORT			1024
//#define SERVER_ADR          "192.168.20.131"            // リモートホストのアドレス（２００教室）
//#define SERVER_ADR          "192.168.21.100"            // リモートホストのアドレス（２０１教室）
#define SERVER_ADR          "127.0.0.1"                 // リモートホストのアドレス(ローカル）
#define BUFSIZE             512


WSADATA			g_wsadata               ;			    // winsock dll

int main(void) {
    SOCKET sock                         ;

    unsigned short port = CHAT_PORT     ;
    char msg[] = "How are you?"         ;
    char buf[BUFSIZE]                   ;

    int  receivedSize                   ;
    int  sendSize                       ;

     struct sockaddr_in server_addr  = { 0 }                ;

    server_addr.sin_family          = AF_INET               ;
    server_addr.sin_addr.s_addr     = inet_addr(SERVER_ADR) ;
    server_addr.sin_port            = htons(port)           ;

    int len = sizeof(struct sockaddr_in)                    ;

    // 1. Winsockを開始(WSAStartup())
    if (WSAStartup(MAKEWORD(2, 2), &g_wsadata) == SOCKET_ERROR) {
        WSACleanup()    ;
        return -1       ;
    }
    printf("startup.\n");

    // 2.ソケット生成(socket())
    sock = socket(AF_INET, SOCK_DGRAM, 0)   ;
    if (sock == INVALID_SOCKET) {
        WSACleanup()    ;
        return -2       ;
    }
    printf("socket created.\n");


 

    // 3.送信（sendto())
    sendSize = sendto(sock, msg, sizeof(msg), 0, (sockaddr*)&server_addr, sizeof(sockaddr)) ;
    if (sendSize != sizeof(msg)) {
        printf("sendto() failed\n")   ;
        WSACleanup()    ;
        return -3;
    }
    printf("\nsended: %s\n", msg);
    printf("remote host address = %s\n", inet_ntoa(server_addr.sin_addr))   ;
    printf("remote port         = %d\n", ntohs(server_addr.sin_port))       ;

    // 4.受信（recvfrom())
    receivedSize = recvfrom(sock, buf, sizeof(buf), 0, (sockaddr*)&server_addr, &len)   ;
    if (receivedSize < 0) {
        printf("recvfrom() failed\n");
        WSACleanup();
        return -4;
    }
    printf("\nreceived: %s\n", buf) ;
    printf("remote host address = %s\n", inet_ntoa(server_addr.sin_addr))   ;
    printf("remote  port        = %d\n", ntohs(server_addr.sin_port))       ;


    // 5.ソケットクローズ(closesocket())
    closesocket(sock)   ;

    // 6.Winsockを終了
    WSACleanup()        ;

    return 0    ;
}