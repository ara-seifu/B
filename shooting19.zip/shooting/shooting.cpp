﻿#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <ctime>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct WaveBullet {
    float x, y;
    float speed;
    float amplitude;
    float frequency;
    float startX;
    float time;
};

struct SpiralBullet {
    float cx, cy;
    float radius;
    float angle;
    float angularSpeed;
    float speed;
};

struct FocusedBullet {
    float x, y;
    float vx, vy;
};

std::vector<WaveBullet> waveBullets;
std::vector<SpiralBullet> spiralBullets;
std::vector<FocusedBullet> focusedBullets;

float playerX = 0.0f;
float playerY = -0.8f;
float enemyX = 0.0f;
float enemyY = 0.0f;

int lastTime = 0;
float shootTimer = 0.0f;

// --- 弾発射関数 ---
void shootWavePattern(int count) {
    for (int i = 0; i < count; i++) {
        WaveBullet b;
        b.x = playerX + (float)(rand() % 100 - 50) / 500.0f; // 少し横ずれ
        b.y = playerY;
        b.startX = b.x;
        b.speed = 0.5f + (float)(rand() % 50) / 500.0f;
        b.amplitude = 0.1f + (float)(rand() % 50) / 500.0f;
        b.frequency = 2 * M_PI + (float)(rand() % 100) / 500.0f;
        b.time = 0.0f;
        waveBullets.push_back(b);
    }
}

void shootSpiral(int n) {
    for (int i = 0; i < n; i++) {
        SpiralBullet b;
        b.cx = enemyX;
        b.cy = enemyY;
        b.radius = 0.1f + (float)(rand() % 50) / 500.0f;
        b.angle = (2.0f * M_PI / n) * i;
        b.angularSpeed = 1.5f + (float)(rand() % 50) / 500.0f;
        b.speed = 0.2f + (float)(rand() % 50) / 500.0f;
        spiralBullets.push_back(b);
    }
}

void shootFocused(int n) {
    for (int i = 0; i < n; i++) {
        float angle = M_PI / 2 + ((float)(rand() % 50) - 25) / 100.0f; // 上方向 ±0.25rad
        FocusedBullet b;
        b.x = enemyX;
        b.y = enemyY;
        b.vx = cos(angle) * 0.5f;
        b.vy = sin(angle) * 0.5f;
        focusedBullets.push_back(b);
    }
}

// --- 描画 ---
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー（青）
    glPointSize(10.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(playerX, playerY);
    glEnd();

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 波弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : waveBullets) glVertex2f(b.x, b.y);
    glEnd();

    // スパイラル弾（オレンジ）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.5f, 0.0f);
    for (auto& b : spiralBullets) {
        float x = b.cx + b.radius * cos(b.angle);
        float y = b.cy + b.radius * sin(b.angle);
        glVertex2f(x, y);
    }
    glEnd();

    // 集中弾（黄）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 1.0f, 0.0f);
    for (auto& b : focusedBullets) glVertex2f(b.x, b.y);
    glEnd();

    glutSwapBuffers();
}

// --- 更新 ---
void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    shootTimer += dt;
    if (shootTimer > 0.5f) { // 0.5秒ごとに自動発射
        shootWavePattern(3);
        shootSpiral(6);
        shootFocused(3);
        shootTimer = 0.0f;
    }

    // 波弾更新
    for (auto& b : waveBullets) {
        b.time += dt;
        b.y += b.speed * dt;
        b.x = b.startX + b.amplitude * sin(b.frequency * b.time);
    }

    // スパイラル弾更新
    for (auto& b : spiralBullets) {
        b.angle += b.angularSpeed * dt;
        b.radius += b.speed * dt;
    }

    // 集中弾更新
    for (auto& b : focusedBullets) {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
    }

    glutPostRedisplay();
}

// --- メイン ---
int main(int argc, char** argv) {
    srand((unsigned)time(NULL));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("無限弾幕デモ");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    glutMainLoop();
    return 0;
}
