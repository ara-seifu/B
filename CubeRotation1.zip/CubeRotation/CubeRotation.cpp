#include <GL/glut.h>  
#include <cmath>

// ��]�p�x
float angleX = 0.0f;
float angleY = 0.0f;
float angleZ = 0.0f;

void drawCube() {
    glBegin(GL_QUADS);
    glColor3f(1, 0, 0); glVertex3f(-1, -1, 1); glVertex3f(1, -1, 1); glVertex3f(1, 1, 1); glVertex3f(-1, 1, 1);
    glColor3f(0, 1, 0); glVertex3f(-1, -1, -1); glVertex3f(-1, 1, -1); glVertex3f(1, 1, -1); glVertex3f(1, -1, -1);
    glColor3f(0, 0, 1); glVertex3f(-1, -1, -1); glVertex3f(-1, -1, 1); glVertex3f(-1, 1, 1); glVertex3f(-1, 1, -1);
    glColor3f(1, 1, 0); glVertex3f(1, -1, -1); glVertex3f(1, 1, -1); glVertex3f(1, 1, 1); glVertex3f(1, -1, 1);
    glColor3f(1, 0, 1); glVertex3f(-1, 1, -1); glVertex3f(-1, 1, 1); glVertex3f(1, 1, 1); glVertex3f(1, 1, -1);
    glColor3f(0, 1, 1); glVertex3f(-1, -1, -1); glVertex3f(1, -1, -1); glVertex3f(1, -1, 1); glVertex3f(-1, -1, 1);
    glEnd();
}

// XYZ����`��i��:X, ��:Y, ��:Z�j
void drawAxes() {
    glBegin(GL_LINES);
    // X��
    glColor3f(1.0, 0.0, 0.0);
    glVertex3f(0, 0, 0); glVertex3f(5, 0, 0);
    // Y��
    glColor3f(0.0, 1.0, 0.0);
    glVertex3f(0, 0, 0); glVertex3f(0, 5, 0);
    // Z��
    glColor3f(0.0, 0.0, 1.0);
    glVertex3f(0, 0, 0); glVertex3f(0, 0, 5);
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(3, 3, 5, 0, 0, 0, 0, 1, 0);

    // ����`��
    drawAxes();

    // ��]��K�p
    glRotatef(angleX, 1.0f, 0.0f, 0.0f);
    glRotatef(angleY, 0.0f, 1.0f, 0.0f);
    glRotatef(angleZ, 0.0f, 0.0f, 1.0f);

    drawCube();
    glutSwapBuffers();
}

void keyboard(unsigned char key, int, int) {
    float delta = 5.0f; // ��]��
    switch (key) {
    case 'a': angleY += delta; break; // Y����
    case 'd': angleY -= delta; break; // Y���E
    case 'w': angleX += delta; break; // X����
    case 's': angleX -= delta; break; // X����
    case 'q': angleZ += delta; break; // Z����
    case 'e': angleZ -= delta; break; // Z���E
    case 0x1b: exit(0);
    }
    glutPostRedisplay();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (double)w / h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

void init() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(1, 1, 1, 1);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("�����̉�]�i�N�H�[�^�j�I�����g�p�j   �����F�x�� �^ �����F�w�� �^ �����F�y��");
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutReshapeFunc(reshape);
    glutMainLoop();
    return 0;
}
