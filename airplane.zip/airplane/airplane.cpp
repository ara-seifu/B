#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <cstdio>

// ==========================
// ��ԕϐ�
// ==========================
float rollAngle = 0.0f;   // ���[���i���E�X���j
float pitchAngle = 0.0f;  // �s�b�`�i�@��㉺�j
float yawAngle = 0.0f;    // ���[�i�@�񍶉E�j
const float DELTA = 2.5f;

// ���̃T�C�Y
const float BODY_RADIUS = 0.15f;
const float BODY_LENGTH = 2.0f;

// ==========================
// ���`��
// ==========================
void drawAxes(float len = 1.5f) {
    glLineWidth(2.0f);
    glBegin(GL_LINES);
    glColor3f(1, 0, 0); glVertex3f(0, 0, 0); glVertex3f(len, 0, 0); // X
    glColor3f(0, 1, 0); glVertex3f(0, 0, 0); glVertex3f(0, len, 0); // Y
    glColor3f(0, 0, 1); glVertex3f(0, 0, 0); glVertex3f(0, 0, len); // Z
    glEnd();
}

// ==========================
// ��s�@�`��i���̏d�S�����_�Ɂj
// ==========================
void drawAircraft() {
    GLUquadric* quad = gluNewQuadric();

    // --- ���́i���_�𓷑̒����Ɂj ---
    glColor3f(0.9f, 0.9f, 0.95f);
    glPushMatrix();
    glTranslatef(0, 0, -BODY_LENGTH / 2); // ���̂̒��������_��
    gluCylinder(quad, BODY_RADIUS, BODY_RADIUS * 0.33f, BODY_LENGTH, 20, 1);
    glPopMatrix();

    // --- �@�� ---
    glPushMatrix();
    glTranslatef(0, 0, BODY_LENGTH / 2); // ���̒�������@��
    glutSolidCone(BODY_RADIUS, 0.3, 20, 10);
    glPopMatrix();

    // --- ���̌�[�L���b�v ---
    glPushMatrix();
    glTranslatef(0, 0, -BODY_LENGTH / 2); // ���̒��������[
    glRotatef(180, 1, 0, 0);
    glutSolidCone(BODY_RADIUS * 0.33f, 0.1, 16, 8);
    glPopMatrix();

    // --- �嗃 ---
    glColor3f(0.8f, 0.8f, 0.85f);
    float wingZ = 0.0f; // ���̒���
    float wingSpan = 0.8f;
    float wingChord = 0.6f;
    glBegin(GL_QUADS);
    // �E��
    glVertex3f(BODY_RADIUS, 0, wingZ);
    glVertex3f(BODY_RADIUS, 0, wingZ + wingChord);
    glVertex3f(BODY_RADIUS + wingSpan, 0, wingZ + wingChord);
    glVertex3f(BODY_RADIUS + wingSpan, 0, wingZ);
    // ����
    glVertex3f(-BODY_RADIUS, 0, wingZ);
    glVertex3f(-BODY_RADIUS, 0, wingZ + wingChord);
    glVertex3f(-BODY_RADIUS - wingSpan, 0, wingZ + wingChord);
    glVertex3f(-BODY_RADIUS - wingSpan, 0, wingZ);
    glEnd();

    // --- �������� ---
    glColor3f(0.75f, 0.75f, 0.8f);
    float hTailZ = -BODY_LENGTH / 2 + 0.2f;
    float hTailLength = 0.4f;
    float hTailSpan = 0.4f;
    glBegin(GL_QUADS);
    // �E
    glVertex3f(BODY_RADIUS, 0, hTailZ);
    glVertex3f(BODY_RADIUS, 0, hTailZ + hTailLength);
    glVertex3f(BODY_RADIUS + hTailSpan, 0, hTailZ + hTailLength);
    glVertex3f(BODY_RADIUS + hTailSpan, 0, hTailZ);
    // ��
    glVertex3f(-BODY_RADIUS, 0, hTailZ);
    glVertex3f(-BODY_RADIUS, 0, hTailZ + hTailLength);
    glVertex3f(-BODY_RADIUS - hTailSpan, 0, hTailZ + hTailLength);
    glVertex3f(-BODY_RADIUS - hTailSpan, 0, hTailZ);
    glEnd();

    // --- �������� ---
    glColor3f(0.7f, 0.7f, 0.75f);
    float vTailHeight = 0.35f;
    float vTailLength = 0.3f;
    float vTailZ = hTailZ + hTailLength; // ����������[
    glBegin(GL_QUADS);
    glVertex3f(0, 0, vTailZ);
    glVertex3f(0, 0, vTailZ + vTailLength);
    glVertex3f(0, vTailHeight, vTailZ + vTailLength);
    glVertex3f(0, vTailHeight, vTailZ);
    glEnd();

    gluDeleteQuadric(quad);
}


// ==========================
// HUD�e�L�X�g
// ==========================
void drawText(float x, float y, const char* str) {
    glRasterPos2f(x, y);
    for (const char* p = str; *p; p++) glutBitmapCharacter(GLUT_BITMAP_9_BY_15, *p);
}

// ==========================
// �`��
// ==========================
void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(4, 2, 4, 0, 0, 0, 0, 1, 0);

    drawAxes(1.5f);

    glPushMatrix();
    // --- ���_���S�ŉ�] ---
    glRotatef(yawAngle, 0, 1, 0);
    glRotatef(pitchAngle, 1, 0, 0);
    glRotatef(rollAngle, 0, 0, 1);
    drawAircraft();
    glPopMatrix();

    // HUD
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 800, 0, 600);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glDisable(GL_LIGHTING);
    glColor3f(1, 1, 1); // ��
    char buf[128];
    sprintf_s(buf, sizeof(buf), "Roll: %.1f��, Pitch: %.1f��, Yaw: %.1f��",
        rollAngle, pitchAngle, yawAngle);
    drawText(10, 560, buf);
    glEnable(GL_LIGHTING);
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    glutSwapBuffers();
}

// ==========================
// ���T�C�Y
// ==========================
void reshape(int w, int h) {
    if (h == 0) h = 1;
    float asp = (float)w / h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, asp, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

// ==========================
// ����
// ==========================
void keyboard(unsigned char key, int, int) {
    switch (key) {
    case 27: exit(0);
    case 'a': case 'A': rollAngle -= DELTA; break;
    case 'd': case 'D': rollAngle += DELTA; break;
    case 'r': case 'R': rollAngle = pitchAngle = yawAngle = 0.0f; break;
    }
    glutPostRedisplay();
}

void special(int key, int, int) {
    switch (key) {
    case GLUT_KEY_LEFT:  yawAngle += DELTA; break;
    case GLUT_KEY_RIGHT: yawAngle -= DELTA; break;
    case GLUT_KEY_UP:    pitchAngle -= DELTA; break;
    case GLUT_KEY_DOWN:  pitchAngle += DELTA; break;
    }
    glutPostRedisplay();
}

// ==========================
// ������
// ==========================
void initGL() {
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.12f, 0.15f, 0.20f, 1.0f);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    GLfloat pos[] = { 5,5,5,1 };
    glLightfv(GL_LIGHT0, GL_POSITION, pos);
    glEnable(GL_COLOR_MATERIAL);
}

// ==========================
// main
// ==========================
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("��s�@�V�~�����[�V���� ����=�s�b�`�^ A/D=���[���^ ����=���[�^ R=���Z�b�g�^ Esc=�I��");

    initGL();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);

    glutMainLoop();
    return 0;
}
