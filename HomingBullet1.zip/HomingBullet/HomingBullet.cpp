﻿#include <GL/glut.h>
#include <cmath>
#include <vector>

struct HomingBullet {
    float x, y;
    float speed;
};

std::vector<HomingBullet> bullets;

float playerX = 0.0f;
float playerY = -0.8f;
float enemyX = 0.0f;
float enemyY = 0.8f;

int lastTime = 0;

// --- キー状態管理 ---
bool keyState[256] = { false };        // ASCIIキー
bool specialKeyState[256] = { false }; // 矢印キー(GLUTでは0-255で十分)

void shootHoming(float speed) {
    HomingBullet b;
    b.x = enemyX;
    b.y = enemyY;
    b.speed = speed;
    bullets.push_back(b);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー（青）
    glPointSize(10.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(playerX, playerY);
    glEnd();

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 自機追尾弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    float moveSpeed = 1.0f * dt; // 秒単位の移動量

    // 矢印キー移動
    if (specialKeyState[GLUT_KEY_LEFT])  playerX -= moveSpeed;
    if (specialKeyState[GLUT_KEY_RIGHT]) playerX += moveSpeed;
    if (specialKeyState[GLUT_KEY_UP])    playerY += moveSpeed;
    if (specialKeyState[GLUT_KEY_DOWN])  playerY -= moveSpeed;

    // スペースキー発射
    if (keyState[' ']) shootHoming(0.5f);

    // 弾の追尾更新
    for (auto& b : bullets) {
        float dx = playerX - b.x;
        float dy = playerY - b.y;
        float dist = sqrt(dx * dx + dy * dy);
        if (dist > 0.001f) {
            b.x += b.speed * dt * dx / dist;
            b.y += b.speed * dt * dy / dist;
        }
    }

    glutPostRedisplay();
}

// --- キー押下・離上 ---
void keyDown(unsigned char key, int, int) { keyState[key] = true; }
void keyUp(unsigned char key, int, int) { keyState[key] = false; }
void specialDown(int key, int, int) { specialKeyState[key] = true; }
void specialUp(int key, int, int) { specialKeyState[key] = false; }

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("自機追尾弾（Space:発射／矢印キー:移動）");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);

    glutKeyboardFunc(keyDown);
    glutKeyboardUpFunc(keyUp);
    glutSpecialFunc(specialDown);
    glutSpecialUpFunc(specialUp);

    glutMainLoop();
    return 0;
}
