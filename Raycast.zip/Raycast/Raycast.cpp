﻿#define M_PI 3.141592653589793238f  // 円周率（ラジアン計算に使用）

#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <limits>
#include <iostream>

// ===============================
// 2次元ベクトル構造体（基本的な演算のみを持つ）
// ===============================
struct Vec2 {
    double x, y;
    Vec2(double x = 0, double y = 0) : x(x), y(y) {}
    Vec2 operator+(const Vec2& o) const { return Vec2(x + o.x, y + o.y); } // ベクトル加算
    Vec2 operator-(const Vec2& o) const { return Vec2(x - o.x, y - o.y); } // ベクトル減算
    Vec2 operator*(double s) const { return Vec2(x * s, y * s); }         // スカラー倍
};

// ===============================
// 線分（壁）を表す構造体
// ===============================
struct Segment {
    Vec2 a, b; // 始点 a と終点 b
    Segment(Vec2 a = Vec2(), Vec2 b = Vec2()) : a(a), b(b) {}
};

// ウィンドウ幅・高さ（初期値）
int WIN_W = 900, WIN_H = 700;

// シーンの壁（線分の集合）
std::vector<Segment> walls;

// プレイヤー（光線の発射点）
Vec2 playerPos(200, 200);      // プレイヤー位置（ピクセル）
double playerAngle = 0.0;      // 視線の角度（ラジアン、0 = 右方向）

double moveSpeed = 200.0;      // 移動速度（px/sec）※移動処理で使用

// レイの設定
int NUM_RAYS = 360;            // 発射するレイの本数（多いほど密になる）
double FOV = M_PI * 2.0;      // 視野角（ここでは全周＝360度）
double MAX_DIST = 2000.0;     // レイの最大到達距離

// キー状態管理（押下状態を保持）
bool keyState[256] = { 0 };
bool specialKeyState[256] = { 0 }; // 矢印キーなどGLUTの特別キー

// マウス状態（ドラッグで回転）
bool mouseDown = false;
int lastMouseX = 0;

// 時間管理（フレームごとの経過時間計測）
int lastTime = 0;

// ===============================
// レイ（半直線）と線分の交差判定
// ===============================
bool raySegmentIntersect(const Vec2& origin, const Vec2& dir, const Segment& seg, double& outDist, Vec2& outPoint) {
    double r_x = seg.b.x - seg.a.x;
    double r_y = seg.b.y - seg.a.y;
    double s_x = dir.x;
    double s_y = dir.y;

    double denom = (s_x * (-r_y) - s_y * (-r_x));
    if (fabs(denom) < 1e-9) return false;

    double dx = seg.a.x - origin.x;
    double dy = seg.a.y - origin.y;

    double t = (dx * (-r_y) - dy * (-r_x)) / denom;
    double u = (s_x * dy - s_y * dx) / denom;

    if (t >= 0.0 && u >= 0.0 && u <= 1.0) {
        outDist = t;
        outPoint = Vec2(origin.x + t * s_x, origin.y + t * s_y);
        return true;
    }
    return false;
}

Vec2 angleToDir(double ang) {
    return Vec2(cos(ang), sin(ang));
}

void initScene() {
    walls.clear();
    walls.emplace_back(Vec2(50, 50), Vec2(WIN_W - 50, 50));
    walls.emplace_back(Vec2(WIN_W - 50, 50), Vec2(WIN_W - 50, WIN_H - 50));
    walls.emplace_back(Vec2(WIN_W - 50, WIN_H - 50), Vec2(50, WIN_H - 50));
    walls.emplace_back(Vec2(50, WIN_H - 50), Vec2(50, 50));

    walls.emplace_back(Vec2(150, 100), Vec2(300, 180));
    walls.emplace_back(Vec2(350, 250), Vec2(650, 220));
    walls.emplace_back(Vec2(400, 120), Vec2(420, 380));
    walls.emplace_back(Vec2(600, 400), Vec2(720, 550));
    walls.emplace_back(Vec2(200, 500), Vec2(320, 420));
    walls.emplace_back(Vec2(480, 320), Vec2(560, 260));
}

// ===============================
// 描画処理
// ===============================
void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glEnable(GL_POINT_SMOOTH);

    glLineWidth(3.0f);
    glColor3f(0.9f, 0.9f, 0.9f);
    glBegin(GL_LINES);
    for (auto& s : walls) {
        glVertex2d(s.a.x, s.a.y);
        glVertex2d(s.b.x, s.b.y);
    }
    glEnd();

    double halfFOV = FOV * 0.5;
    for (int i = 0; i < NUM_RAYS; ++i) {
        double t = (NUM_RAYS == 1) ? 0.0 : ((double)i / (NUM_RAYS - 1));
        double angle = playerAngle - halfFOV + t * FOV;

        Vec2 dir = angleToDir(angle);
        double closestDist = std::numeric_limits<double>::infinity();
        Vec2 closestPoint;

        for (auto& s : walls) {
            double d;
            Vec2 p;
            if (raySegmentIntersect(playerPos, dir, s, d, p)) {
                if (d < closestDist) {
                    closestDist = d;
                    closestPoint = p;
                }
            }
        }

        if (closestDist < std::numeric_limits<double>::infinity()) {
            glColor3f(1.0f, 0.8f, 0.2f);
            glBegin(GL_LINES);
            glVertex2d(playerPos.x, playerPos.y);
            glVertex2d(closestPoint.x, closestPoint.y);
            glEnd();

            glPointSize(3.0f);
            glBegin(GL_POINTS);
            glVertex2d(closestPoint.x, closestPoint.y);
            glEnd();
        }
        else {
            Vec2 end = playerPos + dir * MAX_DIST;
            glColor3f(0.5f, 0.5f, 0.5f);
            glBegin(GL_LINES);
            glVertex2d(playerPos.x, playerPos.y);
            glVertex2d(end.x, end.y);
            glEnd();
        }
    }

    glColor3f(0.2f, 0.9f, 0.6f);
    const int CIRCLE_STEPS = 20;
    double r = 6.0;
    glBegin(GL_POLYGON);
    for (int k = 0; k < CIRCLE_STEPS; ++k) {
        double a = (2.0 * M_PI * k) / CIRCLE_STEPS;
        glVertex2d(playerPos.x + cos(a) * r, playerPos.y + sin(a) * r);
    }
    glEnd();

    Vec2 arrow = playerPos + angleToDir(playerAngle) * 18.0;
    glLineWidth(2.0f);
    glColor3f(0.1f, 0.6f, 0.9f);
    glBegin(GL_LINES);
    glVertex2d(playerPos.x, playerPos.y);
    glVertex2d(arrow.x, arrow.y);
    glEnd();

    glutSwapBuffers();
}

void reshape(int w, int h) {
    WIN_W = w; WIN_H = h;
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, w, h, 0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void keyboardDown(unsigned char k, int x, int y) { keyState[k] = true; if (k == 27) exit(0); }
void keyboardUp(unsigned char k, int x, int y) { keyState[k] = false; }
void specialDown(int key, int x, int y) { specialKeyState[key] = true; }
void specialUp(int key, int x, int y) { specialKeyState[key] = false; }

// ===============================
// マウス移動（ドラッグで視点回転）
// 注意: 現状は右方向にドラッグすると角度が増加、
//       左方向は減少なので、動きが逆に感じる場合は符号を反転させる
// ===============================
void passiveMotion(int x, int y) {
    if (mouseDown) {
        int dx = x - lastMouseX;
        playerAngle -= dx * 0.01; // 符号を反転して直感的に回転するように変更可能
        lastMouseX = x;
    }
}

void mouseButton(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) { mouseDown = true; lastMouseX = x; }
        else mouseDown = false;
    }
    else if (button == 3) { NUM_RAYS += 10; if (NUM_RAYS > 1440) NUM_RAYS = 1440; }
    else if (button == 4) { NUM_RAYS -= 10; if (NUM_RAYS < 8) NUM_RAYS = 8; }
}

void idleFunc() {
    int t = glutGet(GLUT_ELAPSED_TIME);
    double dt = (lastTime == 0) ? 0.0 : (double)(t - lastTime) / 1000.0;
    lastTime = t;

    Vec2 up(0, -1), right(1, 0);
    Vec2 delta(0, 0);
    if (keyState['w'] || keyState['W'] || specialKeyState[GLUT_KEY_UP]) delta = delta + up * moveSpeed * dt;
    if (keyState['s'] || keyState['S'] || specialKeyState[GLUT_KEY_DOWN]) delta = delta - up * moveSpeed * dt;
    if (keyState['a'] || keyState['A'] || specialKeyState[GLUT_KEY_LEFT]) delta = delta - right * moveSpeed * dt;
    if (keyState['d'] || keyState['D'] || specialKeyState[GLUT_KEY_RIGHT]) delta = delta + right * moveSpeed * dt;

    playerPos = playerPos + delta;

    if (playerPos.x < 50) playerPos.x = 50;
    if (playerPos.x > WIN_W - 50) playerPos.x = WIN_W - 50;
    if (playerPos.y < 50) playerPos.y = 50;
    if (playerPos.y > WIN_H - 50) playerPos.y = WIN_H - 50;

    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("レイキャスト （矢印キーで移動／マウスホイールでレイ数を増減／ドラッグで回転）");

    glClearColor(0.08f, 0.08f, 0.08f, 1.0f);

    initScene();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboardDown);
    glutKeyboardUpFunc(keyboardUp);
    glutSpecialFunc(specialDown);
    glutSpecialUpFunc(specialUp);
    glutMouseFunc(mouseButton);
    glutMotionFunc(passiveMotion);
    glutIdleFunc(idleFunc);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutMainLoop();
    return 0;
}