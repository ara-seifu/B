﻿#include <GL/glut.h>
#include <cmath>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct WaveBullet {
    float x, y;       // 弾の現在位置
    float speed;      // Y方向の速度
    float amplitude;  // サイン波の振幅
    float frequency;  // サイン波の周波数
    float startX;     // 初期X位置
    float time;       // 経過時間
};

std::vector<WaveBullet> bullets;

float playerX = 0.0f;
float playerY = -0.8f;

int lastTime = 0;

void shootWave(float x, float y, float speed, float amplitude, float frequency) {
    WaveBullet b;
    b.x = x;
    b.y = y;
    b.startX = x;
    b.speed = speed;
    b.amplitude = amplitude;
    b.frequency = frequency;
    b.time = 0.0f;
    bullets.push_back(b);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー（青）
    glPointSize(10.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(playerX, playerY);
    glEnd();

    // 弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    for (auto& b : bullets) {
        b.time += dt;
        b.y += b.speed * dt;                       // Y方向に移動
        b.x = b.startX + b.amplitude * sin(b.frequency * b.time); // X方向にサイン波
    }

    glutPostRedisplay();
}

void keyboard(unsigned char key, int, int) {
    if (key == ' ') {
        // 波弾を発射：速度0.5、振幅0.2、周波数6.28(rad/sec=1周期/sec)
        shootWave(playerX, playerY, 0.5f, 0.2f, 2 * M_PI);
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("sin波弾(Spaceで発射)");

    glClearColor(0.0, 0.0, 0.0, 1.0); // 背景 黒
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
