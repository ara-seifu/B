﻿#include <GL/freeglut.h> // FreeGLUT: ウィンドウ/入力/タイマー/描画のためのユーティリティ
#include <iostream>        // 標準入出力（cout など）
#include <vector>          // 動的配列
#include <queue>           // 優先度付きキュー（A* の open リストに使用）
#include <cmath>           // 三角関数、abs など
#include <algorithm>       // reverse, min など
#include <random>          // 乱数エンジン（未使用だが宣言あり）
#include <limits>          // numeric_limits<float>::infinity()
#include <string>          // std::string

using namespace std;     // チュートリアル用途で std:: を省略

constexpr double PI = 3.14159265358979323846; // 円描画で使う円周率

// ==== マップ設定 ====
const int MAP_W = 28;           // マップ幅（セル数）
const int MAP_H = 21;           // マップ高さ（セル数）
const int CELL_SIZE = 25;       // 1セルのピクセルサイズ（論理値）
const int WIN_W = MAP_W * CELL_SIZE; // ウィンドウ幅（論理座標）
const int WIN_H = MAP_H * CELL_SIZE; // ウィンドウ高さ（論理座標）

// マップのテンプレート（テキスト表現）。'#'壁 '.'ドット 'P'プレイヤー開始位置 空白は通行可
vector<string> mapTemplate = {
    "############################",
    "#............##............#",
    "#.####.#####.##.#####.####.#",
    "#.#  #.#   #.##.#   #.#  #.#",
    "#.#  #.#   #.##.#   #.#  #.#",
    "#.####.#####.##.#####.####.#",
    "#..........................#",
    "#.####.##.########.##.####.#",
    "#......##....##....##......#",
    "######.##### ## #####.######",
    "     #.#          #.#       ", 
    "######.# ###### ####.#######",
    "      . #      P     # .   ",
    "######.# ######## ## #.######",
    "#..............##...........#",
    "#.####.#####.##.#####.####.#",
    "#.#  #.#   #.##.#   #.#  #.#",
    "#.#  #.#   #.##.#   #.#  #.#",
    "#.####.#####.##.#####.####.#",
    "#..........................#",
    "############################",
};

vector<string> mapData; // 実行時に mapTemplate をコピーして使う（ゲーム中に変更するため）

// ==== エンティティ ====
struct Entity { int x = 0, y = 0; }; // グリッド座標を保持する簡易構造体
Entity player;   // プレイヤー座標
Entity ghost;    // ゴースト座標
int score = 0;   // 取得したドット数
int totalDots = 0; // 総ドット数（勝利判定用）

// RNG（現状未使用だが初期化してある）
std::mt19937 rng((unsigned)time(nullptr));

// ==== ヘルパー ====
inline bool inside(int x, int y) { return x >= 0 && x < MAP_W && y >= 0 && y < MAP_H; }
// マップ領域内かどうか（インデックスチェック）

// 壁判定：行長が足りない行も考慮する実装
bool isWall(int x, int y) {
    if (!inside(x, y)) return true;                    // 範囲外は壁扱い（通行不可）
    if (x >= (int)mapData[y].size()) return false;     // 行が短ければ空白扱い（通行可）
    return mapData[y][x] == '#';                        // '#' が壁
}

bool isDot(int x, int y) {
    if (!inside(x, y)) return false;                   // 範囲外にドットは無し
    if (x >= (int)mapData[y].size()) return false;     // 行が短ければドット無し
    return mapData[y][x] == '.';                        // '.' がドット
}

// マンハッタン距離（A* のヒューリスティック用）
float manhattan(int x1, int y1, int x2, int y2) {
    return float(abs(x1 - x2) + abs(y1 - y2));
}

// ==== A* 実装（安定版） ====
// Node: 探索ノード
struct Node {
    int x, y;       // ノードの位置
    float f, g, h;  // f = g + h, g = スタートからのコスト, h = ヒューリスティック
    Node* parent;   // 経路復元用ポインタ
};

// priority_queue 用比較子（f が小さいほうが優先）
struct NodeCmp {
    bool operator()(const Node* a, const Node* b) const { return a->f > b->f; } // 小さい f が優先
};

// aStar: 開始(sx,sy) から ゴール(gx,gy) までの経路を返す（見つからなければ空ベクタ）
vector<pair<int, int>> aStar(int sx, int sy, int gx, int gy) {
    if (sx == gx && sy == gy) return { {sx,sy} }; // スタートがゴールの場合は即座に返す

    // closed: 展開済みノードのフラグ
    vector<vector<bool>> closed(MAP_H, vector<bool>(MAP_W, false));
    // allNodes: 各座標に対応する Node* を保持（後で delete するため）
    vector<vector<Node*>> allNodes(MAP_H, vector<Node*>(MAP_W, nullptr));
    // gScore: 各座標の最良 g 値（初期は無限大）
    vector<vector<float>> gScore(MAP_H, vector<float>(MAP_W, numeric_limits<float>::infinity()));

    // open リスト（優先度付きキュー）
    priority_queue<Node*, vector<Node*>, NodeCmp> open;

    // 開始ノードを作成して open に入れる
    Node* start = new Node{ sx, sy, 0.0f, 0.0f, manhattan(sx,sy,gx,gy), nullptr };
    start->f = start->g + start->h; // f を計算
    open.push(start);
    allNodes[sy][sx] = start;       // 後で delete するために保存
    gScore[sy][sx] = 0.0f;          // スタートの g は 0

    // 4方向（右、左、上、下）
    const int dirs[4][2] = { {1,0},{-1,0},{0,1},{0,-1} };

    while (!open.empty()) {
        Node* cur = open.top(); open.pop(); // f が最小のノードを取り出す
        // stale エントリを無視するために g 値をチェック
        if (cur->g != gScore[cur->y][cur->x]) continue; // 優先度キューに古いエントリが残るので無視
        if (closed[cur->y][cur->x]) continue;          // 既に展開済みならスキップ
        closed[cur->y][cur->x] = true;                 // 現在ノードを展開済みにする

        // ゴール判定
        if (cur->x == gx && cur->y == gy) {
            // 経路復元：parent を辿ってスタートからゴールまでの経路を得る
            vector<pair<int, int>> path;
            Node* p = cur;
            while (p) {
                path.push_back({ p->x, p->y });
                p = p->parent;
            }
            reverse(path.begin(), path.end()); // 逆順なので反転して返す
            // 使用した Node オブジェクトを解放してメモリリークを防ぐ
            for (auto& row : allNodes) for (auto* n : row) if (n) delete n;
            return path;
        }

        // 隣接ノードを列挙
        for (auto& d : dirs) {
            int nx = cur->x + d[0];
            int ny = cur->y + d[1];
            if (!inside(nx, ny)) continue;      // 地図外ならスキップ
            if (isWall(nx, ny)) continue;      // 壁ならスキップ
            if (closed[ny][nx]) continue;      // 既に展開済みならスキップ

            float tentative_g = cur->g + 1.0f; // 各エッジのコストは 1 固定
            if (tentative_g < gScore[ny][nx]) {
                // より良い経路が見つかった場合に更新
                gScore[ny][nx] = tentative_g;
                float h = manhattan(nx, ny, gx, gy);
                float f = tentative_g + h;
                if (!allNodes[ny][nx]) {
                    // 初めて到達したセルなら Node を生成
                    allNodes[ny][nx] = new Node{ nx, ny, f, tentative_g, h, cur };
                }
                else {
                    // 既に Node が存在する場合は値を更新（priority_queue の decrease-key を模倣）
                    allNodes[ny][nx]->g = tentative_g;
                    allNodes[ny][nx]->h = h;
                    allNodes[ny][nx]->f = f;
                    allNodes[ny][nx]->parent = cur;
                }
                open.push(allNodes[ny][nx]); // open リストに追加（古いエントリは stale になる）
            }
        }
    }

    // open が空になって到達できない場合は使った Node を全て解放して空を返す
    for (auto& row : allNodes) for (auto* n : row) if (n) delete n;
    return {}; // 見つからなかった
}

// ==== 描画ユーティリティ ====
void drawRect(float x, float y, float w, float h) {
    // 四角形を即時モードで描く（左下原点, 幅 w, 高さ h）
    glBegin(GL_QUADS);
    glVertex2f(x, y);
    glVertex2f(x + w, y);
    glVertex2f(x + w, y + h);
    glVertex2f(x, y + h);
    glEnd();
}

void drawCircle(float cx, float cy, float r, int seg = 24) {
    // 中心(cx,cy) から三角扇で円を描く。seg が分割数（多いほど滑らか）
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy); // 中心
    for (int i = 0; i <= seg; ++i) {
        float theta = float(i) * float(2.0 * PI) / float(seg);
        float x = r * cosf(theta);
        float y = r * sinf(theta);
        glVertex2f(cx + x, cy + y);
    }
    glEnd();
}

// ==== ゲーム制御 ====
void resetGame() {
    mapData = mapTemplate; // テンプレートをコピーして実行時用マップにする（ドットを消したりするため）
    totalDots = 0;        // ドット数カウント初期化
    // 'P' を探して player を初期化
    bool foundP = false;
    for (int y = 0; y < MAP_H && y < (int)mapData.size(); ++y) {
        for (int x = 0; x < (int)mapData[y].size() && x < MAP_W; ++x) {
            if (mapData[y][x] == '.') totalDots++; // ドットをカウント
            if (!foundP && mapData[y][x] == 'P') {
                // P を見つけたらプレイヤー初期位置をセットしてマップ上の P を空白にする
                player.x = x; player.y = y;
                mapData[y][x] = ' ';
                foundP = true;
            }
        }
    }
    if (!foundP) { player.x = MAP_W / 2; player.y = MAP_H / 2; } // P が無ければ中央を保険で割り当て
    // ghost を固定位置に配置（本サンプルは単純化のため固定）
    ghost.x = 1; ghost.y = 1;
    score = 0; // スコア初期化
}

// ==== 描画 ====
void renderScene() {
    glClear(GL_COLOR_BUFFER_BIT);       // バッファクリア
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();                   // モデルビュー行列をクリア

    // 論理セル幅/高さ（投影で論理座標を WIN_W/WIN_H に固定しているためここで算出）
    float cellW = (float)WIN_W / (float)MAP_W;
    float cellH = (float)WIN_H / (float)MAP_H;

    // マップ描画（テキスト配列を走査）
    for (int y = 0; y < MAP_H && y < (int)mapData.size(); ++y) {
        for (int x = 0; x < MAP_W; ++x) {
            // 行長が短い場合に備えて安全に取り出す
            char c = (x < (int)mapData[y].size()) ? mapData[y][x] : ' ';
            float sx = x * cellW; // 描画用 X 座標
            // OpenGL の座標系は通常左下が原点なので、テキスト配列の y=0 を "上" に見せるため反転している
            float sy = (MAP_H - 1 - y) * cellH;

            if (c == '#') {
                glColor3f(0.0f, 0.4f, 1.0f); // 壁を青っぽく塗る
                drawRect(sx, sy, cellW, cellH);
            }
            else if (c == '.') {
                glColor3f(1.0f, 1.0f, 1.0f); // ドットは白い小さな円
                drawCircle(sx + cellW * 0.5f, sy + cellH * 0.5f, min(cellW, cellH) * 0.08f, 12);
            }
        }
    }

    // プレイヤー描画（黄色の円）。グリッド座標を中心座標に変換
    float px = player.x * cellW + cellW * 0.5f;
    float py = (MAP_H - 1 - player.y) * cellH + cellH * 0.5f;
    glColor3f(1.0f, 0.9f, 0.0f);
    drawCircle(px, py, min(cellW, cellH) * 0.4f, 32);

    // ゴースト描画（赤）。プレイヤーと同様に座標変換
    float gx = ghost.x * cellW + cellW * 0.5f;
    float gy = (MAP_H - 1 - ghost.y) * cellH + cellH * 0.5f;
    glColor3f(1.0f, 0.2f, 0.2f);
    drawCircle(gx, gy, min(cellW, cellH) * 0.35f, 28);

    // HUD（ラスタ文字） — 左下に表示
    glColor3f(1, 1, 1);
    string hud = "Score: " + to_string(score) + " / " + to_string(totalDots);
    glRasterPos2f(5.0f, 5.0f); // 描画位置（論理座標の左下からのオフセット）
    for (char ch : hud) glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ch); // 1文字ずつ描画

    glutSwapBuffers(); // ダブルバッファの切り替え
}

// ==== 入力処理 ====
void tryMovePlayer(int dx, int dy) {
    int nx = player.x + dx;
    int ny = player.y + dy;
    if (!inside(nx, ny)) return;   // 範囲外は無視
    if (isWall(nx, ny)) return;    // 壁なら無視

    player.x = nx; player.y = ny;  // 移動を確定
    if (isDot(nx, ny)) {
        mapData[ny][nx] = ' ';      // ドットを消す
        score++;                    // スコアを増やす
        if (score >= totalDots) {
            cout << "YOU WIN!" << endl; // 勝利表示（ゲーム終了処理はしていない）
        }
    }
}

void keyboard(unsigned char key, int, int) {
    if (key == 27) exit(0); // ESC で即終了
    if (key == 'q' || key == 'Q') exit(0); // q でも終了
    switch (key) {
    case 'w': case 'W': tryMovePlayer(0, -1); break; // 上
    case 's': case 'S': tryMovePlayer(0, 1); break;  // 下
    case 'a': case 'A': tryMovePlayer(-1, 0); break; // 左
    case 'd': case 'D': tryMovePlayer(1, 0); break;  // 右
    }
    glutPostRedisplay(); // 入力後に画面再描画要求
}

void specialKeys(int key, int, int) {
    // 矢印キー処理（GLUT の special key）
    switch (key) {
    case GLUT_KEY_UP:    tryMovePlayer(0, -1); break;
    case GLUT_KEY_DOWN:  tryMovePlayer(0, 1);  break;
    case GLUT_KEY_LEFT:  tryMovePlayer(-1, 0); break;
    case GLUT_KEY_RIGHT: tryMovePlayer(1, 0);  break;
    }
    glutPostRedisplay();
}

// ==== ゴースト更新（簡易） ====
void updateGhost() {
    // 毎回 A* でプレイヤーまでの経路を求め、1ステップだけ進める
    auto path = aStar(ghost.x, ghost.y, player.x, player.y);
    if (path.size() >= 2) {
        // path[0] は現在位置、path[1] が次の位置
        ghost.x = path[1].first;
        ghost.y = path[1].second;
    }
}

// ==== タイマー ====
void timerFunc(int) {
    // ゴーストとプレイヤーが同じでなければゴーストを更新
    if (!(ghost.x == player.x && ghost.y == player.y)) {
        updateGhost();
        if (ghost.x == player.x && ghost.y == player.y) {
            cout << "GAME OVER" << endl; // 衝突時の表示
            // そのまま終了せず描画を一回更新して止めたい場合は exit をコメントアウト
            exit(0);
        }
    }
    glutPostRedisplay();
    // 250ms 後に再度タイマーを呼ぶ（ループ）
    glutTimerFunc(250, timerFunc, 0);
}

// ==== ウィンドウリサイズ ====
void reshape(int w, int h) {
    glViewport(0, 0, w, h); // ビューポートをウィンドウ全体に設定
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    // 論理座標を固定：左下が (0,0) で右上が (WIN_W, WIN_H)
    // これによりウィンドウサイズに応じて描画がスケーリングされる
    glOrtho(0, WIN_W, 0, WIN_H, -1, 1);
    glMatrixMode(GL_MODELVIEW);
}

// ==== main ====
int main(int argc, char** argv) {
    resetGame(); // ゲーム状態を初期化

    glutInit(&argc, argv); // GLUT 初期化
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // ダブルバッファ＋RGBA
    glutInitWindowSize(WIN_W, WIN_H); // ウィンドウサイズの初期値
    glutCreateWindow("パックマンみたいなもの（経路探索学習用）"); // ウィンドウタイトル

    glClearColor(0, 0, 0, 1); // 背景色（黒）

    // コールバック登録
    glutDisplayFunc(renderScene);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glutReshapeFunc(reshape);
    glutTimerFunc(250, timerFunc, 0); // 250ms ごとのタイマー開始

    glutMainLoop(); // イベントループ開始（ここを抜けることは通常ない）
    return 0;
}
