﻿#include <GL/glut.h>
#include <cmath>
#include <vector>

#define M_PI 3.14159265358979323846

struct Bullet {
    float x, y;
    float vx, vy;
};

std::vector<Bullet> bullets;

float enemyX = 0.0f;
float enemyY = 0.0f;

int lastTime = 0;

// --- 円形弾幕発射 ---
void shootCircleBullet(int numBullets = 16, float speed = 0.3f) {
    for (int i = 0; i < numBullets; i++) {
        float angle = 2.0f * M_PI * i / numBullets;
        Bullet b;
        b.x = enemyX;
        b.y = enemyY;
        b.vx = speed * cos(angle);
        b.vy = speed * sin(angle);
        bullets.push_back(b);
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    for (auto& b : bullets) {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
    }

    glutPostRedisplay();
}

// キーで円形弾幕発射
void keyboard(unsigned char key, int, int) {
    if (key == ' ') shootCircleBullet(); // デフォルト16方向
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("円形弾幕(Spaceで発射)");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
