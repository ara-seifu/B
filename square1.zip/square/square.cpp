﻿/*
     正方形を表示、回転、拡大縮小、回転
 
↑↓←→キー … 平行移動
r … 回転（10度）
s … 拡大
S … 縮小
c … リセット

これを完成させよ

*/


#define _USE_MATH_DEFINES
#include <GL/glut.h>
#include <cmath>
#include <vector>
#include <iostream>

struct Vec3 {
    float x, y, w; // w=1 で同次座標
};

struct Mat3 {
    float m[3][3];
    static Mat3 identity() {
        Mat3 R{};   // Mat3 R; ならディフォルトコンストラクタが呼ばれる。　Mat3 R{}; だと値が０で初期化される
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
            R.m[i][j] = (i == j ? 1 : 0);       // 三項演算子 if(i==j) R.m[i][j] =  1;  else  R.m[i][j] =  0;
        return R;
    }
    Vec3 operator*(const Vec3& v) const {       // ＊演算子を行列の積としてオーバーロード
        Vec3 r{};
        r.x = m[0][0] * v.x + m[0][1] * v.y + m[0][2] * v.w;
        r.y = m[1][0] * v.x + m[1][1] * v.y + m[1][2] * v.w;
        r.w = m[2][0] * v.x + m[2][1] * v.y + m[2][2] * v.w;
        return r;
    }
    Mat3 operator*(const Mat3& B) const { // *演算子を行列にも使えるようにオーバーロード
        Mat3 R{};
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
            R.m[i][j] = 0;
            for (int k = 0; k < 3; k++) R.m[i][j] += m[i][k] * B.m[k][j];
        }
        return R;
    }
};

// ｘ方向にtx、ｙ方向にsy 移動する
Mat3 translate(float tx, float ty) 
{
    Mat3 R = Mat3::identity();// 単位行列




  
    return R;
}

// ｘ方向にsx倍、ｙ方向にsy倍 拡大する
Mat3 scale(float sx, float sy) 
{
    Mat3 R = Mat3::identity();// 単位行列




 
    return R;
}
// deg度だけ（左に）回転させる
Mat3 rotate(float deg) 
{
    Mat3 R = Mat3::identity(); // 単位行列




    return R;
}

// ========== グローバル ==========
std::vector<Vec3> square = {
    {-0.5, 0.5, 1 }, 
    { 0.5, 0.5, 1 }, 
    { 0.5,-0.5, 1 }, 
    {-0.5,-0.5, 1 }
};

Mat3 currentTransform = Mat3::identity();

// 描画
void drawPolygon(const std::vector<Vec3>& vertices, const Mat3& T) 
{
    glBegin(GL_POLYGON);
    for (auto v : vertices) {
        Vec3 tv = T * v;
        glVertex2f(tv.x / tv.w, tv.y / tv.w);
    }
    glEnd();
}

void display() 
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.2, 0.4, 1.0);
    drawPolygon(square, currentTransform);
    glFlush();
}

// キーボード操作
void keyboard(unsigned char key, int, int) {
    if (key == 0x1b) {
        exit(0);
    }
    if (key == 'r') { // 回転
        currentTransform = rotate(10) * currentTransform;
    }
    if (key == 's') { // 拡大
        currentTransform = scale(1.1f, 1.1f) * currentTransform;
    }
    if (key == 'S') { // 縮小
        currentTransform = scale(0.9f, 0.9f) * currentTransform;
    }
    if (key == 'c') { // リセット
        currentTransform = Mat3::identity();
    }
    glutPostRedisplay();
}

// 特殊キー（矢印キー）
void special(int key, int, int) 
{
    if (key == GLUT_KEY_UP)    currentTransform = translate(0, 0.1f) * currentTransform;
    if (key == GLUT_KEY_DOWN)  currentTransform = translate(0, -0.1f) * currentTransform;
    if (key == GLUT_KEY_LEFT)  currentTransform = translate(-0.1f, 0) * currentTransform;
    if (key == GLUT_KEY_RIGHT) currentTransform = translate(0.1f, 0) * currentTransform;
    glutPostRedisplay();
}

void init() 
{
    glClearColor(1, 1, 1, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-2, 2, -2, 2);
    glMatrixMode(GL_MODELVIEW);
}

int main(int argc, char* argv[]) 
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("正方形描画");
    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);
    glutMainLoop();
    return 0;
}
