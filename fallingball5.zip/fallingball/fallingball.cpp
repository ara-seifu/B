﻿// ボール階段落下シミュレーション (C++/GLUT)

#include <GL/glut.h>
#include <cmath>


// ウィンドウサイズ
const int WIN_W = 1200;       // ウインドウの幅
const int WIN_H = 600;       // ウインドウの高さ

// ボールの物理
float ballX ;          // ボールのX座標
float ballY ;          // ボールのY座標
float ballZ ;          // ボールのZ座標
float ballVX;          // 水平方向速度（右向き）
float ballVY;          // 垂直方向速度（上向き）
float gravity = 0.006f;    // 重力
float BALL_RADIUS = 0.3f;    // ボールの半径
float BOUNCE = 0.6f;    // 衝突係数
float FRICTION = 0.98f;    // 床の摩擦係数
float ROT_FRICTION = 0.98f;     // 回転減衰係数
float ballRot = 0.0f;    // ボールの回転角

// 階段
const int   NUM_STEPS = 20;  // 段数
const float STEP_WIDTH = 0.8f;  // 幅
const float STEP_HEIGHT = 0.2f;  // 高さ
const float STEP_DEPTH = 1.0f;  // 奥行

// 床の高さ
const float  FLOOR_Y = -NUM_STEPS * STEP_HEIGHT + BALL_RADIUS; // 床のY座標
// （階段の高さだけ下にずらし、ボールの中心座標で判定する為、ボールの半径分だけ上げている

constexpr double PI = 3.14159265358979323846f;

//-------------------------------------------------------
//    resetBall() 　ボール初期化
//-------------------------------------------------------
void resetBall() {
    ballX = -3.0f;          // ボールのX座標
    ballY = 2.5f;          // ボールのY座標
    ballZ = 0.0f;          // ボールのZ座標
    ballVX = 0.08f;          // 水平方向速度（右向き）
    ballVY = 0.1f;          // 垂直方向速度   （上向き）
}

//-------------------------------------------------------
//    drawStairs() 　階段を表示する
//-------------------------------------------------------
void drawStairs()
{
    glColor3f(0.7f, 0.7f, 0.7f);

    // 階段
    for (int i = 0; i < NUM_STEPS; i++) {   // 階段数ループ
        glPushMatrix();
        glTranslatef(i * STEP_WIDTH + STEP_WIDTH / 2, -i * STEP_HEIGHT - STEP_HEIGHT / 2, 0.0f);
        glScalef(STEP_WIDTH, STEP_HEIGHT, STEP_DEPTH);
        glutSolidCube(1.0f);
        glPopMatrix();
    }

    // 床(論理的には床はFLOOR_Yで定義された値だが、見た目の床はボールの中心より半径分下にある
}

//-------------------------------------------------------
//    drawBall() 　球を表示する
//-------------------------------------------------------
void drawBall()
{
    glPushMatrix();
    glTranslatef(ballX, ballY, ballZ);
    glRotatef(ballRot, 0, 0, 1);

    // 球の本体
    glColor3f(1.0f, 0.2f, 0.2f);    // 赤色の球
    glutSolidSphere(BALL_RADIUS, 40, 40);

    // 模様（経線・緯線）
    glColor3f(1.0f, 1.0f, 1.0f);   // 白色の線
    glutWireSphere(BALL_RADIUS * 1.001f, 6, 6); //  1.001倍の大きさの球のワイヤーフレームを表示（回転がわかるように）

    glPopMatrix();
}

//-------------------------------------------------------
//    update() 　タイマーから起動されるイベントハンドラ
//-------------------------------------------------------
void update(int value)
{
    float prevX = ballX;    //　ボールのX座標を保存


    // ボールのX座標更新

    ballX += ballVX;        // ボールのX座標にボールの横移動速度を加算（等速度運動）

    // ボールのY座標更新
    
    ballVY -= gravity;  // ボールの落下（上昇）速度に重力加速度を加える
    ballY += ballVY;    // ボールの座標にボールの落下（上昇）速度を加算（等加速度運動）


    // ボールの回転角
    float distance = ballX - prevX; // ボールの移動量（ｘ）
    ballRot += (distance / BALL_RADIUS) * (180.0f / PI); // 回転角を求める

    // 現在の段
    int step = (int)(ballX / STEP_WIDTH);   // ボールのｘ座標から何段目か調べる（かなり簡易的）

    // 衝突判定
    float stepY = (step >= 0 && step < NUM_STEPS) ? (-step * STEP_HEIGHT + BALL_RADIUS) : FLOOR_Y; // ボールの位置の床か階段のY座標を求める

    if (ballY < stepY) {    // 衝突した
        ballY = stepY;      // ボールの位置を階段（か床）の位置に修整
        ballVY = -ballVY * BOUNCE; // ボールの速度を逆方向に

        if (fabs(ballVY) < 0.001f) // ボールの速度が無視できるほどなら
            ballVY = 0.0f;          // ゼロとする
    }

    // 床に接触している間は摩擦と回転減衰を毎フレーム適用
    if (ballY <= FLOOR_Y + 0.001f) {    // 床まで落ちている
        ballVX *= FRICTION;             // 水平方向速度に摩擦係数を掛ける
        if (fabs(ballVX) < 0.001f)      // 水平方向速度の絶対値が０付近なら
            ballVX = 0.0f;           // 強制的にゼロに  

        ballRot *= ROT_FRICTION;        // 回転角に回転減衰係数を掛ける
        if (fabs(ballRot) < 0.01f)      //無視できるほど小さければ
            ballRot = 0.0f;             //回転角をゼロとする
    }

    glutPostRedisplay();                // 再描画
    glutTimerFunc(16, update, 0);       //　タイマーで update()を呼び出す
}

//-------------------------------------------------------
//    keyboard() 　キー入力用イベントハンドラ
//-------------------------------------------------------
void keyboard(unsigned char key, int, int) {
    if (key == 0x1b) exit(0);
    if (key == ' ')  resetBall();
}

//-------------------------------------------------------
//    display() 　描画用イベントハンドラ
//-------------------------------------------------------
void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    gluLookAt(9.0, 6.0, 16.0,
        8.0, 0.0, 0.0,
        0.0, 1.0, 0.0);

    drawStairs();
    drawBall();

    glutSwapBuffers();
}

//-------------------------------------------------------
//    reshape() 　サイズ変更時のイベントハンドラ
//-------------------------------------------------------
void reshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(50.0, (float)w / h, 0.1, 50.0);
    glMatrixMode(GL_MODELVIEW);
}

//-------------------------------------------------------
//    main()
//-------------------------------------------------------
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("ボール階段落下");

    resetBall();

    glEnable(GL_DEPTH_TEST);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(16, update, 0);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
