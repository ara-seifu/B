﻿#include <GL/glut.h>
#include <cmath>
#include <vector>

#define M_PI 3.14159265358979323846

struct Bullet {
    float x, y;
    float vx, vy;
    float lifeTime;  // 発射からの経過時間
    bool isChild;    // 子弾かどうか
};

std::vector<Bullet> bullets;

float enemyX = 0.0f;
float enemyY = -0.8f;

int lastTime = 0;

// --- 弾発射 ---
void shootBullet() {
    Bullet b;
    b.x = enemyX;
    b.y = enemyY;
    b.vx = 0.0f;
    b.vy = 0.5f;   // 上方向に発射
    b.lifeTime = 0.0f;
    b.isChild = false;
    bullets.push_back(b);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    std::vector<Bullet> newBullets;

    for (auto& b : bullets) {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.lifeTime += dt;

        // 分裂条件：親弾で1秒経過したら分裂
        if (!b.isChild && b.lifeTime > 1.0f) {
            for (int i = -1; i <= 1; i++) { // -1,0,1方向に分裂
                Bullet child;
                child.x = b.x;
                child.y = b.y;
                float angle = i * 20.0f * M_PI / 180.0f; // ±20度
                float speed = 0.4f;
                float vx = b.vx * cos(angle) - b.vy * sin(angle);
                float vy = b.vx * sin(angle) + b.vy * cos(angle);
                child.vx = vx != 0.0f ? vx : 0.0f + speed * sin(angle);
                child.vy = vy != 0.0f ? vy : speed * cos(angle);
                child.lifeTime = 0.0f;
                child.isChild = true;
                newBullets.push_back(child);
            }
            b.isChild = true; // 親は分裂済み扱い
        }
    }

    // 子弾を追加
    bullets.insert(bullets.end(), newBullets.begin(), newBullets.end());

    glutPostRedisplay();
}

// キーで弾発射
void keyboard(unsigned char key, int, int) {
    if (key == ' ') shootBullet();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("分裂弾(Spaceで発射)");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
