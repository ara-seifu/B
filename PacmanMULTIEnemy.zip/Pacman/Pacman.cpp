﻿
#include <GL/freeglut.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <random>
#include <string>
#include <cstring> // memset

using namespace std;

constexpr double PI = 3.14159265358979323846;

// ==== マップ設定 ====
const int MAP_W = 28;
const int MAP_H = 21;
const int CELL_SIZE = 25;
const int WIN_W = MAP_W * CELL_SIZE;
const int WIN_H = MAP_H * CELL_SIZE;

vector<string> mapTemplate = {
    "############################",
    "#............##............#",
    "#.####.#####.##.#####.####.#",
    "#.#  #.#   #.##.#   #.#  #.#",
    "#.#  #.#   #.##.#   #.#  #.#",
    "#.####.#####.##.#####.####.#",
    "#..........................#",
    "#.####.##.########.##.####.#",
    "#......##....##....##......#",
    "######.##### ## #####.######",
    "     #.#          #.#     ",
    "######.# ###### ####.#######",
    "      . #      P     # .   ",
    "######.# ######## ## #.######",
    "#..............##...........#",
    "#.####.#####.##.#####.####.#",
    "#.#  #.#   #.##.#   #.#  #.#",
    "#.#  #.#   #.##.#   #.#  #.#",
    "#.####.#####.##.#####.####.#",
    "#..........................#",
    "############################",
};

vector<string> mapData; // 実行時にコピーして使う

// ==== エンティティ ====
struct Entity { int x = 0, y = 0; };
Entity player;
int playerDirX = 0, playerDirY = 0; // プレイヤーの直近移動方向（予測用）

struct Ghost {
    int x = 0, y = 0;
    enum Type { BLINKY = 0, PINKY = 1, INKY = 2, CLYDE = 3 } type;
    // コンストラクタ
    Ghost(int _x = 0, int _y = 0, Type t = BLINKY) : x(_x), y(_y), type(t) {}
};

vector<Ghost> ghosts;
int score = 0;
int totalDots = 0;

// RNG
std::mt19937 rng((unsigned)time(nullptr));

// ==== ヘルパー ====
inline bool inside(int x, int y) { return x >= 0 && x < MAP_W && y >= 0 && y < MAP_H; }

// 壁判定（行長が短い場合を考慮）
bool isWall(int x, int y) {
    if (!inside(x, y)) return true;
    if (y >= (int)mapData.size()) return true;
    if (x >= (int)mapData[y].size()) return false; // 行が短ければ空白（通行可）
    return mapData[y][x] == '#';
}

bool isDot(int x, int y) {
    if (!inside(x, y)) return false;
    if (y >= (int)mapData.size()) return false;
    if (x >= (int)mapData[y].size()) return false;
    return mapData[y][x] == '.';
}

inline int manhattan_i(int x1, int y1, int x2, int y2) {
    return abs(x1 - x2) + abs(y1 - y2);
}

// ==== 高速 A*（new/delete を使わない実装） ====
// ノード配列は座標インデックスで直接アクセスする方式。
// openList は単純な配列ヒープ（ここでは線形探索で最低 f を探す）。
// MAP が小さいため実装の簡潔さを優先。

const int MAX_NODES = MAP_W * MAP_H;
const int INF_G = 1 << 28;

struct FastNode {
    int x, y;
    int g;      // g cost
    int h;      // heuristic
    int f;      // g + h
    int parent; // parent index (index = y*MAP_W + x), -1 == none
    bool open;
    bool closed;
};

static FastNode nodes[MAX_NODES];
static int openList[MAX_NODES];
static int openCount = 0;

inline int GetIndex(int x, int y) { return y * MAP_W + x; }

void ResetNodes() {
    // 全ノードのフラグをリセット。MAP が小さいので loop で初期化。
    for (int i = 0; i < MAX_NODES; ++i) {
        nodes[i].open = false;
        nodes[i].closed = false;
        nodes[i].g = INF_G;
        nodes[i].parent = -1;
    }
    openCount = 0;
}

void OpenPush(int idx) {
    openList[openCount++] = idx;
}

int OpenPopLowestF() {
    // 最低 f を線形探索で見つけて取り出す（MAPが小さいので OK）
    int bestPos = 0;
    int bestIdx = openList[0];
    for (int i = 1; i < openCount; ++i) {
        int idx = openList[i];
        if (nodes[idx].f < nodes[bestIdx].f) {
            bestPos = i;
            bestIdx = idx;
        }
    }
    int ret = openList[bestPos];
    openList[bestPos] = openList[--openCount];
    return ret;
}

// A* を実行して path を返す（path は [start,...,goal] の座標列）
// 注意: isWall チェックは呼び出し側で OK
vector<pair<int, int>> aStar_fast(int sx, int sy, int gx, int gy) {
    vector<pair<int, int>> path;
    if (sx == gx && sy == gy) { path.emplace_back(sx, sy); return path; }
    if (!inside(sx, sy) || !inside(gx, gy)) return path;
    if (isWall(gx, gy)) return path;

    ResetNodes();

    int sIdx = GetIndex(sx, sy);
    int gIdx = GetIndex(gx, gy);

    // 初期ノード設定
    nodes[sIdx].x = sx;
    nodes[sIdx].y = sy;
    nodes[sIdx].g = 0;
    nodes[sIdx].h = manhattan_i(sx, sy, gx, gy);
    nodes[sIdx].f = nodes[sIdx].g + nodes[sIdx].h;
    nodes[sIdx].parent = -1;
    nodes[sIdx].open = true;
    OpenPush(sIdx);

    const int dirs[4][2] = { {1,0},{-1,0},{0,1},{0,-1} };

    while (openCount > 0) {
        int curIdx = OpenPopLowestF();
        FastNode& cur = nodes[curIdx];
        cur.open = false;
        cur.closed = true;

        if (curIdx == gIdx) {
            // 経路復元
            int p = gIdx;
            while (p != -1) {
                int px = nodes[p].x;
                int py = nodes[p].y;
                path.emplace_back(px, py);
                p = nodes[p].parent;
            }
            reverse(path.begin(), path.end());
            return path;
        }

        for (int d = 0; d < 4; ++d) {
            int nx = cur.x + dirs[d][0];
            int ny = cur.y + dirs[d][1];
            if (!inside(nx, ny)) continue;
            if (isWall(nx, ny)) continue;
            int nIdx = GetIndex(nx, ny);
            if (nodes[nIdx].closed) continue;

            int tentative_g = cur.g + 1;
            if (tentative_g < nodes[nIdx].g) {
                nodes[nIdx].x = nx;
                nodes[nIdx].y = ny;
                nodes[nIdx].g = tentative_g;
                nodes[nIdx].h = manhattan_i(nx, ny, gx, gy);
                nodes[nIdx].f = nodes[nIdx].g + nodes[nIdx].h;
                nodes[nIdx].parent = curIdx;
                if (!nodes[nIdx].open) {
                    nodes[nIdx].open = true;
                    OpenPush(nIdx);
                }
            }
        }
    }

    // 見つからなかった場合は空を返す
    return path;
}

// ==== 描画ユーティリティ ====
void drawRect(float x, float y, float w, float h) {
    glBegin(GL_QUADS);
    glVertex2f(x, y);
    glVertex2f(x + w, y);
    glVertex2f(x + w, y + h);
    glVertex2f(x, y + h);
    glEnd();
}

void drawCircle(float cx, float cy, float r, int seg = 24) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= seg; ++i) {
        float theta = float(i) * float(2.0 * PI) / float(seg);
        float x = r * cosf(theta);
        float y = r * sinf(theta);
        glVertex2f(cx + x, cy + y);
    }
    glEnd();
}

// ==== ゲーム制御 ====
void resetGame() {
    mapData = mapTemplate;
    totalDots = 0;
    bool foundP = false;
    for (int y = 0; y < MAP_H && y < (int)mapData.size(); ++y) {
        for (int x = 0; x < (int)mapData[y].size() && x < MAP_W; ++x) {
            if (mapData[y][x] == '.') totalDots++;
            if (!foundP && mapData[y][x] == 'P') {
                player.x = x; player.y = y;
                mapData[y][x] = ' ';
                foundP = true;
            }
        }
    }
    if (!foundP) { player.x = MAP_W / 2; player.y = MAP_H / 2; }

    // ゴーストを初期化（複数） - 代表的な4体を示す位置は適宜調整可能
    ghosts.clear();
    ghosts.emplace_back(1, 1, Ghost::BLINKY);                    // 直接追跡
    ghosts.emplace_back(MAP_W - 2, 1, Ghost::PINKY);               // 予測型
    ghosts.emplace_back(1, MAP_H - 2, Ghost::INKY);                // 協調/中間狙い
    ghosts.emplace_back(MAP_W - 2, MAP_H - 2, Ghost::CLYDE);         // 気まぐれ
    score = 0;

    playerDirX = 0; playerDirY = 0;
}

// ==== 描画 ====
void renderScene() {
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    float cellW = (float)WIN_W / (float)MAP_W;
    float cellH = (float)WIN_H / (float)MAP_H;

    // マップ
    for (int y = 0; y < MAP_H && y < (int)mapData.size(); ++y) {
        for (int x = 0; x < MAP_W; ++x) {
            char c = (x < (int)mapData[y].size()) ? mapData[y][x] : ' ';
            float sx = x * cellW;
            float sy = (MAP_H - 1 - y) * cellH; // 上を0行目に見せるため反転

            if (c == '#') {
                glColor3f(0.0f, 0.4f, 1.0f);
                drawRect(sx, sy, cellW, cellH);
            }
            else if (c == '.') {
                glColor3f(1.0f, 1.0f, 1.0f);
                drawCircle(sx + cellW * 0.5f, sy + cellH * 0.5f, min(cellW, cellH) * 0.08f, 12);
            }
        }
    }

    // プレイヤー
    float px = player.x * cellW + cellW * 0.5f;
    float py = (MAP_H - 1 - player.y) * cellH + cellH * 0.5f;
    glColor3f(1.0f, 0.9f, 0.0f);
    drawCircle(px, py, min(cellW, cellH) * 0.4f, 32);

    // ゴースト群
    for (const Ghost& g : ghosts) {
        float gx = g.x * cellW + cellW * 0.5f;
        float gy = (MAP_H - 1 - g.y) * cellH + cellH * 0.5f;
        // 色をタイプで変える
        switch (g.type) {
        case Ghost::BLINKY: glColor3f(1.0f, 0.2f, 0.2f); break; // 赤
        case Ghost::PINKY:  glColor3f(1.0f, 0.5f, 0.8f); break; // ピンク
        case Ghost::INKY:   glColor3f(0.0f, 1.0f, 1.0f); break; // シアン
        case Ghost::CLYDE:  glColor3f(1.0f, 0.6f, 0.0f); break; // 橙
        }
        drawCircle(gx, gy, min(cellW, cellH) * 0.35f, 28);
    }

    // HUD
    glColor3f(1, 1, 1);
    string hud = "Score: " + to_string(score) + " / " + to_string(totalDots);
    glRasterPos2f(5.0f, 5.0f);
    for (char ch : hud) glutBitmapCharacter(GLUT_BITMAP_8_BY_13, ch);

    glutSwapBuffers();
}

// ==== 入力処理 ====
void tryMovePlayer(int dx, int dy) {
    int nx = player.x + dx;
    int ny = player.y + dy;
    if (!inside(nx, ny)) return;
    if (isWall(nx, ny)) return;

    player.x = nx; player.y = ny;
    // 移動方向を保持（Pinky の予測等で使用）
    playerDirX = dx; playerDirY = dy;

    if (isDot(nx, ny)) {
        mapData[ny][nx] = ' ';
        score++;
        if (score >= totalDots) {
            cout << "YOU WIN!" << endl;
        }
    }
}

void keyboard(unsigned char key, int, int) {
    if (key == 27) exit(0);
    if (key == 'q' || key == 'Q') exit(0);
    switch (key) {
    case 'w': case 'W': tryMovePlayer(0, -1); break;
    case 's': case 'S': tryMovePlayer(0, 1); break;
    case 'a': case 'A': tryMovePlayer(-1, 0); break;
    case 'd': case 'D': tryMovePlayer(1, 0); break;
    }
    glutPostRedisplay();
}

void specialKeys(int key, int, int) {
    switch (key) {
    case GLUT_KEY_UP:    tryMovePlayer(0, -1); break;
    case GLUT_KEY_DOWN:  tryMovePlayer(0, 1);  break;
    case GLUT_KEY_LEFT:  tryMovePlayer(-1, 0); break;
    case GLUT_KEY_RIGHT: tryMovePlayer(1, 0);  break;
    }
    glutPostRedisplay();
}

// ==== ゴースト戦略・更新 ====

// 各ゴーストのターゲットを決める（Pinky はプレイヤー進行方向を4マス先に予測）
pair<int, int> ComputeGhostTarget(const Ghost& g) {
    int pacX = player.x;
    int pacY = player.y;
    int dirX = playerDirX;
    int dirY = playerDirY;

    switch (g.type) {
    case Ghost::BLINKY:
        return { pacX, pacY }; // 直追
    case Ghost::PINKY: {
        // 進行方向の4マス先を狙う（進行方向がない場合はプレイヤーを狙う）
        if (dirX == 0 && dirY == 0) return { pacX, pacY };
        int tx = pacX + dirX * 4;
        int ty = pacY + dirY * 4;
        // クリッピング（マップ外と行短を気にするのは aStar 側で判定する）
        if (tx < 0) tx = 0; if (tx >= MAP_W) tx = MAP_W - 1;
        if (ty < 0) ty = 0; if (ty >= MAP_H) ty = MAP_H - 1;
        return { tx, ty };
    }
    case Ghost::INKY: {
        // Blinky と協調する簡易版: プレイヤーと自分の中間点を狙う（実際の Inky は別計算）
        // ここでは最も近い Blinky を探して中間点を狙う実装にしても良い
        // 簡易実装: 自身との中間
        int tx = (pacX + g.x) / 2;
        int ty = (pacY + g.y) / 2;
        return { tx, ty };
    }
    case Ghost::CLYDE: {
        // 近づきすぎたら逃げる、離れていたら追う
        int dist = manhattan_i(g.x, g.y, pacX, pacY);
        if (dist < 6) {
            // マップの左下に逃げる（ランダムにする場合は乱数で設定）
            return { 1, MAP_H - 2 };
        }
        else {
            return { pacX, pacY };
        }
    }
    default:
        return { pacX, pacY };
    }
}

// ゴーストを1ステップ進める（A* で経路を求めて次ノードへ）
void updateGhost(Ghost& g) {
    auto target = ComputeGhostTarget(g);
    // A* を実行して path を得る
    auto path = aStar_fast(g.x, g.y, target.first, target.second);
    if (path.size() >= 2) {
        // 次のステップへ（1 マス進む）
        g.x = path[1].first;
        g.y = path[1].second;
    }
    else if (path.size() == 1) {
        // すでに目標にいる
        g.x = path[0].first;
        g.y = path[0].second;
    }
    else {
        // 経路なしならランダムに1歩（安全策）
        const int dx[4] = { 1,-1,0,0 };
        const int dy[4] = { 0,0,1,-1 };
        for (int i = 0; i < 4; ++i) {
            int nx = g.x + dx[i];
            int ny = g.y + dy[i];
            if (inside(nx, ny) && !isWall(nx, ny)) {
                g.x = nx; g.y = ny; break;
            }
        }
    }
}

// ==== タイマー ====
void timerFunc(int) {
    // まずプレイヤーとゴーストが同じかチェック（既に衝突しているなら終了）
    for (const Ghost& g : ghosts) {
        if (g.x == player.x && g.y == player.y) {
            cout << "GAME OVER" << endl;
            exit(0);
        }
    }

    // 各ゴーストを更新（ここで A* を呼ぶ）
    for (auto& g : ghosts) {
        updateGhost(g);
        if (g.x == player.x && g.y == player.y) {
            cout << "GAME OVER" << endl;
            exit(0);
        }
    }

    glutPostRedisplay();
    glutTimerFunc(200, timerFunc, 0); // 200ms ごとに更新（調整可能）
}

// ==== ウィンドウリサイズ ====
void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, WIN_W, 0, WIN_H, -1, 1); // 論理座標を固定
    glMatrixMode(GL_MODELVIEW);
}

// ==== main ====
int main(int argc, char** argv) {
    resetGame();

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("パックマンみたいなもの (高速 A* ＆マルチゴースト版)");

    glClearColor(0, 0, 0, 1);

    glutDisplayFunc(renderScene);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glutReshapeFunc(reshape);
    glutTimerFunc(200, timerFunc, 0);

    glutMainLoop();
    return 0;
}
