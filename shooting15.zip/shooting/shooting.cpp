﻿#include <GL/glut.h>
#include <cmath>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct Bullet {
    float x, y;
    float vx, vy;
};

std::vector<Bullet> bullets;

// 敵の位置（固定）
float enemyX = 0.0f;
float enemyY = 0.8f;

// プレイヤー位置（ターゲット）
float playerX = 0.0f;
float playerY = -0.8f;

int lastTime = 0;

// --- 集中弾 ---
// n: 弾数, spread: 集中範囲(rad), speed: 単位/sec
void shootFocused(float ex, float ey, float px, float py, int n, float spread, float speed) {
    // 中心角をプレイヤーに向ける
    float dx = px - ex;
    float dy = py - ey;
    float baseAngle = atan2(dy, dx);

    for (int i = 0; i < n; i++) {
        float angle = baseAngle - spread * 0.5f + spread * (i / (float)(n - 1));
        Bullet b;
        b.x = ex;
        b.y = ey;
        b.vx = cos(angle) * speed;
        b.vy = sin(angle) * speed;
        bullets.push_back(b);
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // プレイヤー（青）
    glPointSize(10.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(playerX, playerY);
    glEnd();

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    // 弾の更新
    for (auto& b : bullets) {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
    }

    glutPostRedisplay();
}

void keyboard(unsigned char key, int, int) {
    if (key == ' ') {
        // 集中弾を発射：3発、5度範囲、速度0.5
        shootFocused(enemyX, enemyY, playerX, playerY, 3, 5 * M_PI / 180.0f, 0.5f);
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("集中弾(Spaceで発射)");

    glClearColor(0.0, 0.0, 0.0, 1.0); // 背景 黒
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
