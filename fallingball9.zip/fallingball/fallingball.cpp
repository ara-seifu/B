﻿// ボール落下 &バウンド (C++/GLUT) + 軌跡表示
// 修正版: ボール半径を正しく考慮し、めり込みを防止（衝突時刻で補正し残り時間を反映）

#include <GL/glut.h>
#include <cmath>
#include <vector>

// ウィンドウサイズ
const int WIN_W = 800;
const int WIN_H = 600;
constexpr double PI = 3.14159265358979323846;

// 物理定数
const float g = 9.8f;          // 重力加速度 (m/s^2)
const float dt = 0.016f;       // タイムステップ (秒) ≒ 60fps
const float restitution = 0.6f; // 反発係数
const float groundFriction = 0.98f;

// スケーリング（物理m→画面px）
const float SCALE = 80.0f;

// ボール状態
struct Vec2 { float x, y; };
Vec2 pos = { 5.0f, 7.0f };    // 初期位置 (m) — 中心座標
Vec2 vel = { 0.0f, 0.0f };    // 初速度 (m/s) — 中心速度
const float ballRadius = 0.1f; // 0.1m（半径）

// 床の高さ（地面の y 座標）
const float groundY = 0.5f;  // m （床の位置。ボール底面がここに接する）

// 軌跡を保存する配列
std::vector<Vec2> trail;

//-------------------------------------------------------
//    drawCircle() 　円を表示する（２Ｄ表示の為に独自で用意）
//-------------------------------------------------------
void drawCircle(float radius, int segments) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(0, 0); // 中心
    for (int i = 0; i <= segments; i++) {
        float theta = 2.0f * PI * float(i) / float(segments);
        float x = radius * cosf(theta);
        float y = radius * sinf(theta);
        glVertex2f(x, y);
    }
    glEnd();
}

//-------------------------------------------------------
//    display() 　描画用イベントハンドラ
//-------------------------------------------------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 軌跡の描画
    if (!trail.empty()) {
        glColor3f(1, 1, 0); // 黄色い線
        glBegin(GL_LINE_STRIP);
        for (auto& p : trail) {
            glVertex2f(p.x * SCALE, p.y * SCALE);
        }
        glEnd();
    }

    // ボール描画 (2D円)
    glPushMatrix();
    glTranslatef(pos.x * SCALE, pos.y * SCALE, 0.0f);
    glColor3f(1, 0, 0);
    drawCircle(ballRadius * SCALE, 64);  // 自前で２D表示
    glPopMatrix();

    // 床描画
    glColor3f(0, 1, 0);
    glBegin(GL_LINES);
    glVertex2f(0, groundY * SCALE);
    glVertex2f(WIN_W, groundY * SCALE);
    glEnd();

    glutSwapBuffers();
}

//-------------------------------------------------------
//    update() 　タイマーから起動されるイベントハンドラ
//-------------------------------------------------------
void update(int value) {
    // 前フレームの中心高さ
    float prevY = pos.y;

    // --- 速度更新（重力） ---
    // vel は中心の速度（yが下向きに負になる方向で扱っている）
    vel.y += -g * dt; // 下向きに負の増加

    // 予測（中心）
    float nextX = pos.x + vel.x * dt;
    float nextY = pos.y + vel.y * dt;

    // 底面 (= center_y - radius)
    float prevBottom = prevY - ballRadius;
    float nextBottom = nextY - ballRadius;

    // 衝突判定（底面が床を越えたか）
    if (nextBottom <= groundY) {
        // 衝突が起きる割合 alpha を底面で計算
        // prevBottom > groundY（通常）かつ nextBottom <= groundY のはず
        float denom = (prevBottom - nextBottom);
        float alpha = 0.0f;
        if (denom > 1e-8f) {
            alpha = (prevBottom - groundY) / denom;
            if (alpha < 0.0f) alpha = 0.0f;
            if (alpha > 1.0f) alpha = 1.0f;
        }
        else {
            alpha = 0.0f;
        }

        // 衝突時点の位置（中心）
        float collideX = pos.x + vel.x * dt * alpha;
        float collideY = pos.y + vel.y * dt * alpha; // 中心位置での衝突（まだ半径差あり）

        // 補正して、底面がちょうど床に接する中心Yにする
        collideY = groundY + ballRadius;

        // 衝突前の速度（フレーム先頭で更新した vel は "直前→直後" の値）
        // vel_before はフレームの速度（すでに重力を適用済み）
        Vec2 vel_before = vel;

        // 衝突後の速度
        Vec2 vel_after = vel_before;
        vel_after.y = -vel_before.y * restitution; // 反発（y成分反転 + 係数）
        vel_after.x = vel_before.x * groundFriction; // 接地摩擦で横速度を減衰

        // 残り時間（フレーム内）
        float remain = (1.0f - alpha) * dt;

        // 衝突時刻で位置を設定したあと、残り時間分だけ衝突後の速度で進める
        pos.x = collideX + vel_after.x * remain;
        pos.y = collideY + vel_after.y * remain;

        // 最終的に速度は衝突後のものを採用
        vel = vel_after;

        // 軌跡に追加（現在の中心位置）
        trail.push_back(pos);
    }
    else {
        // 衝突がなければ通常更新（中心）
        pos.x = nextX;
        pos.y = nextY;

        // 軌跡に追加
        trail.push_back(pos);
    }

    if (pos.x * SCALE > WIN_W || pos.y * SCALE < 0 || pos.y * SCALE > WIN_H) {
        pos = { 0.5f, 7.0f };   // 初期位置
        vel = { 4.0f, 0.0f };   // 初速度
        trail.clear();        // 軌跡リセット
    }

    // 軌跡が増えすぎるなら古い点を削除
    if (trail.size() > 2000) {
        trail.erase(trail.begin(), trail.begin() + 200);
    }

    glutPostRedisplay();
    glutTimerFunc(int(dt * 1000), update, 0);
}

//-------------------------------------------------------
//    reshape() 　サイズ変更時のイベントハンドラ
//-------------------------------------------------------
void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WIN_W, 0, WIN_H);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

//-------------------------------------------------------
//    main()
//-------------------------------------------------------
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("ボール落下＆バウンド（床面厳密版）");

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(int(dt * 1000), update, 0);

    glutMainLoop();
    return 0;
}
