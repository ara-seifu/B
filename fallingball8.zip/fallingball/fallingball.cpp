﻿// ボール落下 &バウンド(C++/GLUT) 
// シンプル版: ボール半径を考慮せず、めり込み補正もしない

#include <GL/glut.h>
#include <cmath>
#include <vector>

// ウィンドウサイズ
const int WIN_W = 800;
const int WIN_H = 600;
constexpr double PI = 3.14159265358979323846;

// 物理定数
const float g = 9.8f;           // 重力加速度 (m/s^2)
const float dt = 0.016f;        // タイムステップ (秒) ≒ 60fps
const float restitution = 0.6f; // 反発係数
const float groundFriction = 0.98f;

// スケーリング（物理m→画面px）
const float SCALE = 80.0f;

// ボール状態
struct Vec2 { float x, y; };
Vec2 pos = { 5.0f, 7.0f };     // 初期位置 (m)
Vec2 vel = { 0.0f, 0.0f };     // 初速度 (m/s)
const float ballRadius = 0.1f; // 半径（描画用だけ）

// 床の高さ（地面の y 座標）
const float groundY = 0.5f;    // m

//-------------------------------------------------------
//    drawCircle() 　円を表示する（２Ｄ表示の為に独自で用意）
//-------------------------------------------------------
void drawCircle(float radius, int segments) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(0, 0);
    for (int i = 0; i <= segments; i++) {
        float theta = 2.0f * PI * float(i) / float(segments);
        float x = radius * cosf(theta);
        float y = radius * sinf(theta);
        glVertex2f(x, y);
    }
    glEnd();
}

//-------------------------------------------------------
//    display() 　描画用イベントハンドラ
//-------------------------------------------------------
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // ボール描画
    glPushMatrix();
    glTranslatef(pos.x * SCALE, pos.y * SCALE, 0.0f);
    glColor3f(1, 0, 0);
    drawCircle(ballRadius * SCALE, 64);
    glPopMatrix();

    // 床描画
    glColor3f(0, 1, 0);
    glBegin(GL_LINES);
    glVertex2f(0, groundY * SCALE);
    glVertex2f(WIN_W, groundY * SCALE);
    glEnd();

    glutSwapBuffers();
}

//-------------------------------------------------------
//    update() 　タイマーから起動されるイベントハンドラ
//-------------------------------------------------------
void update(int value) {

    // --- 速度更新（重力） ---
    vel.y += -g * dt;

    // --- 位置更新 ---
    pos.x += vel.x * dt;
    pos.y += vel.y * dt;

    // 衝突判定（中心が groundY 以下）
    if (pos.y <= groundY) {
        pos.y = groundY;                  // めり込みをそのまま修正
        vel.y = -vel.y * restitution;     // 反発
        vel.x *= groundFriction;          // 摩擦で減速
    }


    glutPostRedisplay();
    glutTimerFunc(int(dt * 1000), update, 0);
}

//-------------------------------------------------------
//    reshape() 　サイズ変更時のイベントハンドラ
//-------------------------------------------------------
void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, WIN_W, 0, WIN_H);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

//-------------------------------------------------------
//    main()
//-------------------------------------------------------
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(WIN_W, WIN_H);
    glutCreateWindow("ボール落下＆バウンド");

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(int(dt * 1000), update, 0);

    glutMainLoop();
    return 0;
}
