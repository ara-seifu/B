﻿#include <GL/glut.h>
#include <cmath>
#include <vector>

#define M_PI 3.14159265358979323846

struct Bullet {
    float x, y;
    float vx, vy;
    float lifeTime;  // 発射からの経過時間
    bool exploded;   // 爆発済みか
};

std::vector<Bullet> bullets;

float enemyX = 0.0f;
float enemyY = -0.8f;

int lastTime = 0;

// --- 親弾発射 ---
void shootFirework() {
    Bullet b;
    b.x = enemyX;
    b.y = enemyY;
    b.vx = 0.0f;
    b.vy = 0.3f;     // 上方向に発射
    b.lifeTime = 0.0f;
    b.exploded = false;
    bullets.push_back(b);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    std::vector<Bullet> newBullets;

    for (auto& b : bullets) {
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.lifeTime += dt;

        // 爆発条件：親弾で3秒経過、まだ爆発していない場合
        if (!b.exploded && b.lifeTime > 3.0f) {
            int numChild = 12; // 子弾の数
            float speed = 0.3f;
            for (int i = 0; i < numChild; i++) {
                float angle = 2.0f * M_PI * i / numChild;
                Bullet child;
                child.x = b.x;
                child.y = b.y;
                child.vx = speed * cos(angle);
                child.vy = speed * sin(angle);
                child.lifeTime = 0.0f;
                child.exploded = true; // 子弾はさらに爆発しない
                newBullets.push_back(child);
            }
            b.exploded = true;
        }
    }

    // 子弾を追加
    bullets.insert(bullets.end(), newBullets.begin(), newBullets.end());

    glutPostRedisplay();
}

// キーで花火弾発射
void keyboard(unsigned char key, int, int) {
    if (key == ' ') shootFirework();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("花火弾(Spaceで発射)");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
