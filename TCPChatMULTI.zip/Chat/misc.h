#ifndef _MYMISC
#define	_MYMISC


struct INFORMATION_STRING
{
	char*  str							;
	struct INFORMATION_STRING * next	;
	struct INFORMATION_STRING * prev	;
};

extern struct INFORMATION_STRING g_base;
#endif


void	InitInformationStr(void)			;
void	ResetInformationStr(void)			;
int		ReturnInformationItem(void)			;
char*	ReturnLastInformationStr(void)		;
int		InsertInformationStr(const char *str)	;



