
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS

#include "stdafx.h"
#include "resource.h"
#include "misc.h"

#include <winsock2.h>
#include <windows.h>
#include <process.h>   
#include <stdio.h>
#include <stdlib.h>
#include <WinUser.h>
#include <ws2tcpip.h>

#pragma comment(lib,"ws2_32.lib")


//--------------------------------------------------------------------------

#define CHAT_PORT			1024


#define	CHAT_NOT_CONNECT	0
#define	CHAT_TRY_CONNECT	1
#define	CHAT_CONNECTED		2
#define	CHAT_SERVER_STATE	4

#define MAX_LOADSTRING		100
#define BUFFSIZE			3000
#define STRSIZE				500

char			g_tmp_chatting_str[BUFFSIZE]		;
int				g_tmp_chatting_length=0				;

WSADATA			g_wsadata				;			// winsock dll
unsigned short	g_port					;			// �|�[�g�ԍ�

SOCKADDR_IN		g_socket_address		;			// �T�[�o�[��IP�A�h���X
SOCKET			g_server_socket			;			// �T�[�o�[���\�P�b�g

SOCKADDR_IN		g_client_addrin[8]		;			// �N���C�A���g��IP�A�h���X
SOCKET			g_client_socket[8]		;			// �N���C�A���g���\�P�b�g
BOOL			g_client_status[8] = { FALSE };		// �N���C�A���g���

HINSTANCE 		g_hInst							;	// �C���X�^���X�n���h��
TCHAR 			szTitle[MAX_LOADSTRING]			;	// �^�C�g����
TCHAR 			szWindowClass[MAX_LOADSTRING]	;	// �N���X��
HWND			g_hwnd			;					// �E�C���h�E�n���h��
HWND			g_hEdit = NULL	;					// �ҏW�R���g���[��
WNDPROC			g_fnoldedit		;					// �ҏW�R���g���[���̃f�B�t�H���g�̃E�C���h�E�v���V�[�W��
int				g_state = CHAT_NOT_CONNECT		;	// �X�e�[�^�X



//==========================================================================


//--------------------------------------------------------------------------
char* ReturnMyIpAddress()
{
	int			re;
	char		name[STRSIZE], * ip = NULL;
	PHOSTENT	hostinfo;

	re = gethostname(name, sizeof(name))	;
	if (re == 0) {
		if ((hostinfo = gethostbyname(name)) != NULL) {
			ip = inet_ntoa(*(struct in_addr*)*hostinfo->h_addr_list)	;
		}
	}

	return ip	;
}



//--------------------------------------------------------------------------
int SendChattingMessageSub(SOCKET socket,char* str,int len)	// ������𑗐M����
{
	int		size, total_send = 0;

	while (1) {
		size = send(socket, str+total_send, len-total_send, 0);			// �o�O�C���i�����f�[�^�����x�������Ă����j

		if (size == SOCKET_ERROR) {
			InsertInformationStr("send error!");
			return(-1);
		}

		total_send += size;		

		if (total_send >= len) {
//			char buf2[BUFFSIZE];
//			sprintf(buf2, "snd: %s", str);
//			InsertInformationStr(buf2);
			break;
		}
	}
	return(0);
}


//--------------------------------------------------------------------------
void SendChattingMessage(char* str)	// ������𑗐M����
{
	int		len	;
	char	buf[BUFFSIZE];

	if (str == NULL)
		return	;

	len = (int)strlen(str) + 1	;

	if (g_state == CHAT_SERVER_STATE) {
		for (int i = 0; i < 8; i++) {
			if (g_client_status[i]) {
				if (SendChattingMessageSub(g_client_socket[i], str, len) ) {	// ������𑗐M����
					return;
				}
			}
		}
	}
	else {
		if (SendChattingMessageSub(g_server_socket, str, len)){					// ������𑗐M����
			return;
		}
	}
	sprintf(buf, "snd: %s", str);
	InsertInformationStr(buf);

}



//--------------------------------------------------------------------------
void MakeChattingString(char* str, int size)	// ��M��������܂Ƃ߂ăO���[�o���ϐ��Ɍ���
{
	int		len = -1, i	;

	if (str == NULL || size <= 0)
		return	;

	for (i = 0; i < size; i++) {
		if (str[i] == NULL) {
			len = i + 1	;
			break	;
		}
	}

	if (len < 0) {
		len = size	;
		memcpy((g_tmp_chatting_str + g_tmp_chatting_length), str, len)	;
		g_tmp_chatting_length += len	;
	}
	else {
		memcpy((g_tmp_chatting_str + g_tmp_chatting_length), str, len)	;
//		InsertInformationStr(g_tmp_chatting_str)	;
		if (size != len) {
			g_tmp_chatting_length = (size - len)	;
			memcpy(g_tmp_chatting_str, (str + len), g_tmp_chatting_length)	;
		}
	}
}

//--------------------------------------------------------------------------
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message){
		case WM_INITDIALOG:
				return TRUE	;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) {
				EndDialog(hDlg, LOWORD(wParam))	;
				return TRUE	;
			}
			break	;
	}
    return FALSE	;
}

//--------------------------------------------------------------------------
void ClientThread(void* lpvoid)		// ��M�X���b�h�i�N���C�A���g���j
{
	int					re			;
	DWORD				dw_re		;
	char				buf[BUFFSIZE] = { 0 }	;
	char				buf2[BUFFSIZE] = { 0 }	;
	WSANETWORKEVENTS	event		;
	WSAEVENT			h_revent	;
	SOCKET				socket		;

	int		addr_in_size = sizeof(SOCKADDR_IN)	;

	socket = g_server_socket;		//�@�T�[�o�[���\�P�b�g

	h_revent = WSACreateEvent()		;	//�@�C�x���g���쐬
	WSAEventSelect(socket, h_revent, FD_WRITE | FD_READ | FD_CLOSE)	;	//�@�C�x���g�ƃ\�P�b�g�����т���

	while (1) {
//		InsertInformationStr(buf)	;
		dw_re = WSAWaitForMultipleEvents(1, &h_revent, FALSE, WSA_INFINITE, FALSE)	;
		WSAEnumNetworkEvents(socket, h_revent, &event)	;

		if ((event.lNetworkEvents & FD_READ)) {				//�@��M����
			re = recv(socket, buf, sizeof(buf), 0)	;
			if (re > 0 && re< BUFFSIZE) {
				MakeChattingString(buf, re)			;
				buf[re] = '\0'						;
				sprintf(buf2, "rcv: %s", buf)		;
				InsertInformationStr(buf2)			;
				InvalidateRect(g_hwnd, NULL, TRUE)	;
			}
		}
		else if ((event.lNetworkEvents & FD_CLOSE)) {		//�@�ؒf���ꂽ
			InsertInformationStr("Disconnect Chat")	;
			break	;
		}
	}

	g_state = CHAT_NOT_CONNECT	;

	closesocket(socket)	;
	_endthread()	;
}

//--------------------------------------------------------------------------
void ServerThread(void* no)		// ��M�X���b�h�i�T�[�o�[���j
{
	int					re;
	DWORD				dw_re;
	char				buf[BUFFSIZE] = { 0 };
	char				buf2[BUFFSIZE] = { 0 };
	WSANETWORKEVENTS	event;
	WSAEVENT			h_revent;
	SOCKET				socket;

	int		addr_in_size = sizeof(SOCKADDR_IN);

	socket = g_client_socket[(int)no];	//�@�N���C�A���g���\�P�b�g
		
	h_revent = WSACreateEvent();	//�@�C�x���g���쐬
	WSAEventSelect(socket, h_revent, FD_WRITE | FD_READ | FD_CLOSE);	//�@�C�x���g�ƃ\�P�b�g�����т���

	while (1) {
		//		InsertInformationStr(buf)	;
		dw_re = WSAWaitForMultipleEvents(1, &h_revent, FALSE, WSA_INFINITE, FALSE);
		WSAEnumNetworkEvents(socket, h_revent, &event);

		if ((event.lNetworkEvents & FD_READ)) {				//�@��M����
			re = recv(socket, buf, sizeof(buf), 0);
			if (re > 0 && re < BUFFSIZE) {
				MakeChattingString(buf, re);
				buf[re] = '\0';
				sprintf(buf2, "rcv: %s", buf);
				InsertInformationStr(buf2);
				InvalidateRect(g_hwnd, NULL, TRUE);
			}
		}
		else if ((event.lNetworkEvents & FD_CLOSE)) {		//�@�ؒf���ꂽ
			InsertInformationStr("Disconnect Chat");
			break;
		}
	}

	g_client_status[(int)no] = false;
	g_state = CHAT_NOT_CONNECT;

	closesocket(socket)	;
	_endthread()	;
}

//--------------------------------------------------------------------------
void AcceptThread(void* lpvoid)		// accept�X���b�h�i�T�[�o�[���j
{
	int		addr_in_size = sizeof(SOCKADDR_IN);
	char    buf[STRSIZE];

	for(int i=0;i<8;i++) {
		g_client_socket[i] = accept(g_server_socket, (struct sockaddr*)&g_client_addrin[i], &addr_in_size);
		g_client_status[i] = true;

		sprintf(buf, "accepted IP( %s )  PORT ( %u )", inet_ntoa(g_client_addrin[i].sin_addr), ntohs(g_client_addrin[i].sin_port));
		InsertInformationStr(buf);
		InvalidateRect(g_hwnd, NULL, TRUE);
		_beginthread(ServerThread, 0, (void*)i)	;	//�@�T�[�o�[����M�X���b�h�N��	
	}

	_endthread();
}


//--------------------------------------------------------------------------
int ConnectToChat(unsigned short port, char* ip)	// �N���C�A���g���N��
{
	int		re			;
	char	buf[STRSIZE]	;

	g_port = port	;
	g_socket_address.sin_family			= AF_INET		;
	g_socket_address.sin_port			= htons(port)	;
	g_socket_address.sin_addr.s_addr	= inet_addr(ip)	;


	if (WSAStartup(MAKEWORD(2, 2), &g_wsadata) == SOCKET_ERROR) {	//WS2_32.dll�����[�h
//		InsertInformationStr("WS2_32.DLL Load fail!");
		WSACleanup();

		return -1;
	}

//	InsertInformationStr("make stream type socket")	;
	g_server_socket = socket(AF_INET, SOCK_STREAM, 0)			;			//�\�P�b�g�쐬
	if (g_server_socket == INVALID_SOCKET) {
//		InsertInformationStr("Stream socket create fail!");
		WSACleanup();

		return -2;
	}

	sprintf_s(buf, "Chat trying connect to %s...", ip);
//	InsertInformationStr(buf)	;
	re = connect(g_server_socket, (SOCKADDR*)&g_socket_address, sizeof(SOCKADDR_IN))	;	//�@�R�l�N�g
	if (re) {
//		InsertInformationStr("connect fail!");
		closesocket(g_server_socket);
		WSACleanup();

		return -3;
	}

//	InsertInformationStr("connect success ");
	sprintf(buf, "connected IP( %s )  PORT ( %u )", inet_ntoa(g_socket_address.sin_addr), ntohs(g_socket_address.sin_port));
	InsertInformationStr(buf);

	g_state = CHAT_CONNECTED			;
	_beginthread(ClientThread, 0, NULL)	;	// �N���C�A���g����M�X���b�h�N��

	return 0	;

}

//--------------------------------------------------------------------------
int	BeginChatServer(unsigned short port)	// �T�[�o�[���N��
{
//	int		addr_in_size = sizeof(SOCKADDR_IN);
	char	strbuf[STRSIZE];


	//	InsertInformationStr("Try Load WS2_32.DLL");
	if (WSAStartup(MAKEWORD(2, 2), &g_wsadata) == SOCKET_ERROR) {
		InsertInformationStr("WS2_32.DLL Load fail!");
		WSACleanup();
		return -1;
	}


	sprintf_s(strbuf, "server ip address is %s", ReturnMyIpAddress());
	InsertInformationStr(strbuf);

	g_port = port;
	g_socket_address.sin_family = AF_INET;
	g_socket_address.sin_port = htons(port);
	g_socket_address.sin_addr.s_addr = inet_addr(ReturnMyIpAddress());

	InsertInformationStr("Try open socket..");
	if ((g_server_socket = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
		InsertInformationStr("Socket create error");
		WSACleanup();
		return -2;
	}

	//Try bind
	InsertInformationStr("Try bind...");
	if (bind(g_server_socket, (struct sockaddr*)&g_socket_address, sizeof(g_socket_address)) == SOCKET_ERROR) {
		InsertInformationStr("Bind fail!");
		closesocket(g_server_socket);
		WSACleanup();
		return -3;
	}

	//listen client
	InsertInformationStr("Try listen...");
	if (listen(g_server_socket, SOMAXCONN) == SOCKET_ERROR) {
		InsertInformationStr("listen fail!");
		closesocket(g_server_socket);
		WSACleanup();
		return -4;
	}

	//try accept	
	InsertInformationStr("wait client...");
	InvalidateRect(g_hwnd, NULL, TRUE);
	SendMessage(g_hwnd, WM_PAINT, 0, 0);

	g_state = CHAT_SERVER_STATE;

	_beginthread(AcceptThread, 0, NULL)	;	//�@accept�X���b�h�N��	

	return 0;
}


//--------------------------------------------------------------------------
LRESULT CALLBACK EditProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	char	buf[BUFFSIZE], str[STRSIZE];
	int		re;

	if (iMsg == WM_KEYDOWN && wParam == VK_RETURN) {	//�@�����񂪓��͂��ꂽ
		re = GetWindowText(g_hEdit, buf, BUFFSIZE)	;

		if (re > 0 && re<500) {
			buf[re] = '\0';

			if (g_state == CHAT_NOT_CONNECT && strcmp(buf, "wait") == 0) { //wait �Ɠ��͂��ꂽ��
				if (BeginChatServer(CHAT_PORT) == 0) {		// �T�[�o�[�Ƃ��ċN��
					InsertInformationStr("start server")			;
				}
				else {
					InsertInformationStr("start server fail!")	;
				}
			}

			else if (strcmp(buf, "exit") == 0) {				// exit �Ɠ��͂��ꂽ��I��		
				DestroyWindow(g_hwnd);
			}
			else if (g_state == CHAT_NOT_CONNECT) {				//�@���ڑ��Ȃ���͂��ꂽ�̂̓T�[�o�[���Ɖ���
				g_state = CHAT_TRY_CONNECT				;
				sprintf_s(str, "connect to %s", buf)	;
				InsertInformationStr(str)				;
				if (ConnectToChat(CHAT_PORT, buf) == 0) {		// �T�[�o�[�ɐڑ�
					InsertInformationStr("connect success!")	;
				}
				else {
					InsertInformationStr("connect fail!")	;
					g_state = CHAT_NOT_CONNECT				;
				}
			}
			else {													//�@�ڑ����Ȃ���͂��ꂽ�̂͑��M�p���b�Z�[�W�Ɖ���
				SendChattingMessage(buf)				;
//				InsertInformationStr(buf)				;
			}
		}
		SetWindowText(g_hEdit, "")	;								//�@�����������
		InvalidateRect(g_hwnd, NULL, TRUE);
	}

	return CallWindowProc(g_fnoldedit, hwnd, iMsg, wParam, lParam)	;	// �f�B�t�H���g�̃E�C���h�v���V�[�W�����Ăяo���i�T�u�N���X���j
}


//--------------------------------------------------------------------------
void CreateEditLine(HWND hwnd, WPARAM wParam, LPARAM lParam)	// �ҏW�p�̎q�E�C���h�E�i�R���g���[���j���쐬
{
	g_hEdit = CreateWindow("edit", NULL, WS_CHILD|WS_VISIBLE|WS_BORDER|ES_LEFT, 16, 450, 560, 20,
		hwnd, NULL, ((LPCREATESTRUCT)lParam)->hInstance, NULL)		;
	if(g_hEdit == NULL)	{
		InsertInformationStr("Chatting editline create fail!")	;
		return	;
	}

	g_fnoldedit	= (WNDPROC)SetWindowLongPtr(g_hEdit, GWLP_WNDPROC, (LPARAM)EditProc)	;//�ҏW�R���g���[���̃f�B�t�H���g�̃E�C���h�E�v���V�[�W���̃A�h���X���擾

//	InsertInformationStr("Chatting editline create Success!")	;

}



//--------------------------------------------------------------------------
void DrawInformation(HDC hdc)	// �������\��
{

	struct INFORMATION_STRING* p;
	int i, y, x = 20;

	p = g_base.prev	;
	for (i = 0; p != &g_base && i < 20;i++) {
		char* s;
		s = p->str;

		if (p->str) {
			y = (20-i) * 20;
			TextOut(hdc, x, y, p->str, (int)strlen(p->str));
		}

		p = p->prev;
	}


}








//--------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int 			wmId, wmEvent	;
	PAINTSTRUCT 	ps				;
	HDC 			hdc				;
	TCHAR 			szHello[MAX_LOADSTRING]	;
	RECT 			rt				;
	
	
	LoadString(g_hInst, IDS_HELLO, szHello, MAX_LOADSTRING)	;

	switch (message) {
		
		case WM_CREATE:
			InitInformationStr()		;
			CreateEditLine(hWnd, wParam, lParam)	;	// �ҏW�p�R���g���[���쐬
			break	;
		
		case WM_COMMAND:
			wmId    = LOWORD(wParam)	; 
			wmEvent = HIWORD(wParam)	; 
		
			switch (wmId)			{
				case IDM_ABOUT:
				   DialogBox(g_hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About)	;
				   break	;
				
				case IDM_EXIT:
				   DestroyWindow(hWnd)	;
				   break	;
				
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam)	;
			}
			break	;
		
		case WM_SETFOCUS:
			SetFocus(g_hEdit)			;
			break	;

		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps)	;
			GetClientRect(hWnd, &rt)	;
			DrawInformation(hdc)		;	// �X�e�[�^�X��\��
			EndPaint(hWnd, &ps)			;
			break	;
		
		case WM_DESTROY: 
			ResetInformationStr()	;
			PostQuitMessage(0)			;
			break	;
		
		default:
			return DefWindowProc(hWnd, message, wParam, lParam)	;
   }
   return 0;
}

//--------------------------------------------------------------------------
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex	;

	wcex.cbSize = sizeof(WNDCLASSEX)	; 

	wcex.style			= CS_HREDRAW | CS_VREDRAW	;
	wcex.lpfnWndProc	= (WNDPROC)WndProc	;
	wcex.cbClsExtra		= 0	;
	wcex.cbWndExtra		= 0	;
	wcex.hInstance		= hInstance	;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_CHAT)	;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW)	;
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1)		;
	wcex.lpszMenuName	= (LPCSTR)IDC_CHAT			;
	wcex.lpszClassName	= szWindowClass		;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL)	;

	return RegisterClassEx(&wcex)	;
}

//--------------------------------------------------------------------------
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND		hWnd		;

   g_hInst = hInstance	;
	
   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
   		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL)	;

   g_hwnd	= hWnd	;

   if (!hWnd)   {
      return FALSE	;
   }

   ShowWindow(hWnd, nCmdShow)	;
   UpdateWindow(hWnd)			;

   return TRUE	;
}

//--------------------------------------------------------------------------
int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR llpCmdLine, _In_ int nCmdShow) 
{
 	MSG 	msg			;
	HACCEL 	hAccelTable	;
	
	
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING)	;
	LoadString(hInstance, IDC_CHAT, szWindowClass, MAX_LOADSTRING)	;
	MyRegisterClass(hInstance)	;

	if (!InitInstance (hInstance, nCmdShow)) {
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_CHAT);

	while (GetMessage(&msg, NULL, 0, 0)) {
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) {
			TranslateMessage(&msg)	;
			DispatchMessage(&msg)	;
		}
	}

	return (int)msg.wParam	;

}

