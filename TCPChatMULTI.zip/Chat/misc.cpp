#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include "misc.h"


struct INFORMATION_STRING g_base;
int nodeItem = 0;


void InitInformationStr(void)
{
	g_base.next = &g_base	;
	g_base.prev = &g_base	;
	g_base.str  = NULL		;

}


void ResetInformationStr(void)
{
	struct INFORMATION_STRING * p, *q	;

	p = g_base.next	;

	while (p != &g_base) {
		if (p->str) {
			free(p->str)	;
		}
		p->prev->next = p->next	;
		p->next->prev = p->prev	;
		q = p->next	;
		free(p)		;
		p = q		;

	}
}

 
int	ReturnInformationItem(void)
{
	struct INFORMATION_STRING* p	;
	int item = 0	;

	p = g_base.next	;

	while (p != &g_base) {
		item++		;
		p = p->next	;

	}
	return(item);
}


char * ReturnLastInformationStr(void)
{
	return(g_base.prev->str)	;
}



int InsertInformationStr(const char *str)
{
	struct INFORMATION_STRING* p	;
	
	p = g_base.next	;

	if (str == NULL) {
		return(-1)	;
	}

	p = (struct INFORMATION_STRING *)malloc(sizeof(struct INFORMATION_STRING));		
	if (!p) {
		return(-2)	;
	}
	p->str = (char*)malloc(strlen(str) + 1)	;		
	if (!p->str) {
		return(-3)	;
	}
	
	memcpy(p->str, str, strlen(str) + 1)	;	// �m�ۂ����������ɃR�s�[�i�Ō��NULL���Ɓj

	p->next = & g_base		;
	p->prev = g_base.prev	;

	p->next->prev = p		;
	p->prev->next = p		;

	nodeItem++	;
	return(0)	;

}







