﻿#include <GL/glut.h>
#include <cmath>
#include <vector>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct RotBullet {
    float cx, cy;   // 回転中心
    float radius;   // 半径
    float angle;    // 現在の角度
    float angularSpeed; // rad/sec
};

std::vector<RotBullet> bullets;

// 回転中心（敵）
float enemyX = 0.0f;
float enemyY = 0.0f;

int lastTime = 0;

void shootRotating(int n, float radius, float angularSpeed) {
    for (int i = 0; i < n; i++) {
        RotBullet b;
        b.cx = enemyX;
        b.cy = enemyY;
        b.radius = radius;
        b.angle = (2.0f * M_PI / n) * i; // 均等に配置
        b.angularSpeed = angularSpeed;
        bullets.push_back(b);
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        float x = b.cx + b.radius * cos(b.angle);
        float y = b.cy + b.radius * sin(b.angle);
        glVertex2f(x, y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f; // 秒
    lastTime = currentTime;

    // 弾の更新（角度を回転）
    for (auto& b : bullets) {
        b.angle += b.angularSpeed * dt;
        if (b.angle > 2.0f * M_PI) b.angle -= 2.0f * M_PI;
    }

    glutPostRedisplay();
}

void keyboard(unsigned char key, int, int) {
    if (key == ' ') {
        // 固定回転弾：8発、半径0.3、角速度1rad/sec
        shootRotating(8, 0.3f, 1.0f);
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("固定回転弾(Spaceで発射）");

    glClearColor(0.0, 0.0, 0.0, 1.0); // 背景 黒
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
