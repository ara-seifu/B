﻿#include <GL/glut.h>
#include <vector>

struct AcceleratingBullet {
    float x, y;
    float vx, vy;      // 現在速度
    float ax, ay;      // 加速度
};

std::vector<AcceleratingBullet> bullets;

float enemyX = 0.0f;
float enemyY = -0.8f;

int lastTime = 0;

// --- 弾発射 ---
void shootAcceleratingBullet() {
    AcceleratingBullet b;
    b.x = enemyX;
    b.y = enemyY;
    b.vx = 0.0f;
    b.vy = 0.05f;     // 初速
    b.ax = 0.0f;
    b.ay = 1.8f;     // 加速度
    bullets.push_back(b);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // 敵（緑）
    glPointSize(12.0f);
    glBegin(GL_POINTS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(enemyX, enemyY);
    glEnd();

    // 弾（赤）
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glColor3f(1.0f, 0.0f, 0.0f);
    for (auto& b : bullets) {
        glVertex2f(b.x, b.y);
    }
    glEnd();

    glutSwapBuffers();
}

void idle() {
    int currentTime = glutGet(GLUT_ELAPSED_TIME);
    float dt = (currentTime - lastTime) / 1000.0f;
    lastTime = currentTime;

    for (auto& b : bullets) {
        // 速度更新
        b.vx += b.ax * dt;
        b.vy += b.ay * dt;

        // 位置更新
        b.x += b.vx * dt;
        b.y += b.vy * dt;
    }

    glutPostRedisplay();
}

// キーで弾発射
void keyboard(unsigned char key, int, int) {
    if (key == ' ') shootAcceleratingBullet();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(600, 600);
    glutCreateWindow("加速弾(Spaceで発射）");

    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);

    lastTime = glutGet(GLUT_ELAPSED_TIME);

    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
