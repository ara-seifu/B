#include <GL/glut.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <chrono>

#define M_PI 3.14159265358979323846

using namespace std::chrono;

float ballX, ballY;
float ballVx, ballVy;
float g = -9.8f;

float fielderX = 20.0f;
float landingX = 20.0f; // �{�[���̗����\��n�_

bool apexReached = false;
bool ballCaught = false;

steady_clock::time_point lastTime;

void resetBall() {
    ballX = -30.0f;
    ballY = 1.0f;
    ballVy = 18.0f + rand() % 5;
    ballVx = 10.0f + rand() % 3;

    apexReached = false;
    ballCaught = false;
    landingX = 20.0f;
    fielderX = 20.0f;

    lastTime = steady_clock::now();
}

void drawCircle(float x, float y, float r, float R, float G, float B) {
    glColor3f(R, G, B);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < 64; i++) {
        float th = i * 2.0f * M_PI / 64;
        glVertex2f(x + r * cos(th), y + r * sin(th));
    }
    glEnd();
}

void update() {
    steady_clock::time_point now = steady_clock::now();
    duration<float> elapsed = now - lastTime;
    float dt = elapsed.count();
    lastTime = now;

    if (ballCaught) return;

    // �{�[���^��
    ballX += ballVx * dt;
    ballY += ballVy * dt;
    ballVy += g * dt;


    // ���_����
    if (!apexReached && ballVy < 0) { // ����ɓ��B����
        apexReached = true;

        //-----------------------------------------
        // ���_���B���_�ŗ����n�_(landingX)���v�Z����
        //-----------------------------------------
        



        //-----------------------------------------
        //
        //-----------------------------------------

    }

    // �n�ʔ���
    if (ballY <= 0) {
        ballY = 0;
        ballVy = 0;
        ballVx = 0;
        ballCaught = true;
        return;
    }

    // �O���ړ��i���_�ȍ~�j
    if (apexReached && !ballCaught) {
        float dx = landingX - fielderX;

        // �����ɉ��������x�����Ŋ��炩��
        float speedLimit = 15.0f * (1.0f + (15.0f - ballY) / 15.0f);
        if (dx > speedLimit  * dt) dx =  speedLimit * dt;
        if (dx < -speedLimit * dt) dx = -speedLimit * dt;

        fielderX += dx;
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    update();

    // �n��
    glColor3f(0.2f, 0.6f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(-50, 0); glVertex2f(50, 0);
    glVertex2f(50, -1); glVertex2f(-50, -1);
    glEnd();

    // �{�[���i���j
    drawCircle(ballX, ballY, 0.2f, 1, 1, 1);

    // �O���i���F�j
    drawCircle(fielderX, 0.5f, 0.5f, 1, 1, 0);

    glutSwapBuffers();
}

void timer(int v) { glutPostRedisplay(); glutTimerFunc(16, timer, 0); }
void reshape(int w, int h) { glViewport(0, 0, w, h); glMatrixMode(GL_PROJECTION); glLoadIdentity(); gluOrtho2D(-40, 40, -1, 20); glMatrixMode(GL_MODELVIEW); }
void keyboard(unsigned char key, int x, int y) { if (key == ' ') resetBall(); }
void init() { glClearColor(0.2f, 0.4f, 0.8f, 1.0f); srand(time(nullptr)); resetBall(); }

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(1800, 600);
    glutCreateWindow("�O��� �����n�_�\���L���b�`�i�X�y�[�X�Ń��g���C�j");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(16, timer, 0);
    glutMainLoop();
    return 0;
}
